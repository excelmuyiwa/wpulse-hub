var ug=Object.defineProperty;var hg=(Et,lt,Qt)=>lt in Et?ug(Et,lt,{enumerable:!0,configurable:!0,writable:!0,value:Qt}):Et[lt]=Qt;var ls=(Et,lt,Qt)=>hg(Et,typeof lt!="symbol"?lt+"":lt,Qt);(function(){"use strict";const Et=[];let lt=!1;function Qt(n){const e=n instanceof Error?n.message:typeof n=="string"?n:"";return/extension context invalidated/i.test(e)}function rc(n){Et.push(n)}function Jt(n){if(!Qt(n))return!1;if(lt)return!0;lt=!0,console.debug("[PULSE] Extension context invalidated; this content script has stopped");for(const e of Et)try{e()}catch{}return!0}const cs="pulsePlayerAssignment";function oc(){return typeof chrome<"u"&&!!chrome.storage&&!!chrome.storage.local}async function Ur(){if(!oc())return null;try{const n=await chrome.storage.local.get(cs),e=n?n[cs]:null;if(!e||typeof e!="object")return null;const t=e;return typeof t.wooglesUsername!="string"||t.wooglesUsername.length===0?null:{wooglesUsername:t.wooglesUsername,pulseSlot:t.pulseSlot==="player1"||t.pulseSlot==="player2"?t.pulseSlot:null,confirmedAt:typeof t.confirmedAt=="number"?t.confirmedAt:Date.now()}}catch(n){return Jt(n)||console.error("[Pulse Identity] Failed to read confirmed assignment from storage",n),null}}let Je=null,Sn=null;function Wr(n){try{const e=n.split(".");if(e.length!==3)return null;const s=e[1].replace(/-/g,"+").replace(/_/g,"/"),i=atob(s);return JSON.parse(i)}catch{return null}}async function ac(n=!1){return!n&&Je&&Date.now()<Je.expiresAt?Je:Sn||(Sn=(async()=>{try{const e=await fetch("/api/user_service.AuthenticationService/GetSocketToken",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:"{}"});if(!e.ok)return console.info("[Pulse Identity] Authentication request failed:",e.status),Je=null,null;const t=await e.text();let s;try{s=JSON.parse(t)}catch{return console.warn("[Pulse Identity] Invalid JSON response"),Je=null,null}const r=s.token;if(typeof r!="string")return console.info("[Pulse Identity] No token in response"),Je=null,null;const o=Wr(r);if(!o)return console.warn("[Pulse Identity] Failed to decode JWT payload"),Je=null,null;const a=typeof o.unn=="string"?o.unn:"",l=typeof o.uid=="string"?o.uid:"",c=typeof o.a=="boolean"?o.a:!1,f=typeof o.exp=="number"?o.exp:0;if(!a||!l||!c)return console.info("[Pulse Identity] JWT missing required fields"),Je=null,null;const d=Date.now(),h=f>0?f*1e3:d+300*1e3;return Je={username:a,userId:l,authenticated:c,expiresAt:h,detectedAt:d},Je}catch(e){return console.info("[Pulse Identity] Network/fetch error:",e),Je=null,null}finally{Sn=null}})(),Sn)}async function lc(){try{const n=await fetch("/api/user_service.AuthenticationService/GetSocketToken",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:"{}"});if(n.status===401||n.status===403)return{kind:"signed-out"};if(!n.ok)return{kind:"unknown"};const e=JSON.parse(await n.text());if(typeof e.token!="string")return{kind:"signed-out"};const t=Wr(e.token);if(!t)return{kind:"unknown"};const s=typeof t.unn=="string"?t.unn:"",i=typeof t.a=="boolean"?t.a:!1;return s&&i?{kind:"signed-in",username:s}:{kind:"signed-out"}}catch{return{kind:"unknown"}}}function li(n,e,t=Date.now()){if(!n)return!1;if(t>=n.expiresAt)return!0;const s=n.username.toLowerCase();return!e.some(i=>i.length>0&&i.toLowerCase()===s)}function cc(n){const e={...n[0]||{name:"",username:"",rating:0,score:0,clock:0,slot:"player1"},slot:"player1"},t={...n[1]||{name:"",username:"",rating:0,score:0,clock:0,slot:"player2"},slot:"player2"};return{player1:e,player2:t}}function Cn(n){const e=n.match(/\/game\/([^\/?#]+)/);if(!e)return null;const t=e[1];return t||null}function uc(n){const e=Cn(n);return e?{gameId:e,url:n,detectedAt:Date.now()}:null}function Gr(n){const e=n.trim();if(e==="")return null;const t=/^[-−]/.test(e),s=(t?e.slice(1):e).split(":");for(const r of s)if(!/^\d+$/.test(r))return null;let i;if(s.length===2)i=parseInt(s[0],10)*60+parseInt(s[1],10);else if(s.length===3)i=parseInt(s[0],10)*3600+parseInt(s[1],10)*60+parseInt(s[2],10);else if(s.length===1)i=parseInt(s[0],10);else return null;return t&&i!==0?-i:i}function hc(n){return n.dataLetter==="0"?{blank:!0,dataLetter:"0",letter:"",value:0}:{...n}}function dc(n,e,t){return t?[...n.filter(s=>s.dataLetter!=="128"),...e]:n}function Hr(n){return`${n.letter}|${n.blank}`}function fc(n,e){const t=new Map,s=new Map;for(const o of n){const a=Hr(o),l=t.get(a);l?l.count++:t.set(a,{tile:o,count:1})}for(const o of e){const a=Hr(o),l=s.get(a);l?l.count++:s.set(a,{tile:o,count:1})}const i=[],r=[];for(const[o,{tile:a,count:l}]of t){const c=s.get(o),f=c?c.count:0,d=l-f;if(d>0)for(let h=0;h<d;h++)i.push(a)}for(const[o,{tile:a,count:l}]of s){const c=t.get(o),f=c?c.count:0,d=l-f;if(d>0)for(let h=0;h<d;h++)r.push(a)}return{removed:i,added:r,unchanged:i.length===0&&r.length===0}}function pc(n,e){if(n.removed.length===0||typeof e!="number"||n.removed.length!==e||n.added.length!==e)return null;const s=n.removed.map(i=>i.blank?"?":(i.letter||"").toUpperCase()).join("");return/^[A-Z?]+$/.test(s)?s:null}const Br=/^[A-Z?]{1,7}$/;function us(n,e){return!n||!Br.test(n)?!1:typeof e!="number"||e===n.length}function mc(n,e){let t=null;const s=n.match(/EXCH\s*[\r\n]+([-\d]+)/);if(s){const a=parseInt(s[1],10);a<0&&(t=Math.abs(a))}const i=e.trim();if(t===null){const a=i.match(/^-(\d+)$/);a&&(t=parseInt(a[1],10))}let r=null;const o=i.match(/^-\s*([A-Z?]{1,7})$/);return o&&(r=o[1]),r&&(t===null?t=r.length:t!==r.length&&(r=null)),{count:t,letters:r}}function gc(n,e,t){let s=null;for(const i of n)i.gameId!==e||i.turnCount!==t||(!s||i.rack.length>=s.rack.length)&&(s=i);return s?s.rack:null}function _c(n,e,t){return typeof t!="number"||t<1||n.length===0||n.length!==e.length?null:pc(fc(n,e),t)}const yc=new Set(["EXCHANGE","4"]);function $r(n,e=0){if(e>3||n===null||typeof n!="object")return null;const t=n;if(Array.isArray(t.events))return t.events;for(const s of Object.values(t)){const i=$r(s,e+1);if(i)return i}return null}function Vr(n,e){const t=new Map;for(const s of n)t.set(s,(t.get(s)??0)+1);for(const s of e){const i=t.get(s)??0;if(i===0)return!1;t.set(s,i-1)}return!0}function vc(n,e,t,s,i){const r=$r(n);if(!r||e<1)return null;const o=r.filter(c=>{const f=String((c==null?void 0:c.type)??"").toUpperCase();return yc.has(f)&&typeof c.exchanged=="string"&&Br.test(c.exchanged)});if(o.length!==e)return null;const a=o[e-1].exchanged;if(!us(a,t))return null;const l=c=>c.map(f=>f.blank?"?":(f.letter||"").toUpperCase());if(s&&s.length>0){const c=l(s);if(!Vr(c,a.split("")))return null;const f=[...c];for(const d of a)f.splice(f.indexOf(d),1);if(!Vr(l(i),f))return null}return a}async function Ec(n,e=fetch){try{const t=await e("/api/game_service.GameMetadataService/GetGameHistory",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({gameId:n})});return t.ok?await t.json():null}catch{return null}}function jr(n){if(!n)return null;try{const e=new URL(n,"https://woogles.io");if(e.hostname!=="woogles.io"&&e.hostname!=="www.woogles.io")return null;const t=e.pathname.match(/^\/profile\/([^/]+)\/?$/i);return t?decodeURIComponent(t[1]):null}catch{return null}}function wc(n){const e=n.trim();if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(e))return null;const t=Number(e);return Number.isFinite(t)?t:null}function Sc(n,e,t=[]){return n.length!==2||e.length!==2||n.some(s=>!s.trim())?null:n.map((s,i)=>({name:s.trim(),scoreText:e[i],...t[i]?{username:t[i]}:{}}))}function hs(n){return n.normalize("NFKC").trim().replace(/\s+/g," ").toLowerCase()}function zr(n,e,t,s,i,r){const o=n.map(a=>{const l=hs(i(t[a]));return[a,l?e.filter(c=>hs(r(s[c]))===l):[]]});return o.flatMap(([a,l])=>{if(l.length!==1)return[];const c=l[0];return o.filter(([,d])=>d.includes(c)).length===1?[[a,c]]:[]})}function Cc(n,e){const t=new Map;let s=e.map((l,c)=>c),i=n.map((l,c)=>c);const r=zr(s,i,e,n,l=>l.username||l.name,l=>l.username);for(const[l,c]of r)t.set(l,c);s=s.filter(l=>!r.some(([c])=>c===l)),i=i.filter(l=>!r.some(([,c])=>c===l));const o=zr(s,i,e,n,l=>l.name,l=>l.name);for(const[l,c]of o)t.set(l,c);const a=n.map(()=>{});for(const[l,c]of t){const f=wc(e[l].scoreText);f!==null&&(a[c]=f)}return a}function Ic(n){const e=hs(n.username);if(e)return`username:${e}`;const t=hs(n.name);return t?`name:${t}`:null}function Kr(){const n=new Map;let e=null;return(t,s)=>{const i=t.map(Ic);if(i.length===2&&i.every(Boolean)&&new Set(i).size===2){const o=[...i].sort().join("|");e!==null&&e!==o&&n.clear(),e=o}return s&&Cc(t,s).forEach((a,l)=>{const c=i[l];a!==void 0&&c&&n.set(c,a)}),i.map((o,a)=>{if(!(!o||i.filter(l=>l===o).length!==1))return n.get(o)})}}function dg(n,e){}function bc(){let n=!1,e=null,t=null,s=null,i=0,r=null,o=null;const a=new Set;let l=null,c=null,f=[];const d=new Map;let h=null,y=null,E=null,x=null,j=0;const Y=new Map,de=new Set,ue=new Set;let ge=[],_t=Kr(),_e="",Le=null;const $e=[".pool-section .letter-group","#unseenTiles .letter-group","#unseenTiles",".unseen-tiles .letter",".unseenTiles .letter",".tile-pool .tile"];function st(){var b,k;const m=$e.map(O=>Array.from(document.querySelectorAll(O)).filter(F=>!F.closest('.ant-modal-root, .ant-modal, [role="dialog"]'))).find(O=>O.length>0),_=m?m.map(O=>{var F;return((F=O.textContent)==null?void 0:F.trim())||""}).filter(Boolean):[],I=Array.from(document.querySelectorAll(".ant-card-head-title")).map(O=>{var F;return((F=O.textContent)==null?void 0:F.trim())||""}),R=((b=document.querySelector(".vc-distribution"))==null?void 0:b.textContent)||"",A=I.find(O=>/\d+\s+tiles?/i.test(O))||"",T=O=>{const F=R.match(O);return F?Number(F[1]):null};return{unseenTiles:_,tilesInBag:A?Number((k=A.match(/(\d+)\s+tiles?/i))==null?void 0:k[1]):null,vowels:T(/(\d+)\s*vowel/i),consonants:T(/(\d+)\s*consonant/i)}}function dt(m){return m.filter(I=>I.tentative).map(I=>`${I.coordinate}:${I.letter}:${I.blank?"1":"0"}`).sort().join("|")}function Ge(m){e=m,m.connectionStatus,m.gameStatus,m.activePlayer,m.turnHistory.length,m.latestMove,console.log("[PULSE] READER EMIT",{gameStatus:m.gameStatus,activePlayer:m.activePlayer,turnCount:m.turnHistory.length,player1:m.players.player1.name||m.players.player1.username,player2:m.players.player2.name||m.players.player2.username,boardTiles:m.board.length,rackTiles:m.rack.length}),a.forEach(_=>_(m))}function qt(){e&&e.error&&Ge({...e,error:null})}function $(){h&&window.clearTimeout(h),h=window.setTimeout(()=>{h=null,console.log("[PULSE] RECONCILIATION CHECK");const m=Ie(),_=dt(m.board),I=!y||JSON.stringify(y.players)!==JSON.stringify(m.players)||JSON.stringify(y.board)!==JSON.stringify(m.board)||JSON.stringify(y.turnHistory)!==JSON.stringify(m.turnHistory),R=E!==_;(I||R)&&(console.log("[PULSE] RECONCILIATION STATE CHANGE DETECTED",{stateChanged:I,tentativeChanged:R,tentativeFingerprint:_}),y=m,E=_,Ge(m)),$()},500)}function J(){h&&(window.clearTimeout(h),h=null),y=null,E=null}function me(){var _;console.log("[PULSE] INITIAL STATE READ");const m=Ie();Ge(m),console.log("[PULSE] INITIAL STATE READ COMPLETE",{gameId:(_=m.session)==null?void 0:_.gameId,players:{player1:{name:m.players.player1.name||m.players.player1.username||"",username:m.players.player1.username||"",isActive:m.players.player1.isActive},player2:{name:m.players.player2.name||m.players.player2.username||"",username:m.players.player2.username||"",isActive:m.players.player2.isActive}},turnCount:m.turnHistory.length,boardTiles:m.board.length})}function re(m){return jr(m)??""}function p(){const m=document.querySelector(".streak-widget");if(!m)return Le!==!1&&console.info("[WPULSE MATCH SCORE] .streak-widget is unavailable; retaining only readings already tied to the same player identities"),Le=!1,_e="",null;Le=!0;const _=Array.from(m.querySelectorAll(".ant-col-6 p")),I=Array.from(m.querySelectorAll(".ant-col-2 p")),R=_.map(k=>{var O;return((O=k.textContent)==null?void 0:O.trim())??""}),A=I.map(k=>{var O;return((O=k.textContent)==null?void 0:O.trim())??""}),T=_.map(k=>{const O=k.closest(".ant-col-6"),F=[...k.closest("a[href]")?[k.closest("a[href]")]:[],...Array.from((O==null?void 0:O.querySelectorAll("a[href]"))??[])];for(const fe of F){const H=jr(fe.getAttribute("href"));if(H)return H}return null}),b=Sc(R,A,T);if(!b){const k=`malformed:${R.length}:${A.length}:${R.join("|")}`;return k!==_e&&(console.warn("[WPULSE MATCH SCORE] Streak widget found but its two name/score columns could not be paired",{nameCount:R.length,scoreCount:A.length,names:R}),_e=k),null}return b}function v(){const m=document.querySelectorAll(".player-card"),_=new Map;m.forEach(T=>{var yt,vn,Lt,Dt;const b=T.querySelector(".player-name"),k=((yt=b==null?void 0:b.textContent)==null?void 0:yt.trim())||"",O=T.querySelector(".player-details a"),F=(O==null?void 0:O.getAttribute("href"))||"",fe=re(F),H=T.querySelector(".player-details"),ve=(((vn=H==null?void 0:H.textContent)==null?void 0:vn.trim())||"").match(/(\d+)/),be=ve?parseInt(ve[1],10):0,Ee=T.querySelector(".score"),De=Ee?parseInt(((Lt=Ee.textContent)==null?void 0:Lt.trim())||"0",10):0,Te=fe||k||`player-${_.size}`,ot=T.querySelector(".timer"),at=Gr(((Dt=ot==null?void 0:ot.textContent)==null?void 0:Dt.trim())||"");let Me;at!==null?(Me=at,d.set(Te,at)):Me=d.get(Te)??0;const qe=T.classList.contains("on-turn");_.set(Te,{name:k,username:fe,rating:be,score:De,clock:Me,slot:"player1",isActive:qe})});const I=Array.from(_.values()),R=p(),A=_t(I,R);if(R&&A.some(T=>T===void 0)){const T=`unmatched:${R.map(b=>`${b.username??""}:${b.name}`).join("|")}:${I.map(b=>`${b.username}:${b.name}`).join("|")}`;T!==_e&&(console.warn("[WPULSE MATCH SCORE] One or more streak widget entries could not produce a unique numeric player match; unmatched scores are omitted",{widgetPlayers:R.map(({name:b,username:k,scoreText:O})=>({name:b,username:k??null,scoreText:O})),gamePlayers:I.map(({name:b,username:k})=>({name:b,username:k}))}),_e=T)}else R&&(_e="");return I.map((T,b)=>{const k=A[b];return k===void 0?T:{...T,matchScore:k}})}function P(m){const _=m.find(I=>I.isActive);return _&&(_.slot==="player1"||_.slot==="player2")?_.slot:null}function M(m){const _=["player1","player2"],I=[s==null?void 0:s.username,t==null?void 0:t.wooglesUsername].filter(R=>!!R);for(const R of I){const A=R.trim().toLowerCase(),T=_.find(b=>m[b].username.trim().toLowerCase()===A);if(T)return T}return null}function te(){const m=document.querySelector(".rack#rack");if(!m)return[];const _=[];return m.querySelectorAll(".tile").forEach(R=>{var ce,ve;const A=R.querySelector(".rune span"),T=((ce=A==null?void 0:A.textContent)==null?void 0:ce.trim())||"",b=R.querySelector(".point-value"),k=b?parseInt(((ve=b.textContent)==null?void 0:ve.trim())||"0",10):0,O=R.getAttribute("data-letter")||T;let fe=R.classList.contains("blank")||O==="0"&&k===0&&!!A,H=T;_.push({letter:H,value:k,dataLetter:O,blank:fe})}),_}function le(m){var R,A;if(!m)return[];const _=document.querySelector(".tiles");if(!_)return[];const I=[];for(const T of Array.from(_.children)){const b=T.querySelector(".tile.tentative");if(!b)continue;const k=b.classList.contains("tile-p0"),O=b.classList.contains("tile-p1");if((k?"player1":O?"player2":null)!==m)continue;const fe=b.querySelector(".rune span"),H=((R=fe==null?void 0:fe.textContent)==null?void 0:R.trim())||"",ce=b.querySelector(".point-value"),ve=ce?parseInt(((A=ce.textContent)==null?void 0:A.trim())||"0",10):0,be=b.getAttribute("data-letter")||H,Ee=b.classList.contains("blank");I.push(hc({letter:H,value:ve,dataLetter:be,blank:Ee}))}return I}function N(m){const _=Math.floor(m/15)+1,I=m%15+1;return`${String.fromCharCode(64+I)}${_}`}function X(m){var A,T;const _=document.querySelector(".tiles");if(!_)return[];const I=_.children,R=[];for(let b=0;b<I.length;b++){const k=I[b],O=!k.classList.contains("empty-space"),F=Math.floor(b/15)+1,fe=b%15+1;if(!O)continue;const H=k.querySelector(".tile");if(!H)continue;const ce=H.querySelector(".rune span"),ve=((A=ce==null?void 0:ce.textContent)==null?void 0:A.trim())||"",be=H.querySelector(".point-value"),Ee=be?parseInt(((T=be.textContent)==null?void 0:T.trim())||"0",10):0;H.getAttribute("data-letter");let Te=H.classList.contains("blank"),ot=ve;const at=H.classList.contains("tentative");let Me=null;if(H.classList.contains("tile-p0")?Me="player1":H.classList.contains("tile-p1")&&(Me="player2"),at&&m&&Me&&Me!==m)continue;const qe=H.classList.contains("last-played"),yt=N(b);R.push({row:F,column:fe,coordinate:yt,letter:ot,value:Ee,player:Me,blank:Te,tentative:at,lastPlayed:qe})}return R}function z(m){if(!m)return{base:0,change:0,bonus:null};const _=m.match(/(\d+)\s*\+\s*(\d+)/);if(_)return{base:0,change:parseInt(_[1],10),bonus:parseInt(_[2],10)};const I=m.match(/(\d+)/);return I?{base:0,change:parseInt(I[1],10),bonus:null}:{base:0,change:0,bonus:null}}function Ve(){const m=document.querySelectorAll(".turn"),_=[];return m.forEach((I,R)=>{var si,ii,ri,oi,En,as;const A=I.querySelector(".coord"),T=((si=A==null?void 0:A.textContent)==null?void 0:si.trim())||"",b=I.querySelector(".play .main-word"),k=((ii=b==null?void 0:b.textContent)==null?void 0:ii.trim())||"",O=((ri=I.textContent)==null?void 0:ri.trim())||"",F=O.includes("EXCH"),fe=k.toLowerCase()==="passed turn";let H="play",ce=k,ve=null,be=null;if(F){H="exchange",ce=null;const wn=mc(O,k);ve=wn.count,be=wn.letters}else fe?(H="pass",ce="Passed turn"):H="play";const Ee=I.querySelector(".scores .score-change"),De=((oi=Ee==null?void 0:Ee.textContent)==null?void 0:oi.trim())||"",Te=(De.match(/[+-]\s*\d+/g)??[]).map(wn=>parseInt(wn.replace(/\s+/g,""),10)),ot=Te.length>0?Te[0]:F||fe?0:z(De).change,at=Te.length>1?Te[1]:null;/challeng/i.test(O)&&console.log("[WPULSE CHALLENGE SCORE]",{scoreText:De,signed:Te});const Me=I.querySelector(".scores .cumulative"),qe=Me?parseInt(((En=Me.textContent)==null?void 0:En.trim())||"0",10):0,yt=I.querySelector(".time-left"),vn=yt?Gr(((as=yt.textContent)==null?void 0:as.trim())||"0:00"):null,Lt=R%2===0?"player1":"player2",Dt=je(I,O),os=H==="play"&&!!k&&De!==""&&ot===0,ti=Dt.challengeResult??(os?"off":null),ni=Dt.challengeBonus??(ti==="stayed"?at:null);_.push({turnNumber:R+1,player:Lt,type:H,coordinate:fe||F?null:T||null,word:ce,tilesExchanged:ve,exchangedTiles:be,time:vn,scoreChange:ot,cumulativeScore:qe,isPass:fe,challengeResult:ti,challengeBonus:ni})}),_}function je(m,_){const I=_.replace(/\s+/g," ");/challeng/i.test(I)&&console.log("[WPULSE CHALLENGE TURN]",I.slice(0,200));const R=/challenge!?\s*invalid|challenged?\s*off|phony/i.test(I),A=!R&&/challenge!?\s*valid|challenge\s*bonus/i.test(I),T=I.match(/challenge\s*bonus\D{0,12}(\d+)/i);return{challengeResult:R?"off":A?"stayed":null,challengeBonus:A&&T?Number(T[1]):null}}function Z(m,_,I){const R=r;if(!R)return;ge.length>0&&ge[0].gameId!==R&&(ge=[]);for(const T of m){if(T.type!=="exchange")continue;const b=`${R}|${T.turnNumber}`;T.exchangedTiles&&us(T.exchangedTiles,T.tilesExchanged)&&Y.set(b,T.exchangedTiles)}const A=m[m.length-1];if(A&&A.type==="exchange"&&I&&A.player===I&&_.length>0){const T=`${R}|${A.turnNumber}`;if(!Y.has(T)){const b=gc(ge,R,m.length-1),k=b?_c(b,_,A.tilesExchanged):null;if(k)Y.set(T,k),console.log("[WPULSE EXCHANGE LETTERS]",{key:T,letters:k,source:"rack-comparison"});else{ue.has(T)||(ue.add(T),console.log("[WPULSE EXCHANGE LETTERS]",{key:T,letters:null,reason:"rack comparison does not account for every exchanged tile",tilesExchanged:A.tilesExchanged,before:b?b.map(F=>F.blank?"?":F.letter).join(""):null,after:_.map(F=>F.blank?"?":F.letter).join("")}));const O=m.filter(F=>F.type==="exchange"&&F.player===I).length;rt(R,T,O,A.tilesExchanged,b,_)}}}for(const T of m)T.exchangedTiles=T.type==="exchange"?Y.get(`${R}|${T.turnNumber}`)??null:null;if(_.length>0){const T=_.map(k=>k.blank?"?":k.letter).sort().join(""),b=ge[ge.length-1];(!b||b.turnCount!==m.length||b.fingerprint!==T)&&(ge.push({gameId:R,turnCount:m.length,fingerprint:T,rack:_.map(k=>({...k}))}),ge.length>8&&ge.shift())}}const it=3,ze=1500;async function rt(m,_,I,R,A,T){if(!(de.has(_)||Y.has(_))){de.add(_);for(let b=0;b<it;b++){if(!n||r!==m||Y.has(_))return;const k=await Ec(m),O=vc(k,I,R,A,T);if(O){Y.set(_,O),console.log("[WPULSE EXCHANGE LETTERS]",{key:_,letters:O,source:"game-history"}),n&&Ge(Ie());return}await new Promise(F=>window.setTimeout(F,ze))}console.log("[WPULSE EXCHANGE LETTERS]",{key:_,letters:null,reason:"game history gave no usable letters"})}}function Ke(m){if(m.length===0)return null;const _=m[m.length-1],I=`${r??""}|${JSON.stringify({turnNumber:_.turnNumber,player:_.player,type:_.type,coordinate:_.coordinate,word:_.word,scoreChange:_.scoreChange,cumulativeScore:_.cumulativeScore,isPass:_.isPass})}`;return I!==x&&(x=I,j=Date.now()),{turnNumber:_.turnNumber,player:_.player,type:_.type,coordinate:_.coordinate,word:_.word,tilesExchanged:_.tilesExchanged,exchangedTiles:_.exchangedTiles??null,scoreChange:_.scoreChange,cumulativeScore:_.cumulativeScore,isPass:_.isPass,timestamp:j}}function K(){const m=document.querySelectorAll(".player-card").length>0,_=document.querySelector(".tiles")!==null,I=document.querySelectorAll(".turn").length>0;return!m&&!_?"idle":m&&I||m&&_?"active":"detecting"}function He(){const m=window.location.href,_=uc(m);if(!_)return null;if(r===null)r=_.gameId,o=_.detectedAt;else if(r!==_.gameId){const I=r;r=_.gameId,o=_.detectedAt,d.clear(),_t=Kr(),console.log("[PULSE] SESSION CHANGED",{from:I,to:_.gameId})}return{..._,detectedAt:o??_.detectedAt}}function Ie(){qt();const m=He(),_=v(),I=(t==null?void 0:t.wooglesUsername)??null,{player1:R,player2:A}=cc(_),T=P([R,A]),b=M({player1:R,player2:A}),k=(s==null?void 0:s.username)??I,O=T!==null&&b!==null&&T===b,F=te(),fe=X(T),H=Ve(),ce=K(),ve=T!==null&&b!==null&&!O&&ce!=="finished",be=ve?le(b):[],Ee=dc(F,be,ve);console.log("[WPULSE RACK DEBUG]",{localPlayerUsername:k,activePlayer:T,localPlayerSlot:b,localPlayerIsActive:O,domRackLength:F.length,gameStatus:ce,selectedRackLength:Ee.length,restoredTentativeCount:be.length}),Z(H,Ee,b);const De=Ke(H),Te=st();return{...e||{connectionStatus:"connected",gameStatus:ce,players:{player1:R,player2:A},broadcastPlayers:{left:null,right:null},activePlayer:T,rack:Ee,board:fe,turnHistory:H,latestMove:De,lastStateRead:null,lastFirebasePublish:null,lastDataUpdateTimestamp:null,extensionHeartbeats:{},error:null,session:null,confirmedAssignment:t,...Te,playerRacks:{},playerRackMeta:{},tileMovements:[]},gameStatus:ce,players:{player1:R,player2:A},activePlayer:T,rack:Ee,board:fe,turnHistory:H,latestMove:De,lastStateRead:Date.now(),session:m,confirmedAssignment:t,...Te}}function Ot(){const m=document.documentElement;m&&(c=new MutationObserver(_=>{let I=!1;for(const R of _){if(R.type==="childList"&&R.addedNodes.length>0){I=!0;break}if(R.type==="childList"&&R.removedNodes.length>0){I=!0;break}if(R.type==="characterData"){I=!0;break}if(R.type==="attributes"){I=!0;break}}I&&(l&&window.clearTimeout(l),l=window.setTimeout(()=>{l=null,console.log("[PULSE] MUTATION OBSERVER TRIGGERED — reading state");const R=Ie(),A=R.turnHistory.length;A>i?(console.log("[PULSE] NEW TURN DETECTED",{from:i,to:A}),i=A,Ge(R)):e?(console.log("[PULSE] STATE UPDATE — turn count unchanged, emitting updated state"),Ge(R)):(console.log("[PULSE] FIRST STATE EMIT"),Ge(R))},16))}),c.observe(m,{childList:!0,subtree:!0,characterData:!0,attributes:!0,attributeFilter:["class","data-bnjy"]}))}return{async connect(){n=!0,console.log("[PULSE] READER CONNECTING"),t=await Ur(),me();const m=Ie();i=m.turnHistory.length,console.log("[PULSE] READER CONNECTED",{status:m.gameStatus,players:m.players.player1.username||m.players.player1.name,turnCount:i,confirmedIdentity:(t==null?void 0:t.wooglesUsername)??null}),Ge(m),Ot(),$(),m.gameStatus,m.players.player1.username||m.players.player1.name},disconnect(){n=!1,c&&(c.disconnect(),c=null),l&&(window.clearTimeout(l),l=null),J(),f.forEach(m=>m()),f=[]},getState(){if(!e)throw new Error("Reader not initialized. Call connect() first.");return e},getDetectedPlayers(){if(!e)return[];const m=[];for(const _ of[e.players.player1,e.players.player2])!_.username&&!_.name||m.push({username:_.username||"",name:_.name||"",isActive:_.isActive});return m},getConfirmedUsername(){return(t==null?void 0:t.wooglesUsername)??null},getAutomaticIdentity(){return s},async refreshAutomaticIdentity(m=!1){return s=await ac(m),s},refreshState(){n&&Ge(Ie())},async refreshConfirmedAssignment(){t=await Ur(),console.log("[PULSE] CONFIRMED ASSIGNMENT REFRESHED",{confirmedIdentity:(t==null?void 0:t.wooglesUsername)??null})},onStateChange(m){return a.add(m),()=>a.delete(m)}}}const Tc=()=>{};var qr={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Yr={NODE_ADMIN:!1,SDK_VERSION:"${JSCORE_VERSION}"};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const w=function(n,e){if(!n)throw Xt(e)},Xt=function(n){return new Error("Firebase Database ("+Yr.SDK_VERSION+") INTERNAL ASSERT FAILED: "+n)};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qr=function(n){const e=[];let t=0;for(let s=0;s<n.length;s++){let i=n.charCodeAt(s);i<128?e[t++]=i:i<2048?(e[t++]=i>>6|192,e[t++]=i&63|128):(i&64512)===55296&&s+1<n.length&&(n.charCodeAt(s+1)&64512)===56320?(i=65536+((i&1023)<<10)+(n.charCodeAt(++s)&1023),e[t++]=i>>18|240,e[t++]=i>>12&63|128,e[t++]=i>>6&63|128,e[t++]=i&63|128):(e[t++]=i>>12|224,e[t++]=i>>6&63|128,e[t++]=i&63|128)}return e},Ac=function(n){const e=[];let t=0,s=0;for(;t<n.length;){const i=n[t++];if(i<128)e[s++]=String.fromCharCode(i);else if(i>191&&i<224){const r=n[t++];e[s++]=String.fromCharCode((i&31)<<6|r&63)}else if(i>239&&i<365){const r=n[t++],o=n[t++],a=n[t++],l=((i&7)<<18|(r&63)<<12|(o&63)<<6|a&63)-65536;e[s++]=String.fromCharCode(55296+(l>>10)),e[s++]=String.fromCharCode(56320+(l&1023))}else{const r=n[t++],o=n[t++];e[s++]=String.fromCharCode((i&15)<<12|(r&63)<<6|o&63)}}return e.join("")},ci={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,e){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,s=[];for(let i=0;i<n.length;i+=3){const r=n[i],o=i+1<n.length,a=o?n[i+1]:0,l=i+2<n.length,c=l?n[i+2]:0,f=r>>2,d=(r&3)<<4|a>>4;let h=(a&15)<<2|c>>6,y=c&63;l||(y=64,o||(h=64)),s.push(t[f],t[d],t[h],t[y])}return s.join("")},encodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(n):this.encodeByteArray(Qr(n),e)},decodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(n):Ac(this.decodeStringToByteArray(n,e))},decodeStringToByteArray(n,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,s=[];for(let i=0;i<n.length;){const r=t[n.charAt(i++)],a=i<n.length?t[n.charAt(i)]:0;++i;const c=i<n.length?t[n.charAt(i)]:64;++i;const d=i<n.length?t[n.charAt(i)]:64;if(++i,r==null||a==null||c==null||d==null)throw new Rc;const h=r<<2|a>>4;if(s.push(h),c!==64){const y=a<<4&240|c>>2;if(s.push(y),d!==64){const E=c<<6&192|d;s.push(E)}}}return s},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class Rc extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const Jr=function(n){const e=Qr(n);return ci.encodeByteArray(e,!0)},ds=function(n){return Jr(n).replace(/\./g,"")},fs=function(n){try{return ci.decodeString(n,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Pc(n){return Xr(void 0,n)}function Xr(n,e){if(!(e instanceof Object))return e;switch(e.constructor){case Date:const t=e;return new Date(t.getTime());case Object:n===void 0&&(n={});break;case Array:n=[];break;default:return e}for(const t in e)!e.hasOwnProperty(t)||!Nc(t)||(n[t]=Xr(n[t],e[t]));return n}function Nc(n){return n!=="__proto__"}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function kc(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Oc=()=>kc().__FIREBASE_DEFAULTS__,Lc=()=>{if(typeof process>"u"||typeof qr>"u")return;const n=qr.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},Dc=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=n&&fs(n[1]);return e&&JSON.parse(e)},Zr=()=>{try{return Tc()||Oc()||Lc()||Dc()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},xc=n=>{var e,t;return(t=(e=Zr())===null||e===void 0?void 0:e.emulatorHosts)===null||t===void 0?void 0:t[n]},Mc=n=>{const e=xc(n);if(!e)return;const t=e.lastIndexOf(":");if(t<=0||t+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const s=parseInt(e.substring(t+1),10);return e[0]==="["?[e.substring(1,t-1),s]:[e.substring(0,t),s]},eo=()=>{var n;return(n=Zr())===null||n===void 0?void 0:n.config};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zt{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,s)=>{t?this.reject(t):this.resolve(s),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,s))}}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function In(n){try{return(n.startsWith("http://")||n.startsWith("https://")?new URL(n).hostname:n).endsWith(".cloudworkstations.dev")}catch{return!1}}async function Fc(n){return(await fetch(n,{credentials:"include"})).ok}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Uc(n,e){if(n.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const t={alg:"none",type:"JWT"},s=e||"demo-project",i=n.iat||0,r=n.sub||n.user_id;if(!r)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const o=Object.assign({iss:`https://securetoken.google.com/${s}`,aud:s,iat:i,exp:i+3600,auth_time:i,sub:r,user_id:r,firebase:{sign_in_provider:"custom",identities:{}}},n);return[ds(JSON.stringify(t)),ds(JSON.stringify(o)),""].join(".")}const bn={};function Wc(){const n={prod:[],emulator:[]};for(const e of Object.keys(bn))bn[e]?n.emulator.push(e):n.prod.push(e);return n}function Gc(n){let e=document.getElementById(n),t=!1;return e||(e=document.createElement("div"),e.setAttribute("id",n),t=!0),{created:t,element:e}}let to=!1;function Hc(n,e){if(typeof window>"u"||typeof document>"u"||!In(window.location.host)||bn[n]===e||bn[n]||to)return;bn[n]=e;function t(h){return`__firebase__banner__${h}`}const s="__firebase__banner",r=Wc().prod.length>0;function o(){const h=document.getElementById(s);h&&h.remove()}function a(h){h.style.display="flex",h.style.background="#7faaf0",h.style.position="fixed",h.style.bottom="5px",h.style.left="5px",h.style.padding=".5em",h.style.borderRadius="5px",h.style.alignItems="center"}function l(h,y){h.setAttribute("width","24"),h.setAttribute("id",y),h.setAttribute("height","24"),h.setAttribute("viewBox","0 0 24 24"),h.setAttribute("fill","none"),h.style.marginLeft="-6px"}function c(){const h=document.createElement("span");return h.style.cursor="pointer",h.style.marginLeft="16px",h.style.fontSize="24px",h.innerHTML=" &times;",h.onclick=()=>{to=!0,o()},h}function f(h,y){h.setAttribute("id",y),h.innerText="Learn more",h.href="https://firebase.google.com/docs/studio/preview-apps#preview-backend",h.setAttribute("target","__blank"),h.style.paddingLeft="5px",h.style.textDecoration="underline"}function d(){const h=Gc(s),y=t("text"),E=document.getElementById(y)||document.createElement("span"),x=t("learnmore"),j=document.getElementById(x)||document.createElement("a"),Y=t("preprendIcon"),de=document.getElementById(Y)||document.createElementNS("http://www.w3.org/2000/svg","svg");if(h.created){const ue=h.element;a(ue),f(j,x);const ge=c();l(de,Y),ue.append(de,E,j,ge),document.body.appendChild(ue)}r?(E.innerText="Preview backend disconnected.",de.innerHTML=`<g clip-path="url(#clip0_6013_33858)">
<path d="M4.8 17.6L12 5.6L19.2 17.6H4.8ZM6.91667 16.4H17.0833L12 7.93333L6.91667 16.4ZM12 15.6C12.1667 15.6 12.3056 15.5444 12.4167 15.4333C12.5389 15.3111 12.6 15.1667 12.6 15C12.6 14.8333 12.5389 14.6944 12.4167 14.5833C12.3056 14.4611 12.1667 14.4 12 14.4C11.8333 14.4 11.6889 14.4611 11.5667 14.5833C11.4556 14.6944 11.4 14.8333 11.4 15C11.4 15.1667 11.4556 15.3111 11.5667 15.4333C11.6889 15.5444 11.8333 15.6 12 15.6ZM11.4 13.6H12.6V10.4H11.4V13.6Z" fill="#212121"/>
</g>
<defs>
<clipPath id="clip0_6013_33858">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>`):(de.innerHTML=`<g clip-path="url(#clip0_6083_34804)">
<path d="M11.4 15.2H12.6V11.2H11.4V15.2ZM12 10C12.1667 10 12.3056 9.94444 12.4167 9.83333C12.5389 9.71111 12.6 9.56667 12.6 9.4C12.6 9.23333 12.5389 9.09444 12.4167 8.98333C12.3056 8.86111 12.1667 8.8 12 8.8C11.8333 8.8 11.6889 8.86111 11.5667 8.98333C11.4556 9.09444 11.4 9.23333 11.4 9.4C11.4 9.56667 11.4556 9.71111 11.5667 9.83333C11.6889 9.94444 11.8333 10 12 10ZM12 18.4C11.1222 18.4 10.2944 18.2333 9.51667 17.9C8.73889 17.5667 8.05556 17.1111 7.46667 16.5333C6.88889 15.9444 6.43333 15.2611 6.1 14.4833C5.76667 13.7056 5.6 12.8778 5.6 12C5.6 11.1111 5.76667 10.2833 6.1 9.51667C6.43333 8.73889 6.88889 8.06111 7.46667 7.48333C8.05556 6.89444 8.73889 6.43333 9.51667 6.1C10.2944 5.76667 11.1222 5.6 12 5.6C12.8889 5.6 13.7167 5.76667 14.4833 6.1C15.2611 6.43333 15.9389 6.89444 16.5167 7.48333C17.1056 8.06111 17.5667 8.73889 17.9 9.51667C18.2333 10.2833 18.4 11.1111 18.4 12C18.4 12.8778 18.2333 13.7056 17.9 14.4833C17.5667 15.2611 17.1056 15.9444 16.5167 16.5333C15.9389 17.1111 15.2611 17.5667 14.4833 17.9C13.7167 18.2333 12.8889 18.4 12 18.4ZM12 17.2C13.4444 17.2 14.6722 16.6944 15.6833 15.6833C16.6944 14.6722 17.2 13.4444 17.2 12C17.2 10.5556 16.6944 9.32778 15.6833 8.31667C14.6722 7.30555 13.4444 6.8 12 6.8C10.5556 6.8 9.32778 7.30555 8.31667 8.31667C7.30556 9.32778 6.8 10.5556 6.8 12C6.8 13.4444 7.30556 14.6722 8.31667 15.6833C9.32778 16.6944 10.5556 17.2 12 17.2Z" fill="#212121"/>
</g>
<defs>
<clipPath id="clip0_6083_34804">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>`,E.innerText="Preview backend running in this workspace."),E.setAttribute("id",y)}document.readyState==="loading"?window.addEventListener("DOMContentLoaded",d):d()}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ct(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function ui(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(ct())}function Bc(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function $c(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function no(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function Vc(){return Yr.NODE_ADMIN===!0}function jc(){try{return typeof indexedDB=="object"}catch{return!1}}function zc(){return new Promise((n,e)=>{try{let t=!0;const s="validate-browser-context-for-indexeddb-analytics-module",i=self.indexedDB.open(s);i.onsuccess=()=>{i.result.close(),t||self.indexedDB.deleteDatabase(s),n(!0)},i.onupgradeneeded=()=>{t=!1},i.onerror=()=>{var r;e(((r=i.error)===null||r===void 0?void 0:r.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Kc="FirebaseError";class xt extends Error{constructor(e,t,s){super(t),this.code=e,this.customData=s,this.name=Kc,Object.setPrototypeOf(this,xt.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Tn.prototype.create)}}class Tn{constructor(e,t,s){this.service=e,this.serviceName=t,this.errors=s}create(e,...t){const s=t[0]||{},i=`${this.service}/${e}`,r=this.errors[e],o=r?qc(r,s):"Error",a=`${this.serviceName}: ${o} (${i}).`;return new xt(i,a,s)}}function qc(n,e){return n.replace(Yc,(t,s)=>{const i=e[s];return i!=null?String(i):`<${s}?>`})}const Yc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function An(n){return JSON.parse(n)}function we(n){return JSON.stringify(n)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const so=function(n){let e={},t={},s={},i="";try{const r=n.split(".");e=An(fs(r[0])||""),t=An(fs(r[1])||""),i=r[2],s=t.d||{},delete t.d}catch{}return{header:e,claims:t,data:s,signature:i}},Qc=function(n){const e=so(n),t=e.claims;return!!t&&typeof t=="object"&&t.hasOwnProperty("iat")},Jc=function(n){const e=so(n).claims;return typeof e=="object"&&e.admin===!0};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xe(n,e){return Object.prototype.hasOwnProperty.call(n,e)}function Mt(n,e){if(Object.prototype.hasOwnProperty.call(n,e))return n[e]}function io(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}function ps(n,e,t){const s={};for(const i in n)Object.prototype.hasOwnProperty.call(n,i)&&(s[i]=e.call(t,n[i],i,n));return s}function Rn(n,e){if(n===e)return!0;const t=Object.keys(n),s=Object.keys(e);for(const i of t){if(!s.includes(i))return!1;const r=n[i],o=e[i];if(ro(r)&&ro(o)){if(!Rn(r,o))return!1}else if(r!==o)return!1}for(const i of s)if(!t.includes(i))return!1;return!0}function ro(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hi(n){const e=[];for(const[t,s]of Object.entries(n))Array.isArray(s)?s.forEach(i=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(i))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(s));return e.length?"&"+e.join("&"):""}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xc{constructor(){this.chain_=[],this.buf_=[],this.W_=[],this.pad_=[],this.inbuf_=0,this.total_=0,this.blockSize=512/8,this.pad_[0]=128;for(let e=1;e<this.blockSize;++e)this.pad_[e]=0;this.reset()}reset(){this.chain_[0]=1732584193,this.chain_[1]=4023233417,this.chain_[2]=2562383102,this.chain_[3]=271733878,this.chain_[4]=3285377520,this.inbuf_=0,this.total_=0}compress_(e,t){t||(t=0);const s=this.W_;if(typeof e=="string")for(let d=0;d<16;d++)s[d]=e.charCodeAt(t)<<24|e.charCodeAt(t+1)<<16|e.charCodeAt(t+2)<<8|e.charCodeAt(t+3),t+=4;else for(let d=0;d<16;d++)s[d]=e[t]<<24|e[t+1]<<16|e[t+2]<<8|e[t+3],t+=4;for(let d=16;d<80;d++){const h=s[d-3]^s[d-8]^s[d-14]^s[d-16];s[d]=(h<<1|h>>>31)&4294967295}let i=this.chain_[0],r=this.chain_[1],o=this.chain_[2],a=this.chain_[3],l=this.chain_[4],c,f;for(let d=0;d<80;d++){d<40?d<20?(c=a^r&(o^a),f=1518500249):(c=r^o^a,f=1859775393):d<60?(c=r&o|a&(r|o),f=2400959708):(c=r^o^a,f=3395469782);const h=(i<<5|i>>>27)+c+l+f+s[d]&4294967295;l=a,a=o,o=(r<<30|r>>>2)&4294967295,r=i,i=h}this.chain_[0]=this.chain_[0]+i&4294967295,this.chain_[1]=this.chain_[1]+r&4294967295,this.chain_[2]=this.chain_[2]+o&4294967295,this.chain_[3]=this.chain_[3]+a&4294967295,this.chain_[4]=this.chain_[4]+l&4294967295}update(e,t){if(e==null)return;t===void 0&&(t=e.length);const s=t-this.blockSize;let i=0;const r=this.buf_;let o=this.inbuf_;for(;i<t;){if(o===0)for(;i<=s;)this.compress_(e,i),i+=this.blockSize;if(typeof e=="string"){for(;i<t;)if(r[o]=e.charCodeAt(i),++o,++i,o===this.blockSize){this.compress_(r),o=0;break}}else for(;i<t;)if(r[o]=e[i],++o,++i,o===this.blockSize){this.compress_(r),o=0;break}}this.inbuf_=o,this.total_+=t}digest(){const e=[];let t=this.total_*8;this.inbuf_<56?this.update(this.pad_,56-this.inbuf_):this.update(this.pad_,this.blockSize-(this.inbuf_-56));for(let i=this.blockSize-1;i>=56;i--)this.buf_[i]=t&255,t/=256;this.compress_(this.buf_);let s=0;for(let i=0;i<5;i++)for(let r=24;r>=0;r-=8)e[s]=this.chain_[i]>>r&255,++s;return e}}function Zc(n,e){const t=new eu(n,e);return t.subscribe.bind(t)}class eu{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(s=>{this.error(s)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,s){let i;if(e===void 0&&t===void 0&&s===void 0)throw new Error("Missing Observer.");tu(e,["next","error","complete"])?i=e:i={next:e,error:t,complete:s},i.next===void 0&&(i.next=di),i.error===void 0&&(i.error=di),i.complete===void 0&&(i.complete=di);const r=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?i.error(this.finalError):i.complete()}catch{}}),this.observers.push(i),r}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(s){typeof console<"u"&&console.error&&console.error(s)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function tu(n,e){if(typeof n!="object"||n===null)return!1;for(const t of e)if(t in n&&typeof n[t]=="function")return!0;return!1}function di(){}function ms(n,e){return`${n} failed: ${e} argument `}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nu=function(n){const e=[];let t=0;for(let s=0;s<n.length;s++){let i=n.charCodeAt(s);if(i>=55296&&i<=56319){const r=i-55296;s++,w(s<n.length,"Surrogate pair missing trail surrogate.");const o=n.charCodeAt(s)-56320;i=65536+(r<<10)+o}i<128?e[t++]=i:i<2048?(e[t++]=i>>6|192,e[t++]=i&63|128):i<65536?(e[t++]=i>>12|224,e[t++]=i>>6&63|128,e[t++]=i&63|128):(e[t++]=i>>18|240,e[t++]=i>>12&63|128,e[t++]=i>>6&63|128,e[t++]=i&63|128)}return e},gs=function(n){let e=0;for(let t=0;t<n.length;t++){const s=n.charCodeAt(t);s<128?e++:s<2048?e+=2:s>=55296&&s<=56319?(e+=4,t++):e+=3}return e};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Fe(n){return n&&n._delegate?n._delegate:n}class Ft{constructor(e,t,s){this.name=e,this.instanceFactory=t,this.type=s,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ut="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class su{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const s=new Zt;if(this.instancesDeferred.set(t,s),this.isInitialized(t)||this.shouldAutoInitialize())try{const i=this.getOrInitializeService({instanceIdentifier:t});i&&s.resolve(i)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){var t;const s=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),i=(t=e==null?void 0:e.optional)!==null&&t!==void 0?t:!1;if(this.isInitialized(s)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:s})}catch(r){if(i)return null;throw r}else{if(i)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(ru(e))try{this.getOrInitializeService({instanceIdentifier:Ut})}catch{}for(const[t,s]of this.instancesDeferred.entries()){const i=this.normalizeInstanceIdentifier(t);try{const r=this.getOrInitializeService({instanceIdentifier:i});s.resolve(r)}catch{}}}}clearInstance(e=Ut){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=Ut){return this.instances.has(e)}getOptions(e=Ut){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,s=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(s))throw Error(`${this.name}(${s}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const i=this.getOrInitializeService({instanceIdentifier:s,options:t});for(const[r,o]of this.instancesDeferred.entries()){const a=this.normalizeInstanceIdentifier(r);s===a&&o.resolve(i)}return i}onInit(e,t){var s;const i=this.normalizeInstanceIdentifier(t),r=(s=this.onInitCallbacks.get(i))!==null&&s!==void 0?s:new Set;r.add(e),this.onInitCallbacks.set(i,r);const o=this.instances.get(i);return o&&e(o,i),()=>{r.delete(e)}}invokeOnInitCallbacks(e,t){const s=this.onInitCallbacks.get(t);if(s)for(const i of s)try{i(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let s=this.instances.get(e);if(!s&&this.component&&(s=this.component.instanceFactory(this.container,{instanceIdentifier:iu(e),options:t}),this.instances.set(e,s),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(s,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,s)}catch{}return s||null}normalizeInstanceIdentifier(e=Ut){return this.component?this.component.multipleInstances?e:Ut:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function iu(n){return n===Ut?void 0:n}function ru(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ou{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new su(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oo=[];var ne;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(ne||(ne={}));const au={debug:ne.DEBUG,verbose:ne.VERBOSE,info:ne.INFO,warn:ne.WARN,error:ne.ERROR,silent:ne.SILENT},lu=ne.INFO,cu={[ne.DEBUG]:"log",[ne.VERBOSE]:"log",[ne.INFO]:"info",[ne.WARN]:"warn",[ne.ERROR]:"error"},uu=(n,e,...t)=>{if(e<n.logLevel)return;const s=new Date().toISOString(),i=cu[e];if(i)console[i](`[${s}]  ${n.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class fi{constructor(e){this.name=e,this._logLevel=lu,this._logHandler=uu,this._userLogHandler=null,oo.push(this)}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in ne))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?au[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,ne.DEBUG,...e),this._logHandler(this,ne.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,ne.VERBOSE,...e),this._logHandler(this,ne.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,ne.INFO,...e),this._logHandler(this,ne.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,ne.WARN,...e),this._logHandler(this,ne.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,ne.ERROR,...e),this._logHandler(this,ne.ERROR,...e)}}function hu(n){oo.forEach(e=>{e.setLogLevel(n)})}const du=(n,e)=>e.some(t=>n instanceof t);let ao,lo;function fu(){return ao||(ao=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function pu(){return lo||(lo=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const co=new WeakMap,pi=new WeakMap,uo=new WeakMap,mi=new WeakMap,gi=new WeakMap;function mu(n){const e=new Promise((t,s)=>{const i=()=>{n.removeEventListener("success",r),n.removeEventListener("error",o)},r=()=>{t(wt(n.result)),i()},o=()=>{s(n.error),i()};n.addEventListener("success",r),n.addEventListener("error",o)});return e.then(t=>{t instanceof IDBCursor&&co.set(t,n)}).catch(()=>{}),gi.set(e,n),e}function gu(n){if(pi.has(n))return;const e=new Promise((t,s)=>{const i=()=>{n.removeEventListener("complete",r),n.removeEventListener("error",o),n.removeEventListener("abort",o)},r=()=>{t(),i()},o=()=>{s(n.error||new DOMException("AbortError","AbortError")),i()};n.addEventListener("complete",r),n.addEventListener("error",o),n.addEventListener("abort",o)});pi.set(n,e)}let _i={get(n,e,t){if(n instanceof IDBTransaction){if(e==="done")return pi.get(n);if(e==="objectStoreNames")return n.objectStoreNames||uo.get(n);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return wt(n[e])},set(n,e,t){return n[e]=t,!0},has(n,e){return n instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in n}};function _u(n){_i=n(_i)}function yu(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const s=n.call(yi(this),e,...t);return uo.set(s,e.sort?e.sort():[e]),wt(s)}:pu().includes(n)?function(...e){return n.apply(yi(this),e),wt(co.get(this))}:function(...e){return wt(n.apply(yi(this),e))}}function vu(n){return typeof n=="function"?yu(n):(n instanceof IDBTransaction&&gu(n),du(n,fu())?new Proxy(n,_i):n)}function wt(n){if(n instanceof IDBRequest)return mu(n);if(mi.has(n))return mi.get(n);const e=vu(n);return e!==n&&(mi.set(n,e),gi.set(e,n)),e}const yi=n=>gi.get(n);function Eu(n,e,{blocked:t,upgrade:s,blocking:i,terminated:r}={}){const o=indexedDB.open(n,e),a=wt(o);return s&&o.addEventListener("upgradeneeded",l=>{s(wt(o.result),l.oldVersion,l.newVersion,wt(o.transaction),l)}),t&&o.addEventListener("blocked",l=>t(l.oldVersion,l.newVersion,l)),a.then(l=>{r&&l.addEventListener("close",()=>r()),i&&l.addEventListener("versionchange",c=>i(c.oldVersion,c.newVersion,c))}).catch(()=>{}),a}const wu=["get","getKey","getAll","getAllKeys","count"],Su=["put","add","delete","clear"],vi=new Map;function ho(n,e){if(!(n instanceof IDBDatabase&&!(e in n)&&typeof e=="string"))return;if(vi.get(e))return vi.get(e);const t=e.replace(/FromIndex$/,""),s=e!==t,i=Su.includes(t);if(!(t in(s?IDBIndex:IDBObjectStore).prototype)||!(i||wu.includes(t)))return;const r=async function(o,...a){const l=this.transaction(o,i?"readwrite":"readonly");let c=l.store;return s&&(c=c.index(a.shift())),(await Promise.all([c[t](...a),i&&l.done]))[0]};return vi.set(e,r),r}_u(n=>({...n,get:(e,t,s)=>ho(e,t)||n.get(e,t,s),has:(e,t)=>!!ho(e,t)||n.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cu{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(Iu(t)){const s=t.getImmediate();return`${s.library}/${s.version}`}else return null}).filter(t=>t).join(" ")}}function Iu(n){const e=n.getComponent();return(e==null?void 0:e.type)==="VERSION"}const Ei="@firebase/app",fo="0.13.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ft=new fi("@firebase/app"),bu="@firebase/app-compat",Tu="@firebase/analytics-compat",Au="@firebase/analytics",Ru="@firebase/app-check-compat",Pu="@firebase/app-check",Nu="@firebase/auth",ku="@firebase/auth-compat",Ou="@firebase/database",Lu="@firebase/data-connect",Du="@firebase/database-compat",xu="@firebase/functions",Mu="@firebase/functions-compat",Fu="@firebase/installations",Uu="@firebase/installations-compat",Wu="@firebase/messaging",Gu="@firebase/messaging-compat",Hu="@firebase/performance",Bu="@firebase/performance-compat",$u="@firebase/remote-config",Vu="@firebase/remote-config-compat",ju="@firebase/storage",zu="@firebase/storage-compat",Ku="@firebase/firestore",qu="@firebase/ai",Yu="@firebase/firestore-compat",Qu="firebase",Ju="11.10.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wi="[DEFAULT]",Xu={[Ei]:"fire-core",[bu]:"fire-core-compat",[Au]:"fire-analytics",[Tu]:"fire-analytics-compat",[Pu]:"fire-app-check",[Ru]:"fire-app-check-compat",[Nu]:"fire-auth",[ku]:"fire-auth-compat",[Ou]:"fire-rtdb",[Lu]:"fire-data-connect",[Du]:"fire-rtdb-compat",[xu]:"fire-fn",[Mu]:"fire-fn-compat",[Fu]:"fire-iid",[Uu]:"fire-iid-compat",[Wu]:"fire-fcm",[Gu]:"fire-fcm-compat",[Hu]:"fire-perf",[Bu]:"fire-perf-compat",[$u]:"fire-rc",[Vu]:"fire-rc-compat",[ju]:"fire-gcs",[zu]:"fire-gcs-compat",[Ku]:"fire-fst",[Yu]:"fire-fst-compat",[qu]:"fire-vertex","fire-js":"fire-js",[Qu]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pn=new Map,Zu=new Map,Si=new Map;function po(n,e){try{n.container.addComponent(e)}catch(t){ft.debug(`Component ${e.name} failed to register with FirebaseApp ${n.name}`,t)}}function en(n){const e=n.name;if(Si.has(e))return ft.debug(`There were multiple attempts to register component ${e}.`),!1;Si.set(e,n);for(const t of Pn.values())po(t,n);for(const t of Zu.values())po(t,n);return!0}function mo(n,e){const t=n.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),n.container.getProvider(e)}function St(n){return n==null?!1:n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const eh={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},Ct=new Tn("app","Firebase",eh);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class th{constructor(e,t,s){this._isDeleted=!1,this._options=Object.assign({},e),this._config=Object.assign({},t),this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=s,this.container.addComponent(new Ft("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw Ct.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _s=Ju;function go(n,e={}){let t=n;typeof e!="object"&&(e={name:e});const s=Object.assign({name:wi,automaticDataCollectionEnabled:!0},e),i=s.name;if(typeof i!="string"||!i)throw Ct.create("bad-app-name",{appName:String(i)});if(t||(t=eo()),!t)throw Ct.create("no-options");const r=Pn.get(i);if(r){if(Rn(t,r.options)&&Rn(s,r.config))return r;throw Ct.create("duplicate-app",{appName:i})}const o=new ou(i);for(const l of Si.values())o.addComponent(l);const a=new th(t,s,o);return Pn.set(i,a),a}function _o(n=wi){const e=Pn.get(n);if(!e&&n===wi&&eo())return go();if(!e)throw Ct.create("no-app",{appName:n});return e}function nh(){return Array.from(Pn.values())}function It(n,e,t){var s;let i=(s=Xu[n])!==null&&s!==void 0?s:n;t&&(i+=`-${t}`);const r=i.match(/\s|\//),o=e.match(/\s|\//);if(r||o){const a=[`Unable to register library "${i}" with version "${e}":`];r&&a.push(`library name "${i}" contains illegal characters (whitespace or "/")`),r&&o&&a.push("and"),o&&a.push(`version name "${e}" contains illegal characters (whitespace or "/")`),ft.warn(a.join(" "));return}en(new Ft(`${i}-version`,()=>({library:i,version:e}),"VERSION"))}function sh(n){hu(n)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ih="firebase-heartbeat-database",rh=1,Nn="firebase-heartbeat-store";let Ci=null;function yo(){return Ci||(Ci=Eu(ih,rh,{upgrade:(n,e)=>{switch(e){case 0:try{n.createObjectStore(Nn)}catch(t){console.warn(t)}}}}).catch(n=>{throw Ct.create("idb-open",{originalErrorMessage:n.message})})),Ci}async function oh(n){try{const t=(await yo()).transaction(Nn),s=await t.objectStore(Nn).get(Eo(n));return await t.done,s}catch(e){if(e instanceof xt)ft.warn(e.message);else{const t=Ct.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});ft.warn(t.message)}}}async function vo(n,e){try{const s=(await yo()).transaction(Nn,"readwrite");await s.objectStore(Nn).put(e,Eo(n)),await s.done}catch(t){if(t instanceof xt)ft.warn(t.message);else{const s=Ct.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});ft.warn(s.message)}}}function Eo(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ah=1024,lh=30;class ch{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new hh(t),this._heartbeatsCachePromise=this._storage.read().then(s=>(this._heartbeatsCache=s,s))}async triggerHeartbeat(){var e,t;try{const i=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),r=wo();if(((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)===null||t===void 0?void 0:t.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===r||this._heartbeatsCache.heartbeats.some(o=>o.date===r))return;if(this._heartbeatsCache.heartbeats.push({date:r,agent:i}),this._heartbeatsCache.heartbeats.length>lh){const o=dh(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(o,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(s){ft.warn(s)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=wo(),{heartbeatsToSend:s,unsentEntries:i}=uh(this._heartbeatsCache.heartbeats),r=ds(JSON.stringify({version:2,heartbeats:s}));return this._heartbeatsCache.lastSentHeartbeatDate=t,i.length>0?(this._heartbeatsCache.heartbeats=i,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),r}catch(t){return ft.warn(t),""}}}function wo(){return new Date().toISOString().substring(0,10)}function uh(n,e=ah){const t=[];let s=n.slice();for(const i of n){const r=t.find(o=>o.agent===i.agent);if(r){if(r.dates.push(i.date),So(t)>e){r.dates.pop();break}}else if(t.push({agent:i.agent,dates:[i.date]}),So(t)>e){t.pop();break}s=s.slice(1)}return{heartbeatsToSend:t,unsentEntries:s}}class hh{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return jc()?zc().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await oh(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){var t;if(await this._canUseIndexedDBPromise){const i=await this.read();return vo(this.app,{lastSentHeartbeatDate:(t=e.lastSentHeartbeatDate)!==null&&t!==void 0?t:i.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){var t;if(await this._canUseIndexedDBPromise){const i=await this.read();return vo(this.app,{lastSentHeartbeatDate:(t=e.lastSentHeartbeatDate)!==null&&t!==void 0?t:i.lastSentHeartbeatDate,heartbeats:[...i.heartbeats,...e.heartbeats]})}else return}}function So(n){return ds(JSON.stringify({version:2,heartbeats:n})).length}function dh(n){if(n.length===0)return-1;let e=0,t=n[0].date;for(let s=1;s<n.length;s++)n[s].date<t&&(t=n[s].date,e=s);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fh(n){en(new Ft("platform-logger",e=>new Cu(e),"PRIVATE")),en(new Ft("heartbeat",e=>new ch(e),"PRIVATE")),It(Ei,fo,n),It(Ei,fo,"esm2017"),It("fire-js","")}fh("");var Co={};const Io="@firebase/database",bo="1.0.20";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let To="";function ph(n){To=n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mh{constructor(e){this.domStorage_=e,this.prefix_="firebase:"}set(e,t){t==null?this.domStorage_.removeItem(this.prefixedName_(e)):this.domStorage_.setItem(this.prefixedName_(e),we(t))}get(e){const t=this.domStorage_.getItem(this.prefixedName_(e));return t==null?null:An(t)}remove(e){this.domStorage_.removeItem(this.prefixedName_(e))}prefixedName_(e){return this.prefix_+e}toString(){return this.domStorage_.toString()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gh{constructor(){this.cache_={},this.isInMemoryStorage=!0}set(e,t){t==null?delete this.cache_[e]:this.cache_[e]=t}get(e){return Xe(this.cache_,e)?this.cache_[e]:null}remove(e){delete this.cache_[e]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ao=function(n){try{if(typeof window<"u"&&typeof window[n]<"u"){const e=window[n];return e.setItem("firebase:sentinel","cache"),e.removeItem("firebase:sentinel"),new mh(e)}}catch{}return new gh},Wt=Ao("localStorage"),_h=Ao("sessionStorage");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tn=new fi("@firebase/database"),Ro=(function(){let n=1;return function(){return n++}})(),Po=function(n){const e=nu(n),t=new Xc;t.update(e);const s=t.digest();return ci.encodeByteArray(s)},kn=function(...n){let e="";for(let t=0;t<n.length;t++){const s=n[t];Array.isArray(s)||s&&typeof s=="object"&&typeof s.length=="number"?e+=kn.apply(null,s):typeof s=="object"?e+=we(s):e+=s,e+=" "}return e};let On=null,No=!0;const yh=function(n,e){w(!0,"Can't turn on custom loggers persistently."),tn.logLevel=ne.VERBOSE,On=tn.log.bind(tn)},Re=function(...n){if(No===!0&&(No=!1,On===null&&_h.get("logging_enabled")===!0&&yh()),On){const e=kn.apply(null,n);On(e)}},Ln=function(n){return function(...e){Re(n,...e)}},Ii=function(...n){const e="FIREBASE INTERNAL ERROR: "+kn(...n);tn.error(e)},pt=function(...n){const e=`FIREBASE FATAL ERROR: ${kn(...n)}`;throw tn.error(e),new Error(e)},Ne=function(...n){const e="FIREBASE WARNING: "+kn(...n);tn.warn(e)},vh=function(){typeof window<"u"&&window.location&&window.location.protocol&&window.location.protocol.indexOf("https:")!==-1&&Ne("Insecure Firebase access from a secure page. Please use https in calls to new Firebase().")},bi=function(n){return typeof n=="number"&&(n!==n||n===Number.POSITIVE_INFINITY||n===Number.NEGATIVE_INFINITY)},Eh=function(n){if(document.readyState==="complete")n();else{let e=!1;const t=function(){if(!document.body){setTimeout(t,Math.floor(10));return}e||(e=!0,n())};document.addEventListener?(document.addEventListener("DOMContentLoaded",t,!1),window.addEventListener("load",t,!1)):document.attachEvent&&(document.attachEvent("onreadystatechange",()=>{document.readyState==="complete"&&t()}),window.attachEvent("onload",t))}},nn="[MIN_NAME]",Gt="[MAX_NAME]",Ht=function(n,e){if(n===e)return 0;if(n===nn||e===Gt)return-1;if(e===nn||n===Gt)return 1;{const t=Lo(n),s=Lo(e);return t!==null?s!==null?t-s===0?n.length-e.length:t-s:-1:s!==null?1:n<e?-1:1}},wh=function(n,e){return n===e?0:n<e?-1:1},Dn=function(n,e){if(e&&n in e)return e[n];throw new Error("Missing required key ("+n+") in object: "+we(e))},Ti=function(n){if(typeof n!="object"||n===null)return we(n);const e=[];for(const s in n)e.push(s);e.sort();let t="{";for(let s=0;s<e.length;s++)s!==0&&(t+=","),t+=we(e[s]),t+=":",t+=Ti(n[e[s]]);return t+="}",t},ko=function(n,e){const t=n.length;if(t<=e)return[n];const s=[];for(let i=0;i<t;i+=e)i+e>t?s.push(n.substring(i,t)):s.push(n.substring(i,i+e));return s};function Pe(n,e){for(const t in n)n.hasOwnProperty(t)&&e(t,n[t])}const Oo=function(n){w(!bi(n),"Invalid JSON number");const e=11,t=52,s=(1<<e-1)-1;let i,r,o,a,l;n===0?(r=0,o=0,i=1/n===-1/0?1:0):(i=n<0,n=Math.abs(n),n>=Math.pow(2,1-s)?(a=Math.min(Math.floor(Math.log(n)/Math.LN2),s),r=a+s,o=Math.round(n*Math.pow(2,t-a)-Math.pow(2,t))):(r=0,o=Math.round(n/Math.pow(2,1-s-t))));const c=[];for(l=t;l;l-=1)c.push(o%2?1:0),o=Math.floor(o/2);for(l=e;l;l-=1)c.push(r%2?1:0),r=Math.floor(r/2);c.push(i?1:0),c.reverse();const f=c.join("");let d="";for(l=0;l<64;l+=8){let h=parseInt(f.substr(l,8),2).toString(16);h.length===1&&(h="0"+h),d=d+h}return d.toLowerCase()},Sh=function(){return!!(typeof window=="object"&&window.chrome&&window.chrome.extension&&!/^chrome/.test(window.location.href))},Ch=function(){return typeof Windows=="object"&&typeof Windows.UI=="object"};function Ih(n,e){let t="Unknown Error";n==="too_big"?t="The data requested exceeds the maximum size that can be accessed with a single request.":n==="permission_denied"?t="Client doesn't have permission to access the desired data.":n==="unavailable"&&(t="The service is unavailable");const s=new Error(n+" at "+e._path.toString()+": "+t);return s.code=n.toUpperCase(),s}const bh=new RegExp("^-?(0*)\\d{1,10}$"),Th=-2147483648,Ah=2147483647,Lo=function(n){if(bh.test(n)){const e=Number(n);if(e>=Th&&e<=Ah)return e}return null},sn=function(n){try{n()}catch(e){setTimeout(()=>{const t=e.stack||"";throw Ne("Exception was thrown by user callback.",t),e},Math.floor(0))}},Rh=function(){return(typeof window=="object"&&window.navigator&&window.navigator.userAgent||"").search(/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0},xn=function(n,e){const t=setTimeout(n,e);return typeof t=="number"&&typeof Deno<"u"&&Deno.unrefTimer?Deno.unrefTimer(t):typeof t=="object"&&t.unref&&t.unref(),t};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ph{constructor(e,t){this.appCheckProvider=t,this.appName=e.name,St(e)&&e.settings.appCheckToken&&(this.serverAppAppCheckToken=e.settings.appCheckToken),this.appCheck=t==null?void 0:t.getImmediate({optional:!0}),this.appCheck||t==null||t.get().then(s=>this.appCheck=s)}getToken(e){if(this.serverAppAppCheckToken){if(e)throw new Error("Attempted reuse of `FirebaseServerApp.appCheckToken` after previous usage failed.");return Promise.resolve({token:this.serverAppAppCheckToken})}return this.appCheck?this.appCheck.getToken(e):new Promise((t,s)=>{setTimeout(()=>{this.appCheck?this.getToken(e).then(t,s):t(null)},0)})}addTokenChangeListener(e){var t;(t=this.appCheckProvider)===null||t===void 0||t.get().then(s=>s.addTokenListener(e))}notifyForInvalidToken(){Ne(`Provided AppCheck credentials for the app named "${this.appName}" are invalid. This usually indicates your app was not initialized correctly.`)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nh{constructor(e,t,s){this.appName_=e,this.firebaseOptions_=t,this.authProvider_=s,this.auth_=null,this.auth_=s.getImmediate({optional:!0}),this.auth_||s.onInit(i=>this.auth_=i)}getToken(e){return this.auth_?this.auth_.getToken(e).catch(t=>t&&t.code==="auth/token-not-initialized"?(Re("Got auth/token-not-initialized error.  Treating as null token."),null):Promise.reject(t)):new Promise((t,s)=>{setTimeout(()=>{this.auth_?this.getToken(e).then(t,s):t(null)},0)})}addTokenChangeListener(e){this.auth_?this.auth_.addAuthTokenListener(e):this.authProvider_.get().then(t=>t.addAuthTokenListener(e))}removeTokenChangeListener(e){this.authProvider_.get().then(t=>t.removeAuthTokenListener(e))}notifyForInvalidToken(){let e='Provided authentication credentials for the app named "'+this.appName_+'" are invalid. This usually indicates your app was not initialized correctly. ';"credential"in this.firebaseOptions_?e+='Make sure the "credential" property provided to initializeApp() is authorized to access the specified "databaseURL" and is from the correct project.':"serviceAccount"in this.firebaseOptions_?e+='Make sure the "serviceAccount" property provided to initializeApp() is authorized to access the specified "databaseURL" and is from the correct project.':e+='Make sure the "apiKey" and "databaseURL" properties provided to initializeApp() match the values provided for your app at https://console.firebase.google.com/.',Ne(e)}}class ys{constructor(e){this.accessToken=e}getToken(e){return Promise.resolve({accessToken:this.accessToken})}addTokenChangeListener(e){e(this.accessToken)}removeTokenChangeListener(e){}notifyForInvalidToken(){}}ys.OWNER="owner";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ai="5",Do="v",xo="s",Mo="r",Fo="f",Uo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,Wo="ls",Go="p",Ri="ac",Ho="websocket",Bo="long_polling";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $o{constructor(e,t,s,i,r=!1,o="",a=!1,l=!1,c=null){this.secure=t,this.namespace=s,this.webSocketOnly=i,this.nodeAdmin=r,this.persistenceKey=o,this.includeNamespaceInQueryParams=a,this.isUsingEmulator=l,this.emulatorOptions=c,this._host=e.toLowerCase(),this._domain=this._host.substr(this._host.indexOf(".")+1),this.internalHost=Wt.get("host:"+e)||this._host}isCacheableHost(){return this.internalHost.substr(0,2)==="s-"}isCustomHost(){return this._domain!=="firebaseio.com"&&this._domain!=="firebaseio-demo.com"}get host(){return this._host}set host(e){e!==this.internalHost&&(this.internalHost=e,this.isCacheableHost()&&Wt.set("host:"+this._host,this.internalHost))}toString(){let e=this.toURLString();return this.persistenceKey&&(e+="<"+this.persistenceKey+">"),e}toURLString(){const e=this.secure?"https://":"http://",t=this.includeNamespaceInQueryParams?`?ns=${this.namespace}`:"";return`${e}${this.host}/${t}`}}function kh(n){return n.host!==n.internalHost||n.isCustomHost()||n.includeNamespaceInQueryParams}function Vo(n,e,t){w(typeof e=="string","typeof type must == string"),w(typeof t=="object","typeof params must == object");let s;if(e===Ho)s=(n.secure?"wss://":"ws://")+n.internalHost+"/.ws?";else if(e===Bo)s=(n.secure?"https://":"http://")+n.internalHost+"/.lp?";else throw new Error("Unknown connection type: "+e);kh(n)&&(t.ns=n.namespace);const i=[];return Pe(t,(r,o)=>{i.push(r+"="+o)}),s+i.join("&")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Oh{constructor(){this.counters_={}}incrementCounter(e,t=1){Xe(this.counters_,e)||(this.counters_[e]=0),this.counters_[e]+=t}get(){return Pc(this.counters_)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pi={},Ni={};function ki(n){const e=n.toString();return Pi[e]||(Pi[e]=new Oh),Pi[e]}function Lh(n,e){const t=n.toString();return Ni[t]||(Ni[t]=e()),Ni[t]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dh{constructor(e){this.onMessage_=e,this.pendingResponses=[],this.currentResponseNum=0,this.closeAfterResponse=-1,this.onClose=null}closeAfter(e,t){this.closeAfterResponse=e,this.onClose=t,this.closeAfterResponse<this.currentResponseNum&&(this.onClose(),this.onClose=null)}handleResponse(e,t){for(this.pendingResponses[e]=t;this.pendingResponses[this.currentResponseNum];){const s=this.pendingResponses[this.currentResponseNum];delete this.pendingResponses[this.currentResponseNum];for(let i=0;i<s.length;++i)s[i]&&sn(()=>{this.onMessage_(s[i])});if(this.currentResponseNum===this.closeAfterResponse){this.onClose&&(this.onClose(),this.onClose=null);break}this.currentResponseNum++}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const jo="start",xh="close",Mh="pLPCommand",Fh="pRTLPCB",zo="id",Ko="pw",qo="ser",Uh="cb",Wh="seg",Gh="ts",Hh="d",Bh="dframe",Yo=1870,Qo=30,$h=Yo-Qo,Vh=25e3,jh=3e4;class rn{constructor(e,t,s,i,r,o,a){this.connId=e,this.repoInfo=t,this.applicationId=s,this.appCheckToken=i,this.authToken=r,this.transportSessionId=o,this.lastSessionId=a,this.bytesSent=0,this.bytesReceived=0,this.everConnected_=!1,this.log_=Ln(e),this.stats_=ki(t),this.urlFn=l=>(this.appCheckToken&&(l[Ri]=this.appCheckToken),Vo(t,Bo,l))}open(e,t){this.curSegmentNum=0,this.onDisconnect_=t,this.myPacketOrderer=new Dh(e),this.isClosed_=!1,this.connectTimeoutTimer_=setTimeout(()=>{this.log_("Timed out trying to connect."),this.onClosed_(),this.connectTimeoutTimer_=null},Math.floor(jh)),Eh(()=>{if(this.isClosed_)return;this.scriptTagHolder=new Oi((...r)=>{const[o,a,l,c,f]=r;if(this.incrementIncomingBytes_(r),!!this.scriptTagHolder)if(this.connectTimeoutTimer_&&(clearTimeout(this.connectTimeoutTimer_),this.connectTimeoutTimer_=null),this.everConnected_=!0,o===jo)this.id=a,this.password=l;else if(o===xh)a?(this.scriptTagHolder.sendNewPolls=!1,this.myPacketOrderer.closeAfter(a,()=>{this.onClosed_()})):this.onClosed_();else throw new Error("Unrecognized command received: "+o)},(...r)=>{const[o,a]=r;this.incrementIncomingBytes_(r),this.myPacketOrderer.handleResponse(o,a)},()=>{this.onClosed_()},this.urlFn);const s={};s[jo]="t",s[qo]=Math.floor(Math.random()*1e8),this.scriptTagHolder.uniqueCallbackIdentifier&&(s[Uh]=this.scriptTagHolder.uniqueCallbackIdentifier),s[Do]=Ai,this.transportSessionId&&(s[xo]=this.transportSessionId),this.lastSessionId&&(s[Wo]=this.lastSessionId),this.applicationId&&(s[Go]=this.applicationId),this.appCheckToken&&(s[Ri]=this.appCheckToken),typeof location<"u"&&location.hostname&&Uo.test(location.hostname)&&(s[Mo]=Fo);const i=this.urlFn(s);this.log_("Connecting via long-poll to "+i),this.scriptTagHolder.addTag(i,()=>{})})}start(){this.scriptTagHolder.startLongPoll(this.id,this.password),this.addDisconnectPingFrame(this.id,this.password)}static forceAllow(){rn.forceAllow_=!0}static forceDisallow(){rn.forceDisallow_=!0}static isAvailable(){return rn.forceAllow_?!0:!rn.forceDisallow_&&typeof document<"u"&&document.createElement!=null&&!Sh()&&!Ch()}markConnectionHealthy(){}shutdown_(){this.isClosed_=!0,this.scriptTagHolder&&(this.scriptTagHolder.close(),this.scriptTagHolder=null),this.myDisconnFrame&&(document.body.removeChild(this.myDisconnFrame),this.myDisconnFrame=null),this.connectTimeoutTimer_&&(clearTimeout(this.connectTimeoutTimer_),this.connectTimeoutTimer_=null)}onClosed_(){this.isClosed_||(this.log_("Longpoll is closing itself"),this.shutdown_(),this.onDisconnect_&&(this.onDisconnect_(this.everConnected_),this.onDisconnect_=null))}close(){this.isClosed_||(this.log_("Longpoll is being closed."),this.shutdown_())}send(e){const t=we(e);this.bytesSent+=t.length,this.stats_.incrementCounter("bytes_sent",t.length);const s=Jr(t),i=ko(s,$h);for(let r=0;r<i.length;r++)this.scriptTagHolder.enqueueSegment(this.curSegmentNum,i.length,i[r]),this.curSegmentNum++}addDisconnectPingFrame(e,t){this.myDisconnFrame=document.createElement("iframe");const s={};s[Bh]="t",s[zo]=e,s[Ko]=t,this.myDisconnFrame.src=this.urlFn(s),this.myDisconnFrame.style.display="none",document.body.appendChild(this.myDisconnFrame)}incrementIncomingBytes_(e){const t=we(e).length;this.bytesReceived+=t,this.stats_.incrementCounter("bytes_received",t)}}class Oi{constructor(e,t,s,i){this.onDisconnect=s,this.urlFn=i,this.outstandingRequests=new Set,this.pendingSegs=[],this.currentSerial=Math.floor(Math.random()*1e8),this.sendNewPolls=!0;{this.uniqueCallbackIdentifier=Ro(),window[Mh+this.uniqueCallbackIdentifier]=e,window[Fh+this.uniqueCallbackIdentifier]=t,this.myIFrame=Oi.createIFrame_();let r="";this.myIFrame.src&&this.myIFrame.src.substr(0,11)==="javascript:"&&(r='<script>document.domain="'+document.domain+'";<\/script>');const o="<html><body>"+r+"</body></html>";try{this.myIFrame.doc.open(),this.myIFrame.doc.write(o),this.myIFrame.doc.close()}catch(a){Re("frame writing exception"),a.stack&&Re(a.stack),Re(a)}}}static createIFrame_(){const e=document.createElement("iframe");if(e.style.display="none",document.body){document.body.appendChild(e);try{e.contentWindow.document||Re("No IE domain setting required")}catch{const s=document.domain;e.src="javascript:void((function(){document.open();document.domain='"+s+"';document.close();})())"}}else throw"Document body has not initialized. Wait to initialize Firebase until after the document is ready.";return e.contentDocument?e.doc=e.contentDocument:e.contentWindow?e.doc=e.contentWindow.document:e.document&&(e.doc=e.document),e}close(){this.alive=!1,this.myIFrame&&(this.myIFrame.doc.body.textContent="",setTimeout(()=>{this.myIFrame!==null&&(document.body.removeChild(this.myIFrame),this.myIFrame=null)},Math.floor(0)));const e=this.onDisconnect;e&&(this.onDisconnect=null,e())}startLongPoll(e,t){for(this.myID=e,this.myPW=t,this.alive=!0;this.newRequest_(););}newRequest_(){if(this.alive&&this.sendNewPolls&&this.outstandingRequests.size<(this.pendingSegs.length>0?2:1)){this.currentSerial++;const e={};e[zo]=this.myID,e[Ko]=this.myPW,e[qo]=this.currentSerial;let t=this.urlFn(e),s="",i=0;for(;this.pendingSegs.length>0&&this.pendingSegs[0].d.length+Qo+s.length<=Yo;){const o=this.pendingSegs.shift();s=s+"&"+Wh+i+"="+o.seg+"&"+Gh+i+"="+o.ts+"&"+Hh+i+"="+o.d,i++}return t=t+s,this.addLongPollTag_(t,this.currentSerial),!0}else return!1}enqueueSegment(e,t,s){this.pendingSegs.push({seg:e,ts:t,d:s}),this.alive&&this.newRequest_()}addLongPollTag_(e,t){this.outstandingRequests.add(t);const s=()=>{this.outstandingRequests.delete(t),this.newRequest_()},i=setTimeout(s,Math.floor(Vh)),r=()=>{clearTimeout(i),s()};this.addTag(e,r)}addTag(e,t){setTimeout(()=>{try{if(!this.sendNewPolls)return;const s=this.myIFrame.doc.createElement("script");s.type="text/javascript",s.async=!0,s.src=e,s.onload=s.onreadystatechange=function(){const i=s.readyState;(!i||i==="loaded"||i==="complete")&&(s.onload=s.onreadystatechange=null,s.parentNode&&s.parentNode.removeChild(s),t())},s.onerror=()=>{Re("Long-poll script failed to load: "+e),this.sendNewPolls=!1,this.close()},this.myIFrame.doc.body.appendChild(s)}catch{}},Math.floor(1))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zh=16384,Kh=45e3;let vs=null;typeof MozWebSocket<"u"?vs=MozWebSocket:typeof WebSocket<"u"&&(vs=WebSocket);class Ze{constructor(e,t,s,i,r,o,a){this.connId=e,this.applicationId=s,this.appCheckToken=i,this.authToken=r,this.keepaliveTimer=null,this.frames=null,this.totalFrames=0,this.bytesSent=0,this.bytesReceived=0,this.log_=Ln(this.connId),this.stats_=ki(t),this.connURL=Ze.connectionURL_(t,o,a,i,s),this.nodeAdmin=t.nodeAdmin}static connectionURL_(e,t,s,i,r){const o={};return o[Do]=Ai,typeof location<"u"&&location.hostname&&Uo.test(location.hostname)&&(o[Mo]=Fo),t&&(o[xo]=t),s&&(o[Wo]=s),i&&(o[Ri]=i),r&&(o[Go]=r),Vo(e,Ho,o)}open(e,t){this.onDisconnect=t,this.onMessage=e,this.log_("Websocket connecting to "+this.connURL),this.everConnected_=!1,Wt.set("previous_websocket_failure",!0);try{let s;Vc(),this.mySock=new vs(this.connURL,[],s)}catch(s){this.log_("Error instantiating WebSocket.");const i=s.message||s.data;i&&this.log_(i),this.onClosed_();return}this.mySock.onopen=()=>{this.log_("Websocket connected."),this.everConnected_=!0},this.mySock.onclose=()=>{this.log_("Websocket connection was disconnected."),this.mySock=null,this.onClosed_()},this.mySock.onmessage=s=>{this.handleIncomingFrame(s)},this.mySock.onerror=s=>{this.log_("WebSocket error.  Closing connection.");const i=s.message||s.data;i&&this.log_(i),this.onClosed_()}}start(){}static forceDisallow(){Ze.forceDisallow_=!0}static isAvailable(){let e=!1;if(typeof navigator<"u"&&navigator.userAgent){const t=/Android ([0-9]{0,}\.[0-9]{0,})/,s=navigator.userAgent.match(t);s&&s.length>1&&parseFloat(s[1])<4.4&&(e=!0)}return!e&&vs!==null&&!Ze.forceDisallow_}static previouslyFailed(){return Wt.isInMemoryStorage||Wt.get("previous_websocket_failure")===!0}markConnectionHealthy(){Wt.remove("previous_websocket_failure")}appendFrame_(e){if(this.frames.push(e),this.frames.length===this.totalFrames){const t=this.frames.join("");this.frames=null;const s=An(t);this.onMessage(s)}}handleNewFrameCount_(e){this.totalFrames=e,this.frames=[]}extractFrameCount_(e){if(w(this.frames===null,"We already have a frame buffer"),e.length<=6){const t=Number(e);if(!isNaN(t))return this.handleNewFrameCount_(t),null}return this.handleNewFrameCount_(1),e}handleIncomingFrame(e){if(this.mySock===null)return;const t=e.data;if(this.bytesReceived+=t.length,this.stats_.incrementCounter("bytes_received",t.length),this.resetKeepAlive(),this.frames!==null)this.appendFrame_(t);else{const s=this.extractFrameCount_(t);s!==null&&this.appendFrame_(s)}}send(e){this.resetKeepAlive();const t=we(e);this.bytesSent+=t.length,this.stats_.incrementCounter("bytes_sent",t.length);const s=ko(t,zh);s.length>1&&this.sendString_(String(s.length));for(let i=0;i<s.length;i++)this.sendString_(s[i])}shutdown_(){this.isClosed_=!0,this.keepaliveTimer&&(clearInterval(this.keepaliveTimer),this.keepaliveTimer=null),this.mySock&&(this.mySock.close(),this.mySock=null)}onClosed_(){this.isClosed_||(this.log_("WebSocket is closing itself"),this.shutdown_(),this.onDisconnect&&(this.onDisconnect(this.everConnected_),this.onDisconnect=null))}close(){this.isClosed_||(this.log_("WebSocket is being closed"),this.shutdown_())}resetKeepAlive(){clearInterval(this.keepaliveTimer),this.keepaliveTimer=setInterval(()=>{this.mySock&&this.sendString_("0"),this.resetKeepAlive()},Math.floor(Kh))}sendString_(e){try{this.mySock.send(e)}catch(t){this.log_("Exception thrown from WebSocket.send():",t.message||t.data,"Closing connection."),setTimeout(this.onClosed_.bind(this),0)}}}Ze.responsesRequiredToBeHealthy=2,Ze.healthyTimeout=3e4;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mn{static get ALL_TRANSPORTS(){return[rn,Ze]}static get IS_TRANSPORT_INITIALIZED(){return this.globalTransportInitialized_}constructor(e){this.initTransports_(e)}initTransports_(e){const t=Ze&&Ze.isAvailable();let s=t&&!Ze.previouslyFailed();if(e.webSocketOnly&&(t||Ne("wss:// URL used, but browser isn't known to support websockets.  Trying anyway."),s=!0),s)this.transports_=[Ze];else{const i=this.transports_=[];for(const r of Mn.ALL_TRANSPORTS)r&&r.isAvailable()&&i.push(r);Mn.globalTransportInitialized_=!0}}initialTransport(){if(this.transports_.length>0)return this.transports_[0];throw new Error("No transports available")}upgradeTransport(){return this.transports_.length>1?this.transports_[1]:null}}Mn.globalTransportInitialized_=!1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qh=6e4,Yh=5e3,Qh=10*1024,Jh=100*1024,Li="t",Jo="d",Xh="s",Xo="r",Zh="e",Zo="o",ea="a",ta="n",na="p",ed="h";class td{constructor(e,t,s,i,r,o,a,l,c,f){this.id=e,this.repoInfo_=t,this.applicationId_=s,this.appCheckToken_=i,this.authToken_=r,this.onMessage_=o,this.onReady_=a,this.onDisconnect_=l,this.onKill_=c,this.lastSessionId=f,this.connectionCount=0,this.pendingDataMessages=[],this.state_=0,this.log_=Ln("c:"+this.id+":"),this.transportManager_=new Mn(t),this.log_("Connection created"),this.start_()}start_(){const e=this.transportManager_.initialTransport();this.conn_=new e(this.nextTransportId_(),this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,null,this.lastSessionId),this.primaryResponsesRequired_=e.responsesRequiredToBeHealthy||0;const t=this.connReceiver_(this.conn_),s=this.disconnReceiver_(this.conn_);this.tx_=this.conn_,this.rx_=this.conn_,this.secondaryConn_=null,this.isHealthy_=!1,setTimeout(()=>{this.conn_&&this.conn_.open(t,s)},Math.floor(0));const i=e.healthyTimeout||0;i>0&&(this.healthyTimeout_=xn(()=>{this.healthyTimeout_=null,this.isHealthy_||(this.conn_&&this.conn_.bytesReceived>Jh?(this.log_("Connection exceeded healthy timeout but has received "+this.conn_.bytesReceived+" bytes.  Marking connection healthy."),this.isHealthy_=!0,this.conn_.markConnectionHealthy()):this.conn_&&this.conn_.bytesSent>Qh?this.log_("Connection exceeded healthy timeout but has sent "+this.conn_.bytesSent+" bytes.  Leaving connection alive."):(this.log_("Closing unhealthy connection after timeout."),this.close()))},Math.floor(i)))}nextTransportId_(){return"c:"+this.id+":"+this.connectionCount++}disconnReceiver_(e){return t=>{e===this.conn_?this.onConnectionLost_(t):e===this.secondaryConn_?(this.log_("Secondary connection lost."),this.onSecondaryConnectionLost_()):this.log_("closing an old connection")}}connReceiver_(e){return t=>{this.state_!==2&&(e===this.rx_?this.onPrimaryMessageReceived_(t):e===this.secondaryConn_?this.onSecondaryMessageReceived_(t):this.log_("message on old connection"))}}sendRequest(e){const t={t:"d",d:e};this.sendData_(t)}tryCleanupConnection(){this.tx_===this.secondaryConn_&&this.rx_===this.secondaryConn_&&(this.log_("cleaning up and promoting a connection: "+this.secondaryConn_.connId),this.conn_=this.secondaryConn_,this.secondaryConn_=null)}onSecondaryControl_(e){if(Li in e){const t=e[Li];t===ea?this.upgradeIfSecondaryHealthy_():t===Xo?(this.log_("Got a reset on secondary, closing it"),this.secondaryConn_.close(),(this.tx_===this.secondaryConn_||this.rx_===this.secondaryConn_)&&this.close()):t===Zo&&(this.log_("got pong on secondary."),this.secondaryResponsesRequired_--,this.upgradeIfSecondaryHealthy_())}}onSecondaryMessageReceived_(e){const t=Dn("t",e),s=Dn("d",e);if(t==="c")this.onSecondaryControl_(s);else if(t==="d")this.pendingDataMessages.push(s);else throw new Error("Unknown protocol layer: "+t)}upgradeIfSecondaryHealthy_(){this.secondaryResponsesRequired_<=0?(this.log_("Secondary connection is healthy."),this.isHealthy_=!0,this.secondaryConn_.markConnectionHealthy(),this.proceedWithUpgrade_()):(this.log_("sending ping on secondary."),this.secondaryConn_.send({t:"c",d:{t:na,d:{}}}))}proceedWithUpgrade_(){this.secondaryConn_.start(),this.log_("sending client ack on secondary"),this.secondaryConn_.send({t:"c",d:{t:ea,d:{}}}),this.log_("Ending transmission on primary"),this.conn_.send({t:"c",d:{t:ta,d:{}}}),this.tx_=this.secondaryConn_,this.tryCleanupConnection()}onPrimaryMessageReceived_(e){const t=Dn("t",e),s=Dn("d",e);t==="c"?this.onControl_(s):t==="d"&&this.onDataMessage_(s)}onDataMessage_(e){this.onPrimaryResponse_(),this.onMessage_(e)}onPrimaryResponse_(){this.isHealthy_||(this.primaryResponsesRequired_--,this.primaryResponsesRequired_<=0&&(this.log_("Primary connection is healthy."),this.isHealthy_=!0,this.conn_.markConnectionHealthy()))}onControl_(e){const t=Dn(Li,e);if(Jo in e){const s=e[Jo];if(t===ed){const i=Object.assign({},s);this.repoInfo_.isUsingEmulator&&(i.h=this.repoInfo_.host),this.onHandshake_(i)}else if(t===ta){this.log_("recvd end transmission on primary"),this.rx_=this.secondaryConn_;for(let i=0;i<this.pendingDataMessages.length;++i)this.onDataMessage_(this.pendingDataMessages[i]);this.pendingDataMessages=[],this.tryCleanupConnection()}else t===Xh?this.onConnectionShutdown_(s):t===Xo?this.onReset_(s):t===Zh?Ii("Server Error: "+s):t===Zo?(this.log_("got pong on primary."),this.onPrimaryResponse_(),this.sendPingOnPrimaryIfNecessary_()):Ii("Unknown control packet command: "+t)}}onHandshake_(e){const t=e.ts,s=e.v,i=e.h;this.sessionId=e.s,this.repoInfo_.host=i,this.state_===0&&(this.conn_.start(),this.onConnectionEstablished_(this.conn_,t),Ai!==s&&Ne("Protocol version mismatch detected"),this.tryStartUpgrade_())}tryStartUpgrade_(){const e=this.transportManager_.upgradeTransport();e&&this.startUpgrade_(e)}startUpgrade_(e){this.secondaryConn_=new e(this.nextTransportId_(),this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,this.sessionId),this.secondaryResponsesRequired_=e.responsesRequiredToBeHealthy||0;const t=this.connReceiver_(this.secondaryConn_),s=this.disconnReceiver_(this.secondaryConn_);this.secondaryConn_.open(t,s),xn(()=>{this.secondaryConn_&&(this.log_("Timed out trying to upgrade."),this.secondaryConn_.close())},Math.floor(qh))}onReset_(e){this.log_("Reset packet received.  New host: "+e),this.repoInfo_.host=e,this.state_===1?this.close():(this.closeConnections_(),this.start_())}onConnectionEstablished_(e,t){this.log_("Realtime connection established."),this.conn_=e,this.state_=1,this.onReady_&&(this.onReady_(t,this.sessionId),this.onReady_=null),this.primaryResponsesRequired_===0?(this.log_("Primary connection is healthy."),this.isHealthy_=!0):xn(()=>{this.sendPingOnPrimaryIfNecessary_()},Math.floor(Yh))}sendPingOnPrimaryIfNecessary_(){!this.isHealthy_&&this.state_===1&&(this.log_("sending ping on primary."),this.sendData_({t:"c",d:{t:na,d:{}}}))}onSecondaryConnectionLost_(){const e=this.secondaryConn_;this.secondaryConn_=null,(this.tx_===e||this.rx_===e)&&this.close()}onConnectionLost_(e){this.conn_=null,!e&&this.state_===0?(this.log_("Realtime connection failed."),this.repoInfo_.isCacheableHost()&&(Wt.remove("host:"+this.repoInfo_.host),this.repoInfo_.internalHost=this.repoInfo_.host)):this.state_===1&&this.log_("Realtime connection lost."),this.close()}onConnectionShutdown_(e){this.log_("Connection shutdown command received. Shutting down..."),this.onKill_&&(this.onKill_(e),this.onKill_=null),this.onDisconnect_=null,this.close()}sendData_(e){if(this.state_!==1)throw"Connection is not connected";this.tx_.send(e)}close(){this.state_!==2&&(this.log_("Closing realtime connection."),this.state_=2,this.closeConnections_(),this.onDisconnect_&&(this.onDisconnect_(),this.onDisconnect_=null))}closeConnections_(){this.log_("Shutting down all connections"),this.conn_&&(this.conn_.close(),this.conn_=null),this.secondaryConn_&&(this.secondaryConn_.close(),this.secondaryConn_=null),this.healthyTimeout_&&(clearTimeout(this.healthyTimeout_),this.healthyTimeout_=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sa{put(e,t,s,i){}merge(e,t,s,i){}refreshAuthToken(e){}refreshAppCheckToken(e){}onDisconnectPut(e,t,s){}onDisconnectMerge(e,t,s){}onDisconnectCancel(e,t){}reportStats(e){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ia{constructor(e){this.allowedEvents_=e,this.listeners_={},w(Array.isArray(e)&&e.length>0,"Requires a non-empty array")}trigger(e,...t){if(Array.isArray(this.listeners_[e])){const s=[...this.listeners_[e]];for(let i=0;i<s.length;i++)s[i].callback.apply(s[i].context,t)}}on(e,t,s){this.validateEventType_(e),this.listeners_[e]=this.listeners_[e]||[],this.listeners_[e].push({callback:t,context:s});const i=this.getInitialEvent(e);i&&t.apply(s,i)}off(e,t,s){this.validateEventType_(e);const i=this.listeners_[e]||[];for(let r=0;r<i.length;r++)if(i[r].callback===t&&(!s||s===i[r].context)){i.splice(r,1);return}}validateEventType_(e){w(this.allowedEvents_.find(t=>t===e),"Unknown event: "+e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Es extends ia{static getInstance(){return new Es}constructor(){super(["online"]),this.online_=!0,typeof window<"u"&&typeof window.addEventListener<"u"&&!ui()&&(window.addEventListener("online",()=>{this.online_||(this.online_=!0,this.trigger("online",!0))},!1),window.addEventListener("offline",()=>{this.online_&&(this.online_=!1,this.trigger("online",!1))},!1))}getInitialEvent(e){return w(e==="online","Unknown event type: "+e),[this.online_]}currentlyOnline(){return this.online_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ra=32,oa=768;class se{constructor(e,t){if(t===void 0){this.pieces_=e.split("/");let s=0;for(let i=0;i<this.pieces_.length;i++)this.pieces_[i].length>0&&(this.pieces_[s]=this.pieces_[i],s++);this.pieces_.length=s,this.pieceNum_=0}else this.pieces_=e,this.pieceNum_=t}toString(){let e="";for(let t=this.pieceNum_;t<this.pieces_.length;t++)this.pieces_[t]!==""&&(e+="/"+this.pieces_[t]);return e||"/"}}function Q(){return new se("")}function W(n){return n.pieceNum_>=n.pieces_.length?null:n.pieces_[n.pieceNum_]}function bt(n){return n.pieces_.length-n.pieceNum_}function oe(n){let e=n.pieceNum_;return e<n.pieces_.length&&e++,new se(n.pieces_,e)}function Di(n){return n.pieceNum_<n.pieces_.length?n.pieces_[n.pieces_.length-1]:null}function nd(n){let e="";for(let t=n.pieceNum_;t<n.pieces_.length;t++)n.pieces_[t]!==""&&(e+="/"+encodeURIComponent(String(n.pieces_[t])));return e||"/"}function Fn(n,e=0){return n.pieces_.slice(n.pieceNum_+e)}function aa(n){if(n.pieceNum_>=n.pieces_.length)return null;const e=[];for(let t=n.pieceNum_;t<n.pieces_.length-1;t++)e.push(n.pieces_[t]);return new se(e,0)}function pe(n,e){const t=[];for(let s=n.pieceNum_;s<n.pieces_.length;s++)t.push(n.pieces_[s]);if(e instanceof se)for(let s=e.pieceNum_;s<e.pieces_.length;s++)t.push(e.pieces_[s]);else{const s=e.split("/");for(let i=0;i<s.length;i++)s[i].length>0&&t.push(s[i])}return new se(t,0)}function B(n){return n.pieceNum_>=n.pieces_.length}function ke(n,e){const t=W(n),s=W(e);if(t===null)return e;if(t===s)return ke(oe(n),oe(e));throw new Error("INTERNAL ERROR: innerPath ("+e+") is not within outerPath ("+n+")")}function sd(n,e){const t=Fn(n,0),s=Fn(e,0);for(let i=0;i<t.length&&i<s.length;i++){const r=Ht(t[i],s[i]);if(r!==0)return r}return t.length===s.length?0:t.length<s.length?-1:1}function xi(n,e){if(bt(n)!==bt(e))return!1;for(let t=n.pieceNum_,s=e.pieceNum_;t<=n.pieces_.length;t++,s++)if(n.pieces_[t]!==e.pieces_[s])return!1;return!0}function Be(n,e){let t=n.pieceNum_,s=e.pieceNum_;if(bt(n)>bt(e))return!1;for(;t<n.pieces_.length;){if(n.pieces_[t]!==e.pieces_[s])return!1;++t,++s}return!0}class id{constructor(e,t){this.errorPrefix_=t,this.parts_=Fn(e,0),this.byteLength_=Math.max(1,this.parts_.length);for(let s=0;s<this.parts_.length;s++)this.byteLength_+=gs(this.parts_[s]);la(this)}}function rd(n,e){n.parts_.length>0&&(n.byteLength_+=1),n.parts_.push(e),n.byteLength_+=gs(e),la(n)}function od(n){const e=n.parts_.pop();n.byteLength_-=gs(e),n.parts_.length>0&&(n.byteLength_-=1)}function la(n){if(n.byteLength_>oa)throw new Error(n.errorPrefix_+"has a key path longer than "+oa+" bytes ("+n.byteLength_+").");if(n.parts_.length>ra)throw new Error(n.errorPrefix_+"path specified exceeds the maximum depth that can be written ("+ra+") or object contains a cycle "+Bt(n))}function Bt(n){return n.parts_.length===0?"":"in property '"+n.parts_.join(".")+"'"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mi extends ia{static getInstance(){return new Mi}constructor(){super(["visible"]);let e,t;typeof document<"u"&&typeof document.addEventListener<"u"&&(typeof document.hidden<"u"?(t="visibilitychange",e="hidden"):typeof document.mozHidden<"u"?(t="mozvisibilitychange",e="mozHidden"):typeof document.msHidden<"u"?(t="msvisibilitychange",e="msHidden"):typeof document.webkitHidden<"u"&&(t="webkitvisibilitychange",e="webkitHidden")),this.visible_=!0,t&&document.addEventListener(t,()=>{const s=!document[e];s!==this.visible_&&(this.visible_=s,this.trigger("visible",s))},!1)}getInitialEvent(e){return w(e==="visible","Unknown event type: "+e),[this.visible_]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Un=1e3,ad=300*1e3,ca=30*1e3,ld=1.3,cd=3e4,ud="server_kill",ua=3;class mt extends sa{constructor(e,t,s,i,r,o,a,l){if(super(),this.repoInfo_=e,this.applicationId_=t,this.onDataUpdate_=s,this.onConnectStatus_=i,this.onServerInfoUpdate_=r,this.authTokenProvider_=o,this.appCheckTokenProvider_=a,this.authOverride_=l,this.id=mt.nextPersistentConnectionId_++,this.log_=Ln("p:"+this.id+":"),this.interruptReasons_={},this.listens=new Map,this.outstandingPuts_=[],this.outstandingGets_=[],this.outstandingPutCount_=0,this.outstandingGetCount_=0,this.onDisconnectRequestQueue_=[],this.connected_=!1,this.reconnectDelay_=Un,this.maxReconnectDelay_=ad,this.securityDebugCallback_=null,this.lastSessionId=null,this.establishConnectionTimer_=null,this.visible_=!1,this.requestCBHash_={},this.requestNumber_=0,this.realtime_=null,this.authToken_=null,this.appCheckToken_=null,this.forceTokenRefresh_=!1,this.invalidAuthTokenCount_=0,this.invalidAppCheckTokenCount_=0,this.firstConnection_=!0,this.lastConnectionAttemptTime_=null,this.lastConnectionEstablishedTime_=null,l)throw new Error("Auth override specified in options, but not supported on non Node.js platforms");Mi.getInstance().on("visible",this.onVisible_,this),e.host.indexOf("fblocal")===-1&&Es.getInstance().on("online",this.onOnline_,this)}sendRequest(e,t,s){const i=++this.requestNumber_,r={r:i,a:e,b:t};this.log_(we(r)),w(this.connected_,"sendRequest call when we're not connected not allowed."),this.realtime_.sendRequest(r),s&&(this.requestCBHash_[i]=s)}get(e){this.initConnection_();const t=new Zt,i={action:"g",request:{p:e._path.toString(),q:e._queryObject},onComplete:o=>{const a=o.d;o.s==="ok"?t.resolve(a):t.reject(a)}};this.outstandingGets_.push(i),this.outstandingGetCount_++;const r=this.outstandingGets_.length-1;return this.connected_&&this.sendGet_(r),t.promise}listen(e,t,s,i){this.initConnection_();const r=e._queryIdentifier,o=e._path.toString();this.log_("Listen called for "+o+" "+r),this.listens.has(o)||this.listens.set(o,new Map),w(e._queryParams.isDefault()||!e._queryParams.loadsAllData(),"listen() called for non-default but complete query"),w(!this.listens.get(o).has(r),"listen() called twice for same path/queryId.");const a={onComplete:i,hashFn:t,query:e,tag:s};this.listens.get(o).set(r,a),this.connected_&&this.sendListen_(a)}sendGet_(e){const t=this.outstandingGets_[e];this.sendRequest("g",t.request,s=>{delete this.outstandingGets_[e],this.outstandingGetCount_--,this.outstandingGetCount_===0&&(this.outstandingGets_=[]),t.onComplete&&t.onComplete(s)})}sendListen_(e){const t=e.query,s=t._path.toString(),i=t._queryIdentifier;this.log_("Listen on "+s+" for "+i);const r={p:s},o="q";e.tag&&(r.q=t._queryObject,r.t=e.tag),r.h=e.hashFn(),this.sendRequest(o,r,a=>{const l=a.d,c=a.s;mt.warnOnListenWarnings_(l,t),(this.listens.get(s)&&this.listens.get(s).get(i))===e&&(this.log_("listen response",a),c!=="ok"&&this.removeListen_(s,i),e.onComplete&&e.onComplete(c,l))})}static warnOnListenWarnings_(e,t){if(e&&typeof e=="object"&&Xe(e,"w")){const s=Mt(e,"w");if(Array.isArray(s)&&~s.indexOf("no_index")){const i='".indexOn": "'+t._queryParams.getIndex().toString()+'"',r=t._path.toString();Ne(`Using an unspecified index. Your data will be downloaded and filtered on the client. Consider adding ${i} at ${r} to your security rules for better performance.`)}}}refreshAuthToken(e){this.authToken_=e,this.log_("Auth token refreshed"),this.authToken_?this.tryAuth():this.connected_&&this.sendRequest("unauth",{},()=>{}),this.reduceReconnectDelayIfAdminCredential_(e)}reduceReconnectDelayIfAdminCredential_(e){(e&&e.length===40||Jc(e))&&(this.log_("Admin auth credential detected.  Reducing max reconnect time."),this.maxReconnectDelay_=ca)}refreshAppCheckToken(e){this.appCheckToken_=e,this.log_("App check token refreshed"),this.appCheckToken_?this.tryAppCheck():this.connected_&&this.sendRequest("unappeck",{},()=>{})}tryAuth(){if(this.connected_&&this.authToken_){const e=this.authToken_,t=Qc(e)?"auth":"gauth",s={cred:e};this.authOverride_===null?s.noauth=!0:typeof this.authOverride_=="object"&&(s.authvar=this.authOverride_),this.sendRequest(t,s,i=>{const r=i.s,o=i.d||"error";this.authToken_===e&&(r==="ok"?this.invalidAuthTokenCount_=0:this.onAuthRevoked_(r,o))})}}tryAppCheck(){this.connected_&&this.appCheckToken_&&this.sendRequest("appcheck",{token:this.appCheckToken_},e=>{const t=e.s,s=e.d||"error";t==="ok"?this.invalidAppCheckTokenCount_=0:this.onAppCheckRevoked_(t,s)})}unlisten(e,t){const s=e._path.toString(),i=e._queryIdentifier;this.log_("Unlisten called for "+s+" "+i),w(e._queryParams.isDefault()||!e._queryParams.loadsAllData(),"unlisten() called for non-default but complete query"),this.removeListen_(s,i)&&this.connected_&&this.sendUnlisten_(s,i,e._queryObject,t)}sendUnlisten_(e,t,s,i){this.log_("Unlisten on "+e+" for "+t);const r={p:e},o="n";i&&(r.q=s,r.t=i),this.sendRequest(o,r)}onDisconnectPut(e,t,s){this.initConnection_(),this.connected_?this.sendOnDisconnect_("o",e,t,s):this.onDisconnectRequestQueue_.push({pathString:e,action:"o",data:t,onComplete:s})}onDisconnectMerge(e,t,s){this.initConnection_(),this.connected_?this.sendOnDisconnect_("om",e,t,s):this.onDisconnectRequestQueue_.push({pathString:e,action:"om",data:t,onComplete:s})}onDisconnectCancel(e,t){this.initConnection_(),this.connected_?this.sendOnDisconnect_("oc",e,null,t):this.onDisconnectRequestQueue_.push({pathString:e,action:"oc",data:null,onComplete:t})}sendOnDisconnect_(e,t,s,i){const r={p:t,d:s};this.log_("onDisconnect "+e,r),this.sendRequest(e,r,o=>{i&&setTimeout(()=>{i(o.s,o.d)},Math.floor(0))})}put(e,t,s,i){this.putInternal("p",e,t,s,i)}merge(e,t,s,i){this.putInternal("m",e,t,s,i)}putInternal(e,t,s,i,r){this.initConnection_();const o={p:t,d:s};r!==void 0&&(o.h=r),this.outstandingPuts_.push({action:e,request:o,onComplete:i}),this.outstandingPutCount_++;const a=this.outstandingPuts_.length-1;this.connected_?this.sendPut_(a):this.log_("Buffering put: "+t)}sendPut_(e){const t=this.outstandingPuts_[e].action,s=this.outstandingPuts_[e].request,i=this.outstandingPuts_[e].onComplete;this.outstandingPuts_[e].queued=this.connected_,this.sendRequest(t,s,r=>{this.log_(t+" response",r),delete this.outstandingPuts_[e],this.outstandingPutCount_--,this.outstandingPutCount_===0&&(this.outstandingPuts_=[]),i&&i(r.s,r.d)})}reportStats(e){if(this.connected_){const t={c:e};this.log_("reportStats",t),this.sendRequest("s",t,s=>{if(s.s!=="ok"){const r=s.d;this.log_("reportStats","Error sending stats: "+r)}})}}onDataMessage_(e){if("r"in e){this.log_("from server: "+we(e));const t=e.r,s=this.requestCBHash_[t];s&&(delete this.requestCBHash_[t],s(e.b))}else{if("error"in e)throw"A server-side error has occurred: "+e.error;"a"in e&&this.onDataPush_(e.a,e.b)}}onDataPush_(e,t){this.log_("handleServerMessage",e,t),e==="d"?this.onDataUpdate_(t.p,t.d,!1,t.t):e==="m"?this.onDataUpdate_(t.p,t.d,!0,t.t):e==="c"?this.onListenRevoked_(t.p,t.q):e==="ac"?this.onAuthRevoked_(t.s,t.d):e==="apc"?this.onAppCheckRevoked_(t.s,t.d):e==="sd"?this.onSecurityDebugPacket_(t):Ii("Unrecognized action received from server: "+we(e)+`
Are you using the latest client?`)}onReady_(e,t){this.log_("connection ready"),this.connected_=!0,this.lastConnectionEstablishedTime_=new Date().getTime(),this.handleTimestamp_(e),this.lastSessionId=t,this.firstConnection_&&this.sendConnectStats_(),this.restoreState_(),this.firstConnection_=!1,this.onConnectStatus_(!0)}scheduleConnect_(e){w(!this.realtime_,"Scheduling a connect when we're already connected/ing?"),this.establishConnectionTimer_&&clearTimeout(this.establishConnectionTimer_),this.establishConnectionTimer_=setTimeout(()=>{this.establishConnectionTimer_=null,this.establishConnection_()},Math.floor(e))}initConnection_(){!this.realtime_&&this.firstConnection_&&this.scheduleConnect_(0)}onVisible_(e){e&&!this.visible_&&this.reconnectDelay_===this.maxReconnectDelay_&&(this.log_("Window became visible.  Reducing delay."),this.reconnectDelay_=Un,this.realtime_||this.scheduleConnect_(0)),this.visible_=e}onOnline_(e){e?(this.log_("Browser went online."),this.reconnectDelay_=Un,this.realtime_||this.scheduleConnect_(0)):(this.log_("Browser went offline.  Killing connection."),this.realtime_&&this.realtime_.close())}onRealtimeDisconnect_(){if(this.log_("data client disconnected"),this.connected_=!1,this.realtime_=null,this.cancelSentTransactions_(),this.requestCBHash_={},this.shouldReconnect_()){this.visible_?this.lastConnectionEstablishedTime_&&(new Date().getTime()-this.lastConnectionEstablishedTime_>cd&&(this.reconnectDelay_=Un),this.lastConnectionEstablishedTime_=null):(this.log_("Window isn't visible.  Delaying reconnect."),this.reconnectDelay_=this.maxReconnectDelay_,this.lastConnectionAttemptTime_=new Date().getTime());const e=Math.max(0,new Date().getTime()-this.lastConnectionAttemptTime_);let t=Math.max(0,this.reconnectDelay_-e);t=Math.random()*t,this.log_("Trying to reconnect in "+t+"ms"),this.scheduleConnect_(t),this.reconnectDelay_=Math.min(this.maxReconnectDelay_,this.reconnectDelay_*ld)}this.onConnectStatus_(!1)}async establishConnection_(){if(this.shouldReconnect_()){this.log_("Making a connection attempt"),this.lastConnectionAttemptTime_=new Date().getTime(),this.lastConnectionEstablishedTime_=null;const e=this.onDataMessage_.bind(this),t=this.onReady_.bind(this),s=this.onRealtimeDisconnect_.bind(this),i=this.id+":"+mt.nextConnectionId_++,r=this.lastSessionId;let o=!1,a=null;const l=function(){a?a.close():(o=!0,s())},c=function(d){w(a,"sendRequest call when we're not connected not allowed."),a.sendRequest(d)};this.realtime_={close:l,sendRequest:c};const f=this.forceTokenRefresh_;this.forceTokenRefresh_=!1;try{const[d,h]=await Promise.all([this.authTokenProvider_.getToken(f),this.appCheckTokenProvider_.getToken(f)]);o?Re("getToken() completed but was canceled"):(Re("getToken() completed. Creating connection."),this.authToken_=d&&d.accessToken,this.appCheckToken_=h&&h.token,a=new td(i,this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,e,t,s,y=>{Ne(y+" ("+this.repoInfo_.toString()+")"),this.interrupt(ud)},r))}catch(d){this.log_("Failed to get token: "+d),o||(this.repoInfo_.nodeAdmin&&Ne(d),l())}}}interrupt(e){Re("Interrupting connection for reason: "+e),this.interruptReasons_[e]=!0,this.realtime_?this.realtime_.close():(this.establishConnectionTimer_&&(clearTimeout(this.establishConnectionTimer_),this.establishConnectionTimer_=null),this.connected_&&this.onRealtimeDisconnect_())}resume(e){Re("Resuming connection for reason: "+e),delete this.interruptReasons_[e],io(this.interruptReasons_)&&(this.reconnectDelay_=Un,this.realtime_||this.scheduleConnect_(0))}handleTimestamp_(e){const t=e-new Date().getTime();this.onServerInfoUpdate_({serverTimeOffset:t})}cancelSentTransactions_(){for(let e=0;e<this.outstandingPuts_.length;e++){const t=this.outstandingPuts_[e];t&&"h"in t.request&&t.queued&&(t.onComplete&&t.onComplete("disconnect"),delete this.outstandingPuts_[e],this.outstandingPutCount_--)}this.outstandingPutCount_===0&&(this.outstandingPuts_=[])}onListenRevoked_(e,t){let s;t?s=t.map(r=>Ti(r)).join("$"):s="default";const i=this.removeListen_(e,s);i&&i.onComplete&&i.onComplete("permission_denied")}removeListen_(e,t){const s=new se(e).toString();let i;if(this.listens.has(s)){const r=this.listens.get(s);i=r.get(t),r.delete(t),r.size===0&&this.listens.delete(s)}else i=void 0;return i}onAuthRevoked_(e,t){Re("Auth token revoked: "+e+"/"+t),this.authToken_=null,this.forceTokenRefresh_=!0,this.realtime_.close(),(e==="invalid_token"||e==="permission_denied")&&(this.invalidAuthTokenCount_++,this.invalidAuthTokenCount_>=ua&&(this.reconnectDelay_=ca,this.authTokenProvider_.notifyForInvalidToken()))}onAppCheckRevoked_(e,t){Re("App check token revoked: "+e+"/"+t),this.appCheckToken_=null,this.forceTokenRefresh_=!0,(e==="invalid_token"||e==="permission_denied")&&(this.invalidAppCheckTokenCount_++,this.invalidAppCheckTokenCount_>=ua&&this.appCheckTokenProvider_.notifyForInvalidToken())}onSecurityDebugPacket_(e){this.securityDebugCallback_?this.securityDebugCallback_(e):"msg"in e&&console.log("FIREBASE: "+e.msg.replace(`
`,`
FIREBASE: `))}restoreState_(){this.tryAuth(),this.tryAppCheck();for(const e of this.listens.values())for(const t of e.values())this.sendListen_(t);for(let e=0;e<this.outstandingPuts_.length;e++)this.outstandingPuts_[e]&&this.sendPut_(e);for(;this.onDisconnectRequestQueue_.length;){const e=this.onDisconnectRequestQueue_.shift();this.sendOnDisconnect_(e.action,e.pathString,e.data,e.onComplete)}for(let e=0;e<this.outstandingGets_.length;e++)this.outstandingGets_[e]&&this.sendGet_(e)}sendConnectStats_(){const e={};let t="js";e["sdk."+t+"."+To.replace(/\./g,"-")]=1,ui()?e["framework.cordova"]=1:no()&&(e["framework.reactnative"]=1),this.reportStats(e)}shouldReconnect_(){const e=Es.getInstance().currentlyOnline();return io(this.interruptReasons_)&&e}}mt.nextPersistentConnectionId_=0,mt.nextConnectionId_=0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class G{constructor(e,t){this.name=e,this.node=t}static Wrap(e,t){return new G(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ws{getCompare(){return this.compare.bind(this)}indexedValueChanged(e,t){const s=new G(nn,e),i=new G(nn,t);return this.compare(s,i)!==0}minPost(){return G.MIN}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ss;class ha extends ws{static get __EMPTY_NODE(){return Ss}static set __EMPTY_NODE(e){Ss=e}compare(e,t){return Ht(e.name,t.name)}isDefinedOn(e){throw Xt("KeyIndex.isDefinedOn not expected to be called.")}indexedValueChanged(e,t){return!1}minPost(){return G.MIN}maxPost(){return new G(Gt,Ss)}makePost(e,t){return w(typeof e=="string","KeyIndex indexValue must always be a string."),new G(e,Ss)}toString(){return".key"}}const on=new ha;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cs{constructor(e,t,s,i,r=null){this.isReverse_=i,this.resultGenerator_=r,this.nodeStack_=[];let o=1;for(;!e.isEmpty();)if(e=e,o=t?s(e.key,t):1,i&&(o*=-1),o<0)this.isReverse_?e=e.left:e=e.right;else if(o===0){this.nodeStack_.push(e);break}else this.nodeStack_.push(e),this.isReverse_?e=e.right:e=e.left}getNext(){if(this.nodeStack_.length===0)return null;let e=this.nodeStack_.pop(),t;if(this.resultGenerator_?t=this.resultGenerator_(e.key,e.value):t={key:e.key,value:e.value},this.isReverse_)for(e=e.left;!e.isEmpty();)this.nodeStack_.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack_.push(e),e=e.left;return t}hasNext(){return this.nodeStack_.length>0}peek(){if(this.nodeStack_.length===0)return null;const e=this.nodeStack_[this.nodeStack_.length-1];return this.resultGenerator_?this.resultGenerator_(e.key,e.value):{key:e.key,value:e.value}}}class Se{constructor(e,t,s,i,r){this.key=e,this.value=t,this.color=s??Se.RED,this.left=i??xe.EMPTY_NODE,this.right=r??xe.EMPTY_NODE}copy(e,t,s,i,r){return new Se(e??this.key,t??this.value,s??this.color,i??this.left,r??this.right)}count(){return this.left.count()+1+this.right.count()}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||!!e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min_(){return this.left.isEmpty()?this:this.left.min_()}minKey(){return this.min_().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,s){let i=this;const r=s(e,i.key);return r<0?i=i.copy(null,null,null,i.left.insert(e,t,s),null):r===0?i=i.copy(null,t,null,null,null):i=i.copy(null,null,null,null,i.right.insert(e,t,s)),i.fixUp_()}removeMin_(){if(this.left.isEmpty())return xe.EMPTY_NODE;let e=this;return!e.left.isRed_()&&!e.left.left.isRed_()&&(e=e.moveRedLeft_()),e=e.copy(null,null,null,e.left.removeMin_(),null),e.fixUp_()}remove(e,t){let s,i;if(s=this,t(e,s.key)<0)!s.left.isEmpty()&&!s.left.isRed_()&&!s.left.left.isRed_()&&(s=s.moveRedLeft_()),s=s.copy(null,null,null,s.left.remove(e,t),null);else{if(s.left.isRed_()&&(s=s.rotateRight_()),!s.right.isEmpty()&&!s.right.isRed_()&&!s.right.left.isRed_()&&(s=s.moveRedRight_()),t(e,s.key)===0){if(s.right.isEmpty())return xe.EMPTY_NODE;i=s.right.min_(),s=s.copy(i.key,i.value,null,null,s.right.removeMin_())}s=s.copy(null,null,null,null,s.right.remove(e,t))}return s.fixUp_()}isRed_(){return this.color}fixUp_(){let e=this;return e.right.isRed_()&&!e.left.isRed_()&&(e=e.rotateLeft_()),e.left.isRed_()&&e.left.left.isRed_()&&(e=e.rotateRight_()),e.left.isRed_()&&e.right.isRed_()&&(e=e.colorFlip_()),e}moveRedLeft_(){let e=this.colorFlip_();return e.right.left.isRed_()&&(e=e.copy(null,null,null,null,e.right.rotateRight_()),e=e.rotateLeft_(),e=e.colorFlip_()),e}moveRedRight_(){let e=this.colorFlip_();return e.left.left.isRed_()&&(e=e.rotateRight_(),e=e.colorFlip_()),e}rotateLeft_(){const e=this.copy(null,null,Se.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight_(){const e=this.copy(null,null,Se.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip_(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth_(){const e=this.check_();return Math.pow(2,e)<=this.count()+1}check_(){if(this.isRed_()&&this.left.isRed_())throw new Error("Red node has red child("+this.key+","+this.value+")");if(this.right.isRed_())throw new Error("Right child of ("+this.key+","+this.value+") is red");const e=this.left.check_();if(e!==this.right.check_())throw new Error("Black depths differ");return e+(this.isRed_()?0:1)}}Se.RED=!0,Se.BLACK=!1;class hd{copy(e,t,s,i,r){return this}insert(e,t,s){return new Se(e,t,null)}remove(e,t){return this}count(){return 0}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}check_(){return 0}isRed_(){return!1}}class xe{constructor(e,t=xe.EMPTY_NODE){this.comparator_=e,this.root_=t}insert(e,t){return new xe(this.comparator_,this.root_.insert(e,t,this.comparator_).copy(null,null,Se.BLACK,null,null))}remove(e){return new xe(this.comparator_,this.root_.remove(e,this.comparator_).copy(null,null,Se.BLACK,null,null))}get(e){let t,s=this.root_;for(;!s.isEmpty();){if(t=this.comparator_(e,s.key),t===0)return s.value;t<0?s=s.left:t>0&&(s=s.right)}return null}getPredecessorKey(e){let t,s=this.root_,i=null;for(;!s.isEmpty();)if(t=this.comparator_(e,s.key),t===0){if(s.left.isEmpty())return i?i.key:null;for(s=s.left;!s.right.isEmpty();)s=s.right;return s.key}else t<0?s=s.left:t>0&&(i=s,s=s.right);throw new Error("Attempted to find predecessor key for a nonexistent key.  What gives?")}isEmpty(){return this.root_.isEmpty()}count(){return this.root_.count()}minKey(){return this.root_.minKey()}maxKey(){return this.root_.maxKey()}inorderTraversal(e){return this.root_.inorderTraversal(e)}reverseTraversal(e){return this.root_.reverseTraversal(e)}getIterator(e){return new Cs(this.root_,null,this.comparator_,!1,e)}getIteratorFrom(e,t){return new Cs(this.root_,e,this.comparator_,!1,t)}getReverseIteratorFrom(e,t){return new Cs(this.root_,e,this.comparator_,!0,t)}getReverseIterator(e){return new Cs(this.root_,null,this.comparator_,!0,e)}}xe.EMPTY_NODE=new hd;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function dd(n,e){return Ht(n.name,e.name)}function Fi(n,e){return Ht(n,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ui;function fd(n){Ui=n}const da=function(n){return typeof n=="number"?"number:"+Oo(n):"string:"+n},fa=function(n){if(n.isLeafNode()){const e=n.val();w(typeof e=="string"||typeof e=="number"||typeof e=="object"&&Xe(e,".sv"),"Priority must be a string or number.")}else w(n===Ui||n.isEmpty(),"priority of unexpected type.");w(n===Ui||n.getPriority().isEmpty(),"Priority nodes can't have a priority of their own.")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let pa;class Ce{static set __childrenNodeConstructor(e){pa=e}static get __childrenNodeConstructor(){return pa}constructor(e,t=Ce.__childrenNodeConstructor.EMPTY_NODE){this.value_=e,this.priorityNode_=t,this.lazyHash_=null,w(this.value_!==void 0&&this.value_!==null,"LeafNode shouldn't be created with null/undefined value."),fa(this.priorityNode_)}isLeafNode(){return!0}getPriority(){return this.priorityNode_}updatePriority(e){return new Ce(this.value_,e)}getImmediateChild(e){return e===".priority"?this.priorityNode_:Ce.__childrenNodeConstructor.EMPTY_NODE}getChild(e){return B(e)?this:W(e)===".priority"?this.priorityNode_:Ce.__childrenNodeConstructor.EMPTY_NODE}hasChild(){return!1}getPredecessorChildName(e,t){return null}updateImmediateChild(e,t){return e===".priority"?this.updatePriority(t):t.isEmpty()&&e!==".priority"?this:Ce.__childrenNodeConstructor.EMPTY_NODE.updateImmediateChild(e,t).updatePriority(this.priorityNode_)}updateChild(e,t){const s=W(e);return s===null?t:t.isEmpty()&&s!==".priority"?this:(w(s!==".priority"||bt(e)===1,".priority must be the last token in a path"),this.updateImmediateChild(s,Ce.__childrenNodeConstructor.EMPTY_NODE.updateChild(oe(e),t)))}isEmpty(){return!1}numChildren(){return 0}forEachChild(e,t){return!1}val(e){return e&&!this.getPriority().isEmpty()?{".value":this.getValue(),".priority":this.getPriority().val()}:this.getValue()}hash(){if(this.lazyHash_===null){let e="";this.priorityNode_.isEmpty()||(e+="priority:"+da(this.priorityNode_.val())+":");const t=typeof this.value_;e+=t+":",t==="number"?e+=Oo(this.value_):e+=this.value_,this.lazyHash_=Po(e)}return this.lazyHash_}getValue(){return this.value_}compareTo(e){return e===Ce.__childrenNodeConstructor.EMPTY_NODE?1:e instanceof Ce.__childrenNodeConstructor?-1:(w(e.isLeafNode(),"Unknown node type"),this.compareToLeafNode_(e))}compareToLeafNode_(e){const t=typeof e.value_,s=typeof this.value_,i=Ce.VALUE_TYPE_ORDER.indexOf(t),r=Ce.VALUE_TYPE_ORDER.indexOf(s);return w(i>=0,"Unknown leaf type: "+t),w(r>=0,"Unknown leaf type: "+s),i===r?s==="object"?0:this.value_<e.value_?-1:this.value_===e.value_?0:1:r-i}withIndex(){return this}isIndexed(){return!0}equals(e){if(e===this)return!0;if(e.isLeafNode()){const t=e;return this.value_===t.value_&&this.priorityNode_.equals(t.priorityNode_)}else return!1}}Ce.VALUE_TYPE_ORDER=["object","boolean","number","string"];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let ma,ga;function pd(n){ma=n}function md(n){ga=n}class gd extends ws{compare(e,t){const s=e.node.getPriority(),i=t.node.getPriority(),r=s.compareTo(i);return r===0?Ht(e.name,t.name):r}isDefinedOn(e){return!e.getPriority().isEmpty()}indexedValueChanged(e,t){return!e.getPriority().equals(t.getPriority())}minPost(){return G.MIN}maxPost(){return new G(Gt,new Ce("[PRIORITY-POST]",ga))}makePost(e,t){const s=ma(e);return new G(t,new Ce("[PRIORITY-POST]",s))}toString(){return".priority"}}const he=new gd;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _d=Math.log(2);class yd{constructor(e){const t=r=>parseInt(Math.log(r)/_d,10),s=r=>parseInt(Array(r+1).join("1"),2);this.count=t(e+1),this.current_=this.count-1;const i=s(this.count);this.bits_=e+1&i}nextBitIsOne(){const e=!(this.bits_&1<<this.current_);return this.current_--,e}}const Is=function(n,e,t,s){n.sort(e);const i=function(l,c){const f=c-l;let d,h;if(f===0)return null;if(f===1)return d=n[l],h=t?t(d):d,new Se(h,d.node,Se.BLACK,null,null);{const y=parseInt(f/2,10)+l,E=i(l,y),x=i(y+1,c);return d=n[y],h=t?t(d):d,new Se(h,d.node,Se.BLACK,E,x)}},r=function(l){let c=null,f=null,d=n.length;const h=function(E,x){const j=d-E,Y=d;d-=E;const de=i(j+1,Y),ue=n[j],ge=t?t(ue):ue;y(new Se(ge,ue.node,x,null,de))},y=function(E){c?(c.left=E,c=E):(f=E,c=E)};for(let E=0;E<l.count;++E){const x=l.nextBitIsOne(),j=Math.pow(2,l.count-(E+1));x?h(j,Se.BLACK):(h(j,Se.BLACK),h(j,Se.RED))}return f},o=new yd(n.length),a=r(o);return new xe(s||e,a)};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Wi;const an={};class gt{static get Default(){return w(an&&he,"ChildrenNode.ts has not been loaded"),Wi=Wi||new gt({".priority":an},{".priority":he}),Wi}constructor(e,t){this.indexes_=e,this.indexSet_=t}get(e){const t=Mt(this.indexes_,e);if(!t)throw new Error("No index defined for "+e);return t instanceof xe?t:null}hasIndex(e){return Xe(this.indexSet_,e.toString())}addIndex(e,t){w(e!==on,"KeyIndex always exists and isn't meant to be added to the IndexMap.");const s=[];let i=!1;const r=t.getIterator(G.Wrap);let o=r.getNext();for(;o;)i=i||e.isDefinedOn(o.node),s.push(o),o=r.getNext();let a;i?a=Is(s,e.getCompare()):a=an;const l=e.toString(),c=Object.assign({},this.indexSet_);c[l]=e;const f=Object.assign({},this.indexes_);return f[l]=a,new gt(f,c)}addToIndexes(e,t){const s=ps(this.indexes_,(i,r)=>{const o=Mt(this.indexSet_,r);if(w(o,"Missing index implementation for "+r),i===an)if(o.isDefinedOn(e.node)){const a=[],l=t.getIterator(G.Wrap);let c=l.getNext();for(;c;)c.name!==e.name&&a.push(c),c=l.getNext();return a.push(e),Is(a,o.getCompare())}else return an;else{const a=t.get(e.name);let l=i;return a&&(l=l.remove(new G(e.name,a))),l.insert(e,e.node)}});return new gt(s,this.indexSet_)}removeFromIndexes(e,t){const s=ps(this.indexes_,i=>{if(i===an)return i;{const r=t.get(e.name);return r?i.remove(new G(e.name,r)):i}});return new gt(s,this.indexSet_)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Wn;class L{static get EMPTY_NODE(){return Wn||(Wn=new L(new xe(Fi),null,gt.Default))}constructor(e,t,s){this.children_=e,this.priorityNode_=t,this.indexMap_=s,this.lazyHash_=null,this.priorityNode_&&fa(this.priorityNode_),this.children_.isEmpty()&&w(!this.priorityNode_||this.priorityNode_.isEmpty(),"An empty node cannot have a priority")}isLeafNode(){return!1}getPriority(){return this.priorityNode_||Wn}updatePriority(e){return this.children_.isEmpty()?this:new L(this.children_,e,this.indexMap_)}getImmediateChild(e){if(e===".priority")return this.getPriority();{const t=this.children_.get(e);return t===null?Wn:t}}getChild(e){const t=W(e);return t===null?this:this.getImmediateChild(t).getChild(oe(e))}hasChild(e){return this.children_.get(e)!==null}updateImmediateChild(e,t){if(w(t,"We should always be passing snapshot nodes"),e===".priority")return this.updatePriority(t);{const s=new G(e,t);let i,r;t.isEmpty()?(i=this.children_.remove(e),r=this.indexMap_.removeFromIndexes(s,this.children_)):(i=this.children_.insert(e,t),r=this.indexMap_.addToIndexes(s,this.children_));const o=i.isEmpty()?Wn:this.priorityNode_;return new L(i,o,r)}}updateChild(e,t){const s=W(e);if(s===null)return t;{w(W(e)!==".priority"||bt(e)===1,".priority must be the last token in a path");const i=this.getImmediateChild(s).updateChild(oe(e),t);return this.updateImmediateChild(s,i)}}isEmpty(){return this.children_.isEmpty()}numChildren(){return this.children_.count()}val(e){if(this.isEmpty())return null;const t={};let s=0,i=0,r=!0;if(this.forEachChild(he,(o,a)=>{t[o]=a.val(e),s++,r&&L.INTEGER_REGEXP_.test(o)?i=Math.max(i,Number(o)):r=!1}),!e&&r&&i<2*s){const o=[];for(const a in t)o[a]=t[a];return o}else return e&&!this.getPriority().isEmpty()&&(t[".priority"]=this.getPriority().val()),t}hash(){if(this.lazyHash_===null){let e="";this.getPriority().isEmpty()||(e+="priority:"+da(this.getPriority().val())+":"),this.forEachChild(he,(t,s)=>{const i=s.hash();i!==""&&(e+=":"+t+":"+i)}),this.lazyHash_=e===""?"":Po(e)}return this.lazyHash_}getPredecessorChildName(e,t,s){const i=this.resolveIndex_(s);if(i){const r=i.getPredecessorKey(new G(e,t));return r?r.name:null}else return this.children_.getPredecessorKey(e)}getFirstChildName(e){const t=this.resolveIndex_(e);if(t){const s=t.minKey();return s&&s.name}else return this.children_.minKey()}getFirstChild(e){const t=this.getFirstChildName(e);return t?new G(t,this.children_.get(t)):null}getLastChildName(e){const t=this.resolveIndex_(e);if(t){const s=t.maxKey();return s&&s.name}else return this.children_.maxKey()}getLastChild(e){const t=this.getLastChildName(e);return t?new G(t,this.children_.get(t)):null}forEachChild(e,t){const s=this.resolveIndex_(e);return s?s.inorderTraversal(i=>t(i.name,i.node)):this.children_.inorderTraversal(t)}getIterator(e){return this.getIteratorFrom(e.minPost(),e)}getIteratorFrom(e,t){const s=this.resolveIndex_(t);if(s)return s.getIteratorFrom(e,i=>i);{const i=this.children_.getIteratorFrom(e.name,G.Wrap);let r=i.peek();for(;r!=null&&t.compare(r,e)<0;)i.getNext(),r=i.peek();return i}}getReverseIterator(e){return this.getReverseIteratorFrom(e.maxPost(),e)}getReverseIteratorFrom(e,t){const s=this.resolveIndex_(t);if(s)return s.getReverseIteratorFrom(e,i=>i);{const i=this.children_.getReverseIteratorFrom(e.name,G.Wrap);let r=i.peek();for(;r!=null&&t.compare(r,e)>0;)i.getNext(),r=i.peek();return i}}compareTo(e){return this.isEmpty()?e.isEmpty()?0:-1:e.isLeafNode()||e.isEmpty()?1:e===Gn?-1:0}withIndex(e){if(e===on||this.indexMap_.hasIndex(e))return this;{const t=this.indexMap_.addIndex(e,this.children_);return new L(this.children_,this.priorityNode_,t)}}isIndexed(e){return e===on||this.indexMap_.hasIndex(e)}equals(e){if(e===this)return!0;if(e.isLeafNode())return!1;{const t=e;if(this.getPriority().equals(t.getPriority()))if(this.children_.count()===t.children_.count()){const s=this.getIterator(he),i=t.getIterator(he);let r=s.getNext(),o=i.getNext();for(;r&&o;){if(r.name!==o.name||!r.node.equals(o.node))return!1;r=s.getNext(),o=i.getNext()}return r===null&&o===null}else return!1;else return!1}}resolveIndex_(e){return e===on?null:this.indexMap_.get(e.toString())}}L.INTEGER_REGEXP_=/^(0|[1-9]\d*)$/;class vd extends L{constructor(){super(new xe(Fi),L.EMPTY_NODE,gt.Default)}compareTo(e){return e===this?0:1}equals(e){return e===this}getPriority(){return this}getImmediateChild(e){return L.EMPTY_NODE}isEmpty(){return!1}}const Gn=new vd;Object.defineProperties(G,{MIN:{value:new G(nn,L.EMPTY_NODE)},MAX:{value:new G(Gt,Gn)}}),ha.__EMPTY_NODE=L.EMPTY_NODE,Ce.__childrenNodeConstructor=L,fd(Gn),md(Gn);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ed=!0;function ye(n,e=null){if(n===null)return L.EMPTY_NODE;if(typeof n=="object"&&".priority"in n&&(e=n[".priority"]),w(e===null||typeof e=="string"||typeof e=="number"||typeof e=="object"&&".sv"in e,"Invalid priority type found: "+typeof e),typeof n=="object"&&".value"in n&&n[".value"]!==null&&(n=n[".value"]),typeof n!="object"||".sv"in n){const t=n;return new Ce(t,ye(e))}if(!(n instanceof Array)&&Ed){const t=[];let s=!1;if(Pe(n,(o,a)=>{if(o.substring(0,1)!=="."){const l=ye(a);l.isEmpty()||(s=s||!l.getPriority().isEmpty(),t.push(new G(o,l)))}}),t.length===0)return L.EMPTY_NODE;const r=Is(t,dd,o=>o.name,Fi);if(s){const o=Is(t,he.getCompare());return new L(r,ye(e),new gt({".priority":o},{".priority":he}))}else return new L(r,ye(e),gt.Default)}else{let t=L.EMPTY_NODE;return Pe(n,(s,i)=>{if(Xe(n,s)&&s.substring(0,1)!=="."){const r=ye(i);(r.isLeafNode()||!r.isEmpty())&&(t=t.updateImmediateChild(s,r))}}),t.updatePriority(ye(e))}}pd(ye);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wd extends ws{constructor(e){super(),this.indexPath_=e,w(!B(e)&&W(e)!==".priority","Can't create PathIndex with empty path or .priority key")}extractChild(e){return e.getChild(this.indexPath_)}isDefinedOn(e){return!e.getChild(this.indexPath_).isEmpty()}compare(e,t){const s=this.extractChild(e.node),i=this.extractChild(t.node),r=s.compareTo(i);return r===0?Ht(e.name,t.name):r}makePost(e,t){const s=ye(e),i=L.EMPTY_NODE.updateChild(this.indexPath_,s);return new G(t,i)}maxPost(){const e=L.EMPTY_NODE.updateChild(this.indexPath_,Gn);return new G(Gt,e)}toString(){return Fn(this.indexPath_,0).join("/")}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sd extends ws{compare(e,t){const s=e.node.compareTo(t.node);return s===0?Ht(e.name,t.name):s}isDefinedOn(e){return!0}indexedValueChanged(e,t){return!e.equals(t)}minPost(){return G.MIN}maxPost(){return G.MAX}makePost(e,t){const s=ye(e);return new G(t,s)}toString(){return".value"}}const Cd=new Sd;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _a(n){return{type:"value",snapshotNode:n}}function ln(n,e){return{type:"child_added",snapshotNode:e,childName:n}}function Hn(n,e){return{type:"child_removed",snapshotNode:e,childName:n}}function Bn(n,e,t){return{type:"child_changed",snapshotNode:e,childName:n,oldSnap:t}}function Id(n,e){return{type:"child_moved",snapshotNode:e,childName:n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gi{constructor(e){this.index_=e}updateChild(e,t,s,i,r,o){w(e.isIndexed(this.index_),"A node must be indexed if only a child is updated");const a=e.getImmediateChild(t);return a.getChild(i).equals(s.getChild(i))&&a.isEmpty()===s.isEmpty()||(o!=null&&(s.isEmpty()?e.hasChild(t)?o.trackChildChange(Hn(t,a)):w(e.isLeafNode(),"A child remove without an old child only makes sense on a leaf node"):a.isEmpty()?o.trackChildChange(ln(t,s)):o.trackChildChange(Bn(t,s,a))),e.isLeafNode()&&s.isEmpty())?e:e.updateImmediateChild(t,s).withIndex(this.index_)}updateFullNode(e,t,s){return s!=null&&(e.isLeafNode()||e.forEachChild(he,(i,r)=>{t.hasChild(i)||s.trackChildChange(Hn(i,r))}),t.isLeafNode()||t.forEachChild(he,(i,r)=>{if(e.hasChild(i)){const o=e.getImmediateChild(i);o.equals(r)||s.trackChildChange(Bn(i,r,o))}else s.trackChildChange(ln(i,r))})),t.withIndex(this.index_)}updatePriority(e,t){return e.isEmpty()?L.EMPTY_NODE:e.updatePriority(t)}filtersNodes(){return!1}getIndexedFilter(){return this}getIndex(){return this.index_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $n{constructor(e){this.indexedFilter_=new Gi(e.getIndex()),this.index_=e.getIndex(),this.startPost_=$n.getStartPost_(e),this.endPost_=$n.getEndPost_(e),this.startIsInclusive_=!e.startAfterSet_,this.endIsInclusive_=!e.endBeforeSet_}getStartPost(){return this.startPost_}getEndPost(){return this.endPost_}matches(e){const t=this.startIsInclusive_?this.index_.compare(this.getStartPost(),e)<=0:this.index_.compare(this.getStartPost(),e)<0,s=this.endIsInclusive_?this.index_.compare(e,this.getEndPost())<=0:this.index_.compare(e,this.getEndPost())<0;return t&&s}updateChild(e,t,s,i,r,o){return this.matches(new G(t,s))||(s=L.EMPTY_NODE),this.indexedFilter_.updateChild(e,t,s,i,r,o)}updateFullNode(e,t,s){t.isLeafNode()&&(t=L.EMPTY_NODE);let i=t.withIndex(this.index_);i=i.updatePriority(L.EMPTY_NODE);const r=this;return t.forEachChild(he,(o,a)=>{r.matches(new G(o,a))||(i=i.updateImmediateChild(o,L.EMPTY_NODE))}),this.indexedFilter_.updateFullNode(e,i,s)}updatePriority(e,t){return e}filtersNodes(){return!0}getIndexedFilter(){return this.indexedFilter_}getIndex(){return this.index_}static getStartPost_(e){if(e.hasStart()){const t=e.getIndexStartName();return e.getIndex().makePost(e.getIndexStartValue(),t)}else return e.getIndex().minPost()}static getEndPost_(e){if(e.hasEnd()){const t=e.getIndexEndName();return e.getIndex().makePost(e.getIndexEndValue(),t)}else return e.getIndex().maxPost()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bd{constructor(e){this.withinDirectionalStart=t=>this.reverse_?this.withinEndPost(t):this.withinStartPost(t),this.withinDirectionalEnd=t=>this.reverse_?this.withinStartPost(t):this.withinEndPost(t),this.withinStartPost=t=>{const s=this.index_.compare(this.rangedFilter_.getStartPost(),t);return this.startIsInclusive_?s<=0:s<0},this.withinEndPost=t=>{const s=this.index_.compare(t,this.rangedFilter_.getEndPost());return this.endIsInclusive_?s<=0:s<0},this.rangedFilter_=new $n(e),this.index_=e.getIndex(),this.limit_=e.getLimit(),this.reverse_=!e.isViewFromLeft(),this.startIsInclusive_=!e.startAfterSet_,this.endIsInclusive_=!e.endBeforeSet_}updateChild(e,t,s,i,r,o){return this.rangedFilter_.matches(new G(t,s))||(s=L.EMPTY_NODE),e.getImmediateChild(t).equals(s)?e:e.numChildren()<this.limit_?this.rangedFilter_.getIndexedFilter().updateChild(e,t,s,i,r,o):this.fullLimitUpdateChild_(e,t,s,r,o)}updateFullNode(e,t,s){let i;if(t.isLeafNode()||t.isEmpty())i=L.EMPTY_NODE.withIndex(this.index_);else if(this.limit_*2<t.numChildren()&&t.isIndexed(this.index_)){i=L.EMPTY_NODE.withIndex(this.index_);let r;this.reverse_?r=t.getReverseIteratorFrom(this.rangedFilter_.getEndPost(),this.index_):r=t.getIteratorFrom(this.rangedFilter_.getStartPost(),this.index_);let o=0;for(;r.hasNext()&&o<this.limit_;){const a=r.getNext();if(this.withinDirectionalStart(a))if(this.withinDirectionalEnd(a))i=i.updateImmediateChild(a.name,a.node),o++;else break;else continue}}else{i=t.withIndex(this.index_),i=i.updatePriority(L.EMPTY_NODE);let r;this.reverse_?r=i.getReverseIterator(this.index_):r=i.getIterator(this.index_);let o=0;for(;r.hasNext();){const a=r.getNext();o<this.limit_&&this.withinDirectionalStart(a)&&this.withinDirectionalEnd(a)?o++:i=i.updateImmediateChild(a.name,L.EMPTY_NODE)}}return this.rangedFilter_.getIndexedFilter().updateFullNode(e,i,s)}updatePriority(e,t){return e}filtersNodes(){return!0}getIndexedFilter(){return this.rangedFilter_.getIndexedFilter()}getIndex(){return this.index_}fullLimitUpdateChild_(e,t,s,i,r){let o;if(this.reverse_){const d=this.index_.getCompare();o=(h,y)=>d(y,h)}else o=this.index_.getCompare();const a=e;w(a.numChildren()===this.limit_,"");const l=new G(t,s),c=this.reverse_?a.getFirstChild(this.index_):a.getLastChild(this.index_),f=this.rangedFilter_.matches(l);if(a.hasChild(t)){const d=a.getImmediateChild(t);let h=i.getChildAfterChild(this.index_,c,this.reverse_);for(;h!=null&&(h.name===t||a.hasChild(h.name));)h=i.getChildAfterChild(this.index_,h,this.reverse_);const y=h==null?1:o(h,l);if(f&&!s.isEmpty()&&y>=0)return r!=null&&r.trackChildChange(Bn(t,s,d)),a.updateImmediateChild(t,s);{r!=null&&r.trackChildChange(Hn(t,d));const x=a.updateImmediateChild(t,L.EMPTY_NODE);return h!=null&&this.rangedFilter_.matches(h)?(r!=null&&r.trackChildChange(ln(h.name,h.node)),x.updateImmediateChild(h.name,h.node)):x}}else return s.isEmpty()?e:f&&o(c,l)>=0?(r!=null&&(r.trackChildChange(Hn(c.name,c.node)),r.trackChildChange(ln(t,s))),a.updateImmediateChild(t,s).updateImmediateChild(c.name,L.EMPTY_NODE)):e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hi{constructor(){this.limitSet_=!1,this.startSet_=!1,this.startNameSet_=!1,this.startAfterSet_=!1,this.endSet_=!1,this.endNameSet_=!1,this.endBeforeSet_=!1,this.limit_=0,this.viewFrom_="",this.indexStartValue_=null,this.indexStartName_="",this.indexEndValue_=null,this.indexEndName_="",this.index_=he}hasStart(){return this.startSet_}isViewFromLeft(){return this.viewFrom_===""?this.startSet_:this.viewFrom_==="l"}getIndexStartValue(){return w(this.startSet_,"Only valid if start has been set"),this.indexStartValue_}getIndexStartName(){return w(this.startSet_,"Only valid if start has been set"),this.startNameSet_?this.indexStartName_:nn}hasEnd(){return this.endSet_}getIndexEndValue(){return w(this.endSet_,"Only valid if end has been set"),this.indexEndValue_}getIndexEndName(){return w(this.endSet_,"Only valid if end has been set"),this.endNameSet_?this.indexEndName_:Gt}hasLimit(){return this.limitSet_}hasAnchoredLimit(){return this.limitSet_&&this.viewFrom_!==""}getLimit(){return w(this.limitSet_,"Only valid if limit has been set"),this.limit_}getIndex(){return this.index_}loadsAllData(){return!(this.startSet_||this.endSet_||this.limitSet_)}isDefault(){return this.loadsAllData()&&this.index_===he}copy(){const e=new Hi;return e.limitSet_=this.limitSet_,e.limit_=this.limit_,e.startSet_=this.startSet_,e.startAfterSet_=this.startAfterSet_,e.indexStartValue_=this.indexStartValue_,e.startNameSet_=this.startNameSet_,e.indexStartName_=this.indexStartName_,e.endSet_=this.endSet_,e.endBeforeSet_=this.endBeforeSet_,e.indexEndValue_=this.indexEndValue_,e.endNameSet_=this.endNameSet_,e.indexEndName_=this.indexEndName_,e.index_=this.index_,e.viewFrom_=this.viewFrom_,e}}function Td(n){return n.loadsAllData()?new Gi(n.getIndex()):n.hasLimit()?new bd(n):new $n(n)}function ya(n){const e={};if(n.isDefault())return e;let t;if(n.index_===he?t="$priority":n.index_===Cd?t="$value":n.index_===on?t="$key":(w(n.index_ instanceof wd,"Unrecognized index type!"),t=n.index_.toString()),e.orderBy=we(t),n.startSet_){const s=n.startAfterSet_?"startAfter":"startAt";e[s]=we(n.indexStartValue_),n.startNameSet_&&(e[s]+=","+we(n.indexStartName_))}if(n.endSet_){const s=n.endBeforeSet_?"endBefore":"endAt";e[s]=we(n.indexEndValue_),n.endNameSet_&&(e[s]+=","+we(n.indexEndName_))}return n.limitSet_&&(n.isViewFromLeft()?e.limitToFirst=n.limit_:e.limitToLast=n.limit_),e}function va(n){const e={};if(n.startSet_&&(e.sp=n.indexStartValue_,n.startNameSet_&&(e.sn=n.indexStartName_),e.sin=!n.startAfterSet_),n.endSet_&&(e.ep=n.indexEndValue_,n.endNameSet_&&(e.en=n.indexEndName_),e.ein=!n.endBeforeSet_),n.limitSet_){e.l=n.limit_;let t=n.viewFrom_;t===""&&(n.isViewFromLeft()?t="l":t="r"),e.vf=t}return n.index_!==he&&(e.i=n.index_.toString()),e}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bs extends sa{reportStats(e){throw new Error("Method not implemented.")}static getListenId_(e,t){return t!==void 0?"tag$"+t:(w(e._queryParams.isDefault(),"should have a tag if it's not a default query."),e._path.toString())}constructor(e,t,s,i){super(),this.repoInfo_=e,this.onDataUpdate_=t,this.authTokenProvider_=s,this.appCheckTokenProvider_=i,this.log_=Ln("p:rest:"),this.listens_={}}listen(e,t,s,i){const r=e._path.toString();this.log_("Listen called for "+r+" "+e._queryIdentifier);const o=bs.getListenId_(e,s),a={};this.listens_[o]=a;const l=ya(e._queryParams);this.restRequest_(r+".json",l,(c,f)=>{let d=f;if(c===404&&(d=null,c=null),c===null&&this.onDataUpdate_(r,d,!1,s),Mt(this.listens_,o)===a){let h;c?c===401?h="permission_denied":h="rest_error:"+c:h="ok",i(h,null)}})}unlisten(e,t){const s=bs.getListenId_(e,t);delete this.listens_[s]}get(e){const t=ya(e._queryParams),s=e._path.toString(),i=new Zt;return this.restRequest_(s+".json",t,(r,o)=>{let a=o;r===404&&(a=null,r=null),r===null?(this.onDataUpdate_(s,a,!1,null),i.resolve(a)):i.reject(new Error(a))}),i.promise}refreshAuthToken(e){}restRequest_(e,t={},s){return t.format="export",Promise.all([this.authTokenProvider_.getToken(!1),this.appCheckTokenProvider_.getToken(!1)]).then(([i,r])=>{i&&i.accessToken&&(t.auth=i.accessToken),r&&r.token&&(t.ac=r.token);const o=(this.repoInfo_.secure?"https://":"http://")+this.repoInfo_.host+e+"?ns="+this.repoInfo_.namespace+hi(t);this.log_("Sending REST request for "+o);const a=new XMLHttpRequest;a.onreadystatechange=()=>{if(s&&a.readyState===4){this.log_("REST Response for "+o+" received. status:",a.status,"response:",a.responseText);let l=null;if(a.status>=200&&a.status<300){try{l=An(a.responseText)}catch{Ne("Failed to parse JSON response for "+o+": "+a.responseText)}s(null,l)}else a.status!==401&&a.status!==404&&Ne("Got unsuccessful REST response for "+o+" Status: "+a.status),s(a.status);s=null}},a.open("GET",o,!0),a.send()})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ad{constructor(){this.rootNode_=L.EMPTY_NODE}getNode(e){return this.rootNode_.getChild(e)}updateSnapshot(e,t){this.rootNode_=this.rootNode_.updateChild(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ts(){return{value:null,children:new Map}}function Ea(n,e,t){if(B(e))n.value=t,n.children.clear();else if(n.value!==null)n.value=n.value.updateChild(e,t);else{const s=W(e);n.children.has(s)||n.children.set(s,Ts());const i=n.children.get(s);e=oe(e),Ea(i,e,t)}}function Bi(n,e,t){n.value!==null?t(e,n.value):Rd(n,(s,i)=>{const r=new se(e.toString()+"/"+s);Bi(i,r,t)})}function Rd(n,e){n.children.forEach((t,s)=>{e(s,t)})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pd{constructor(e){this.collection_=e,this.last_=null}get(){const e=this.collection_.get(),t=Object.assign({},e);return this.last_&&Pe(this.last_,(s,i)=>{t[s]=t[s]-i}),this.last_=e,t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wa=10*1e3,Nd=30*1e3,kd=300*1e3;class Od{constructor(e,t){this.server_=t,this.statsToReport_={},this.statsListener_=new Pd(e);const s=wa+(Nd-wa)*Math.random();xn(this.reportStats_.bind(this),Math.floor(s))}reportStats_(){const e=this.statsListener_.get(),t={};let s=!1;Pe(e,(i,r)=>{r>0&&Xe(this.statsToReport_,i)&&(t[i]=r,s=!0)}),s&&this.server_.reportStats(t),xn(this.reportStats_.bind(this),Math.floor(Math.random()*2*kd))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var et;(function(n){n[n.OVERWRITE=0]="OVERWRITE",n[n.MERGE=1]="MERGE",n[n.ACK_USER_WRITE=2]="ACK_USER_WRITE",n[n.LISTEN_COMPLETE=3]="LISTEN_COMPLETE"})(et||(et={}));function $i(){return{fromUser:!0,fromServer:!1,queryId:null,tagged:!1}}function Vi(){return{fromUser:!1,fromServer:!0,queryId:null,tagged:!1}}function ji(n){return{fromUser:!1,fromServer:!0,queryId:n,tagged:!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class As{constructor(e,t,s){this.path=e,this.affectedTree=t,this.revert=s,this.type=et.ACK_USER_WRITE,this.source=$i()}operationForChild(e){if(B(this.path)){if(this.affectedTree.value!=null)return w(this.affectedTree.children.isEmpty(),"affectedTree should not have overlapping affected paths."),this;{const t=this.affectedTree.subtree(new se(e));return new As(Q(),t,this.revert)}}else return w(W(this.path)===e,"operationForChild called for unrelated child."),new As(oe(this.path),this.affectedTree,this.revert)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vn{constructor(e,t){this.source=e,this.path=t,this.type=et.LISTEN_COMPLETE}operationForChild(e){return B(this.path)?new Vn(this.source,Q()):new Vn(this.source,oe(this.path))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $t{constructor(e,t,s){this.source=e,this.path=t,this.snap=s,this.type=et.OVERWRITE}operationForChild(e){return B(this.path)?new $t(this.source,Q(),this.snap.getImmediateChild(e)):new $t(this.source,oe(this.path),this.snap)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cn{constructor(e,t,s){this.source=e,this.path=t,this.children=s,this.type=et.MERGE}operationForChild(e){if(B(this.path)){const t=this.children.subtree(new se(e));return t.isEmpty()?null:t.value?new $t(this.source,Q(),t.value):new cn(this.source,Q(),t)}else return w(W(this.path)===e,"Can't get a merge for a child not on the path of the operation"),new cn(this.source,oe(this.path),this.children)}toString(){return"Operation("+this.path+": "+this.source.toString()+" merge: "+this.children.toString()+")"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tt{constructor(e,t,s){this.node_=e,this.fullyInitialized_=t,this.filtered_=s}isFullyInitialized(){return this.fullyInitialized_}isFiltered(){return this.filtered_}isCompleteForPath(e){if(B(e))return this.isFullyInitialized()&&!this.filtered_;const t=W(e);return this.isCompleteForChild(t)}isCompleteForChild(e){return this.isFullyInitialized()&&!this.filtered_||this.node_.hasChild(e)}getNode(){return this.node_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ld{constructor(e){this.query_=e,this.index_=this.query_._queryParams.getIndex()}}function Dd(n,e,t,s){const i=[],r=[];return e.forEach(o=>{o.type==="child_changed"&&n.index_.indexedValueChanged(o.oldSnap,o.snapshotNode)&&r.push(Id(o.childName,o.snapshotNode))}),jn(n,i,"child_removed",e,s,t),jn(n,i,"child_added",e,s,t),jn(n,i,"child_moved",r,s,t),jn(n,i,"child_changed",e,s,t),jn(n,i,"value",e,s,t),i}function jn(n,e,t,s,i,r){const o=s.filter(a=>a.type===t);o.sort((a,l)=>Md(n,a,l)),o.forEach(a=>{const l=xd(n,a,r);i.forEach(c=>{c.respondsTo(a.type)&&e.push(c.createEvent(l,n.query_))})})}function xd(n,e,t){return e.type==="value"||e.type==="child_removed"||(e.prevName=t.getPredecessorChildName(e.childName,e.snapshotNode,n.index_)),e}function Md(n,e,t){if(e.childName==null||t.childName==null)throw Xt("Should only compare child_ events.");const s=new G(e.childName,e.snapshotNode),i=new G(t.childName,t.snapshotNode);return n.index_.compare(s,i)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Rs(n,e){return{eventCache:n,serverCache:e}}function zn(n,e,t,s){return Rs(new Tt(e,t,s),n.serverCache)}function Sa(n,e,t,s){return Rs(n.eventCache,new Tt(e,t,s))}function Ps(n){return n.eventCache.isFullyInitialized()?n.eventCache.getNode():null}function Vt(n){return n.serverCache.isFullyInitialized()?n.serverCache.getNode():null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let zi;const Fd=()=>(zi||(zi=new xe(wh)),zi);class ae{static fromObject(e){let t=new ae(null);return Pe(e,(s,i)=>{t=t.set(new se(s),i)}),t}constructor(e,t=Fd()){this.value=e,this.children=t}isEmpty(){return this.value===null&&this.children.isEmpty()}findRootMostMatchingPathAndValue(e,t){if(this.value!=null&&t(this.value))return{path:Q(),value:this.value};if(B(e))return null;{const s=W(e),i=this.children.get(s);if(i!==null){const r=i.findRootMostMatchingPathAndValue(oe(e),t);return r!=null?{path:pe(new se(s),r.path),value:r.value}:null}else return null}}findRootMostValueAndPath(e){return this.findRootMostMatchingPathAndValue(e,()=>!0)}subtree(e){if(B(e))return this;{const t=W(e),s=this.children.get(t);return s!==null?s.subtree(oe(e)):new ae(null)}}set(e,t){if(B(e))return new ae(t,this.children);{const s=W(e),r=(this.children.get(s)||new ae(null)).set(oe(e),t),o=this.children.insert(s,r);return new ae(this.value,o)}}remove(e){if(B(e))return this.children.isEmpty()?new ae(null):new ae(null,this.children);{const t=W(e),s=this.children.get(t);if(s){const i=s.remove(oe(e));let r;return i.isEmpty()?r=this.children.remove(t):r=this.children.insert(t,i),this.value===null&&r.isEmpty()?new ae(null):new ae(this.value,r)}else return this}}get(e){if(B(e))return this.value;{const t=W(e),s=this.children.get(t);return s?s.get(oe(e)):null}}setTree(e,t){if(B(e))return t;{const s=W(e),r=(this.children.get(s)||new ae(null)).setTree(oe(e),t);let o;return r.isEmpty()?o=this.children.remove(s):o=this.children.insert(s,r),new ae(this.value,o)}}fold(e){return this.fold_(Q(),e)}fold_(e,t){const s={};return this.children.inorderTraversal((i,r)=>{s[i]=r.fold_(pe(e,i),t)}),t(e,this.value,s)}findOnPath(e,t){return this.findOnPath_(e,Q(),t)}findOnPath_(e,t,s){const i=this.value?s(t,this.value):!1;if(i)return i;if(B(e))return null;{const r=W(e),o=this.children.get(r);return o?o.findOnPath_(oe(e),pe(t,r),s):null}}foreachOnPath(e,t){return this.foreachOnPath_(e,Q(),t)}foreachOnPath_(e,t,s){if(B(e))return this;{this.value&&s(t,this.value);const i=W(e),r=this.children.get(i);return r?r.foreachOnPath_(oe(e),pe(t,i),s):new ae(null)}}foreach(e){this.foreach_(Q(),e)}foreach_(e,t){this.children.inorderTraversal((s,i)=>{i.foreach_(pe(e,s),t)}),this.value&&t(e,this.value)}foreachChild(e){this.children.inorderTraversal((t,s)=>{s.value&&e(t,s.value)})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tt{constructor(e){this.writeTree_=e}static empty(){return new tt(new ae(null))}}function Kn(n,e,t){if(B(e))return new tt(new ae(t));{const s=n.writeTree_.findRootMostValueAndPath(e);if(s!=null){const i=s.path;let r=s.value;const o=ke(i,e);return r=r.updateChild(o,t),new tt(n.writeTree_.set(i,r))}else{const i=new ae(t),r=n.writeTree_.setTree(e,i);return new tt(r)}}}function Ki(n,e,t){let s=n;return Pe(t,(i,r)=>{s=Kn(s,pe(e,i),r)}),s}function Ca(n,e){if(B(e))return tt.empty();{const t=n.writeTree_.setTree(e,new ae(null));return new tt(t)}}function qi(n,e){return jt(n,e)!=null}function jt(n,e){const t=n.writeTree_.findRootMostValueAndPath(e);return t!=null?n.writeTree_.get(t.path).getChild(ke(t.path,e)):null}function Ia(n){const e=[],t=n.writeTree_.value;return t!=null?t.isLeafNode()||t.forEachChild(he,(s,i)=>{e.push(new G(s,i))}):n.writeTree_.children.inorderTraversal((s,i)=>{i.value!=null&&e.push(new G(s,i.value))}),e}function At(n,e){if(B(e))return n;{const t=jt(n,e);return t!=null?new tt(new ae(t)):new tt(n.writeTree_.subtree(e))}}function Yi(n){return n.writeTree_.isEmpty()}function un(n,e){return ba(Q(),n.writeTree_,e)}function ba(n,e,t){if(e.value!=null)return t.updateChild(n,e.value);{let s=null;return e.children.inorderTraversal((i,r)=>{i===".priority"?(w(r.value!==null,"Priority writes must always be leaf nodes"),s=r.value):t=ba(pe(n,i),r,t)}),!t.getChild(n).isEmpty()&&s!==null&&(t=t.updateChild(pe(n,".priority"),s)),t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ns(n,e){return Na(e,n)}function Ud(n,e,t,s,i){w(s>n.lastWriteId,"Stacking an older write on top of newer ones"),i===void 0&&(i=!0),n.allWrites.push({path:e,snap:t,writeId:s,visible:i}),i&&(n.visibleWrites=Kn(n.visibleWrites,e,t)),n.lastWriteId=s}function Wd(n,e,t,s){w(s>n.lastWriteId,"Stacking an older merge on top of newer ones"),n.allWrites.push({path:e,children:t,writeId:s,visible:!0}),n.visibleWrites=Ki(n.visibleWrites,e,t),n.lastWriteId=s}function Gd(n,e){for(let t=0;t<n.allWrites.length;t++){const s=n.allWrites[t];if(s.writeId===e)return s}return null}function Hd(n,e){const t=n.allWrites.findIndex(a=>a.writeId===e);w(t>=0,"removeWrite called with nonexistent writeId.");const s=n.allWrites[t];n.allWrites.splice(t,1);let i=s.visible,r=!1,o=n.allWrites.length-1;for(;i&&o>=0;){const a=n.allWrites[o];a.visible&&(o>=t&&Bd(a,s.path)?i=!1:Be(s.path,a.path)&&(r=!0)),o--}if(i){if(r)return $d(n),!0;if(s.snap)n.visibleWrites=Ca(n.visibleWrites,s.path);else{const a=s.children;Pe(a,l=>{n.visibleWrites=Ca(n.visibleWrites,pe(s.path,l))})}return!0}else return!1}function Bd(n,e){if(n.snap)return Be(n.path,e);for(const t in n.children)if(n.children.hasOwnProperty(t)&&Be(pe(n.path,t),e))return!0;return!1}function $d(n){n.visibleWrites=Ta(n.allWrites,Vd,Q()),n.allWrites.length>0?n.lastWriteId=n.allWrites[n.allWrites.length-1].writeId:n.lastWriteId=-1}function Vd(n){return n.visible}function Ta(n,e,t){let s=tt.empty();for(let i=0;i<n.length;++i){const r=n[i];if(e(r)){const o=r.path;let a;if(r.snap)Be(t,o)?(a=ke(t,o),s=Kn(s,a,r.snap)):Be(o,t)&&(a=ke(o,t),s=Kn(s,Q(),r.snap.getChild(a)));else if(r.children){if(Be(t,o))a=ke(t,o),s=Ki(s,a,r.children);else if(Be(o,t))if(a=ke(o,t),B(a))s=Ki(s,Q(),r.children);else{const l=Mt(r.children,W(a));if(l){const c=l.getChild(oe(a));s=Kn(s,Q(),c)}}}else throw Xt("WriteRecord should have .snap or .children")}}return s}function Aa(n,e,t,s,i){if(!s&&!i){const r=jt(n.visibleWrites,e);if(r!=null)return r;{const o=At(n.visibleWrites,e);if(Yi(o))return t;if(t==null&&!qi(o,Q()))return null;{const a=t||L.EMPTY_NODE;return un(o,a)}}}else{const r=At(n.visibleWrites,e);if(!i&&Yi(r))return t;if(!i&&t==null&&!qi(r,Q()))return null;{const o=function(c){return(c.visible||i)&&(!s||!~s.indexOf(c.writeId))&&(Be(c.path,e)||Be(e,c.path))},a=Ta(n.allWrites,o,e),l=t||L.EMPTY_NODE;return un(a,l)}}}function jd(n,e,t){let s=L.EMPTY_NODE;const i=jt(n.visibleWrites,e);if(i)return i.isLeafNode()||i.forEachChild(he,(r,o)=>{s=s.updateImmediateChild(r,o)}),s;if(t){const r=At(n.visibleWrites,e);return t.forEachChild(he,(o,a)=>{const l=un(At(r,new se(o)),a);s=s.updateImmediateChild(o,l)}),Ia(r).forEach(o=>{s=s.updateImmediateChild(o.name,o.node)}),s}else{const r=At(n.visibleWrites,e);return Ia(r).forEach(o=>{s=s.updateImmediateChild(o.name,o.node)}),s}}function zd(n,e,t,s,i){w(s||i,"Either existingEventSnap or existingServerSnap must exist");const r=pe(e,t);if(qi(n.visibleWrites,r))return null;{const o=At(n.visibleWrites,r);return Yi(o)?i.getChild(t):un(o,i.getChild(t))}}function Kd(n,e,t,s){const i=pe(e,t),r=jt(n.visibleWrites,i);if(r!=null)return r;if(s.isCompleteForChild(t)){const o=At(n.visibleWrites,i);return un(o,s.getNode().getImmediateChild(t))}else return null}function qd(n,e){return jt(n.visibleWrites,e)}function Yd(n,e,t,s,i,r,o){let a;const l=At(n.visibleWrites,e),c=jt(l,Q());if(c!=null)a=c;else if(t!=null)a=un(l,t);else return[];if(a=a.withIndex(o),!a.isEmpty()&&!a.isLeafNode()){const f=[],d=o.getCompare(),h=r?a.getReverseIteratorFrom(s,o):a.getIteratorFrom(s,o);let y=h.getNext();for(;y&&f.length<i;)d(y,s)!==0&&f.push(y),y=h.getNext();return f}else return[]}function Qd(){return{visibleWrites:tt.empty(),allWrites:[],lastWriteId:-1}}function ks(n,e,t,s){return Aa(n.writeTree,n.treePath,e,t,s)}function Qi(n,e){return jd(n.writeTree,n.treePath,e)}function Ra(n,e,t,s){return zd(n.writeTree,n.treePath,e,t,s)}function Os(n,e){return qd(n.writeTree,pe(n.treePath,e))}function Jd(n,e,t,s,i,r){return Yd(n.writeTree,n.treePath,e,t,s,i,r)}function Ji(n,e,t){return Kd(n.writeTree,n.treePath,e,t)}function Pa(n,e){return Na(pe(n.treePath,e),n.writeTree)}function Na(n,e){return{treePath:n,writeTree:e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xd{constructor(){this.changeMap=new Map}trackChildChange(e){const t=e.type,s=e.childName;w(t==="child_added"||t==="child_changed"||t==="child_removed","Only child changes supported for tracking"),w(s!==".priority","Only non-priority child changes can be tracked.");const i=this.changeMap.get(s);if(i){const r=i.type;if(t==="child_added"&&r==="child_removed")this.changeMap.set(s,Bn(s,e.snapshotNode,i.snapshotNode));else if(t==="child_removed"&&r==="child_added")this.changeMap.delete(s);else if(t==="child_removed"&&r==="child_changed")this.changeMap.set(s,Hn(s,i.oldSnap));else if(t==="child_changed"&&r==="child_added")this.changeMap.set(s,ln(s,e.snapshotNode));else if(t==="child_changed"&&r==="child_changed")this.changeMap.set(s,Bn(s,e.snapshotNode,i.oldSnap));else throw Xt("Illegal combination of changes: "+e+" occurred after "+i)}else this.changeMap.set(s,e)}getChanges(){return Array.from(this.changeMap.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zd{getCompleteChild(e){return null}getChildAfterChild(e,t,s){return null}}const ka=new Zd;class Xi{constructor(e,t,s=null){this.writes_=e,this.viewCache_=t,this.optCompleteServerCache_=s}getCompleteChild(e){const t=this.viewCache_.eventCache;if(t.isCompleteForChild(e))return t.getNode().getImmediateChild(e);{const s=this.optCompleteServerCache_!=null?new Tt(this.optCompleteServerCache_,!0,!1):this.viewCache_.serverCache;return Ji(this.writes_,e,s)}}getChildAfterChild(e,t,s){const i=this.optCompleteServerCache_!=null?this.optCompleteServerCache_:Vt(this.viewCache_),r=Jd(this.writes_,i,t,1,s,e);return r.length===0?null:r[0]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ef(n){return{filter:n}}function tf(n,e){w(e.eventCache.getNode().isIndexed(n.filter.getIndex()),"Event snap not indexed"),w(e.serverCache.getNode().isIndexed(n.filter.getIndex()),"Server snap not indexed")}function nf(n,e,t,s,i){const r=new Xd;let o,a;if(t.type===et.OVERWRITE){const c=t;c.source.fromUser?o=Zi(n,e,c.path,c.snap,s,i,r):(w(c.source.fromServer,"Unknown source."),a=c.source.tagged||e.serverCache.isFiltered()&&!B(c.path),o=Ls(n,e,c.path,c.snap,s,i,a,r))}else if(t.type===et.MERGE){const c=t;c.source.fromUser?o=rf(n,e,c.path,c.children,s,i,r):(w(c.source.fromServer,"Unknown source."),a=c.source.tagged||e.serverCache.isFiltered(),o=er(n,e,c.path,c.children,s,i,a,r))}else if(t.type===et.ACK_USER_WRITE){const c=t;c.revert?o=lf(n,e,c.path,s,i,r):o=of(n,e,c.path,c.affectedTree,s,i,r)}else if(t.type===et.LISTEN_COMPLETE)o=af(n,e,t.path,s,r);else throw Xt("Unknown operation type: "+t.type);const l=r.getChanges();return sf(e,o,l),{viewCache:o,changes:l}}function sf(n,e,t){const s=e.eventCache;if(s.isFullyInitialized()){const i=s.getNode().isLeafNode()||s.getNode().isEmpty(),r=Ps(n);(t.length>0||!n.eventCache.isFullyInitialized()||i&&!s.getNode().equals(r)||!s.getNode().getPriority().equals(r.getPriority()))&&t.push(_a(Ps(e)))}}function Oa(n,e,t,s,i,r){const o=e.eventCache;if(Os(s,t)!=null)return e;{let a,l;if(B(t))if(w(e.serverCache.isFullyInitialized(),"If change path is empty, we must have complete server data"),e.serverCache.isFiltered()){const c=Vt(e),f=c instanceof L?c:L.EMPTY_NODE,d=Qi(s,f);a=n.filter.updateFullNode(e.eventCache.getNode(),d,r)}else{const c=ks(s,Vt(e));a=n.filter.updateFullNode(e.eventCache.getNode(),c,r)}else{const c=W(t);if(c===".priority"){w(bt(t)===1,"Can't have a priority with additional path components");const f=o.getNode();l=e.serverCache.getNode();const d=Ra(s,t,f,l);d!=null?a=n.filter.updatePriority(f,d):a=o.getNode()}else{const f=oe(t);let d;if(o.isCompleteForChild(c)){l=e.serverCache.getNode();const h=Ra(s,t,o.getNode(),l);h!=null?d=o.getNode().getImmediateChild(c).updateChild(f,h):d=o.getNode().getImmediateChild(c)}else d=Ji(s,c,e.serverCache);d!=null?a=n.filter.updateChild(o.getNode(),c,d,f,i,r):a=o.getNode()}}return zn(e,a,o.isFullyInitialized()||B(t),n.filter.filtersNodes())}}function Ls(n,e,t,s,i,r,o,a){const l=e.serverCache;let c;const f=o?n.filter:n.filter.getIndexedFilter();if(B(t))c=f.updateFullNode(l.getNode(),s,null);else if(f.filtersNodes()&&!l.isFiltered()){const y=l.getNode().updateChild(t,s);c=f.updateFullNode(l.getNode(),y,null)}else{const y=W(t);if(!l.isCompleteForPath(t)&&bt(t)>1)return e;const E=oe(t),j=l.getNode().getImmediateChild(y).updateChild(E,s);y===".priority"?c=f.updatePriority(l.getNode(),j):c=f.updateChild(l.getNode(),y,j,E,ka,null)}const d=Sa(e,c,l.isFullyInitialized()||B(t),f.filtersNodes()),h=new Xi(i,d,r);return Oa(n,d,t,i,h,a)}function Zi(n,e,t,s,i,r,o){const a=e.eventCache;let l,c;const f=new Xi(i,e,r);if(B(t))c=n.filter.updateFullNode(e.eventCache.getNode(),s,o),l=zn(e,c,!0,n.filter.filtersNodes());else{const d=W(t);if(d===".priority")c=n.filter.updatePriority(e.eventCache.getNode(),s),l=zn(e,c,a.isFullyInitialized(),a.isFiltered());else{const h=oe(t),y=a.getNode().getImmediateChild(d);let E;if(B(h))E=s;else{const x=f.getCompleteChild(d);x!=null?Di(h)===".priority"&&x.getChild(aa(h)).isEmpty()?E=x:E=x.updateChild(h,s):E=L.EMPTY_NODE}if(y.equals(E))l=e;else{const x=n.filter.updateChild(a.getNode(),d,E,h,f,o);l=zn(e,x,a.isFullyInitialized(),n.filter.filtersNodes())}}}return l}function La(n,e){return n.eventCache.isCompleteForChild(e)}function rf(n,e,t,s,i,r,o){let a=e;return s.foreach((l,c)=>{const f=pe(t,l);La(e,W(f))&&(a=Zi(n,a,f,c,i,r,o))}),s.foreach((l,c)=>{const f=pe(t,l);La(e,W(f))||(a=Zi(n,a,f,c,i,r,o))}),a}function Da(n,e,t){return t.foreach((s,i)=>{e=e.updateChild(s,i)}),e}function er(n,e,t,s,i,r,o,a){if(e.serverCache.getNode().isEmpty()&&!e.serverCache.isFullyInitialized())return e;let l=e,c;B(t)?c=s:c=new ae(null).setTree(t,s);const f=e.serverCache.getNode();return c.children.inorderTraversal((d,h)=>{if(f.hasChild(d)){const y=e.serverCache.getNode().getImmediateChild(d),E=Da(n,y,h);l=Ls(n,l,new se(d),E,i,r,o,a)}}),c.children.inorderTraversal((d,h)=>{const y=!e.serverCache.isCompleteForChild(d)&&h.value===null;if(!f.hasChild(d)&&!y){const E=e.serverCache.getNode().getImmediateChild(d),x=Da(n,E,h);l=Ls(n,l,new se(d),x,i,r,o,a)}}),l}function of(n,e,t,s,i,r,o){if(Os(i,t)!=null)return e;const a=e.serverCache.isFiltered(),l=e.serverCache;if(s.value!=null){if(B(t)&&l.isFullyInitialized()||l.isCompleteForPath(t))return Ls(n,e,t,l.getNode().getChild(t),i,r,a,o);if(B(t)){let c=new ae(null);return l.getNode().forEachChild(on,(f,d)=>{c=c.set(new se(f),d)}),er(n,e,t,c,i,r,a,o)}else return e}else{let c=new ae(null);return s.foreach((f,d)=>{const h=pe(t,f);l.isCompleteForPath(h)&&(c=c.set(f,l.getNode().getChild(h)))}),er(n,e,t,c,i,r,a,o)}}function af(n,e,t,s,i){const r=e.serverCache,o=Sa(e,r.getNode(),r.isFullyInitialized()||B(t),r.isFiltered());return Oa(n,o,t,s,ka,i)}function lf(n,e,t,s,i,r){let o;if(Os(s,t)!=null)return e;{const a=new Xi(s,e,i),l=e.eventCache.getNode();let c;if(B(t)||W(t)===".priority"){let f;if(e.serverCache.isFullyInitialized())f=ks(s,Vt(e));else{const d=e.serverCache.getNode();w(d instanceof L,"serverChildren would be complete if leaf node"),f=Qi(s,d)}f=f,c=n.filter.updateFullNode(l,f,r)}else{const f=W(t);let d=Ji(s,f,e.serverCache);d==null&&e.serverCache.isCompleteForChild(f)&&(d=l.getImmediateChild(f)),d!=null?c=n.filter.updateChild(l,f,d,oe(t),a,r):e.eventCache.getNode().hasChild(f)?c=n.filter.updateChild(l,f,L.EMPTY_NODE,oe(t),a,r):c=l,c.isEmpty()&&e.serverCache.isFullyInitialized()&&(o=ks(s,Vt(e)),o.isLeafNode()&&(c=n.filter.updateFullNode(c,o,r)))}return o=e.serverCache.isFullyInitialized()||Os(s,Q())!=null,zn(e,c,o,n.filter.filtersNodes())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cf{constructor(e,t){this.query_=e,this.eventRegistrations_=[];const s=this.query_._queryParams,i=new Gi(s.getIndex()),r=Td(s);this.processor_=ef(r);const o=t.serverCache,a=t.eventCache,l=i.updateFullNode(L.EMPTY_NODE,o.getNode(),null),c=r.updateFullNode(L.EMPTY_NODE,a.getNode(),null),f=new Tt(l,o.isFullyInitialized(),i.filtersNodes()),d=new Tt(c,a.isFullyInitialized(),r.filtersNodes());this.viewCache_=Rs(d,f),this.eventGenerator_=new Ld(this.query_)}get query(){return this.query_}}function uf(n){return n.viewCache_.serverCache.getNode()}function hf(n){return Ps(n.viewCache_)}function df(n,e){const t=Vt(n.viewCache_);return t&&(n.query._queryParams.loadsAllData()||!B(e)&&!t.getImmediateChild(W(e)).isEmpty())?t.getChild(e):null}function xa(n){return n.eventRegistrations_.length===0}function ff(n,e){n.eventRegistrations_.push(e)}function Ma(n,e,t){const s=[];if(t){w(e==null,"A cancel should cancel all event registrations.");const i=n.query._path;n.eventRegistrations_.forEach(r=>{const o=r.createCancelEvent(t,i);o&&s.push(o)})}if(e){let i=[];for(let r=0;r<n.eventRegistrations_.length;++r){const o=n.eventRegistrations_[r];if(!o.matches(e))i.push(o);else if(e.hasAnyCallback()){i=i.concat(n.eventRegistrations_.slice(r+1));break}}n.eventRegistrations_=i}else n.eventRegistrations_=[];return s}function Fa(n,e,t,s){e.type===et.MERGE&&e.source.queryId!==null&&(w(Vt(n.viewCache_),"We should always have a full cache before handling merges"),w(Ps(n.viewCache_),"Missing event cache, even though we have a server cache"));const i=n.viewCache_,r=nf(n.processor_,i,e,t,s);return tf(n.processor_,r.viewCache),w(r.viewCache.serverCache.isFullyInitialized()||!i.serverCache.isFullyInitialized(),"Once a server snap is complete, it should never go back"),n.viewCache_=r.viewCache,Ua(n,r.changes,r.viewCache.eventCache.getNode(),null)}function pf(n,e){const t=n.viewCache_.eventCache,s=[];return t.getNode().isLeafNode()||t.getNode().forEachChild(he,(r,o)=>{s.push(ln(r,o))}),t.isFullyInitialized()&&s.push(_a(t.getNode())),Ua(n,s,t.getNode(),e)}function Ua(n,e,t,s){const i=s?[s]:n.eventRegistrations_;return Dd(n.eventGenerator_,e,t,i)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ds;class Wa{constructor(){this.views=new Map}}function mf(n){w(!Ds,"__referenceConstructor has already been defined"),Ds=n}function gf(){return w(Ds,"Reference.ts has not been loaded"),Ds}function _f(n){return n.views.size===0}function tr(n,e,t,s){const i=e.source.queryId;if(i!==null){const r=n.views.get(i);return w(r!=null,"SyncTree gave us an op for an invalid query."),Fa(r,e,t,s)}else{let r=[];for(const o of n.views.values())r=r.concat(Fa(o,e,t,s));return r}}function Ga(n,e,t,s,i){const r=e._queryIdentifier,o=n.views.get(r);if(!o){let a=ks(t,i?s:null),l=!1;a?l=!0:s instanceof L?(a=Qi(t,s),l=!1):(a=L.EMPTY_NODE,l=!1);const c=Rs(new Tt(a,l,!1),new Tt(s,i,!1));return new cf(e,c)}return o}function yf(n,e,t,s,i,r){const o=Ga(n,e,s,i,r);return n.views.has(e._queryIdentifier)||n.views.set(e._queryIdentifier,o),ff(o,t),pf(o,t)}function vf(n,e,t,s){const i=e._queryIdentifier,r=[];let o=[];const a=Pt(n);if(i==="default")for(const[l,c]of n.views.entries())o=o.concat(Ma(c,t,s)),xa(c)&&(n.views.delete(l),c.query._queryParams.loadsAllData()||r.push(c.query));else{const l=n.views.get(i);l&&(o=o.concat(Ma(l,t,s)),xa(l)&&(n.views.delete(i),l.query._queryParams.loadsAllData()||r.push(l.query)))}return a&&!Pt(n)&&r.push(new(gf())(e._repo,e._path)),{removed:r,events:o}}function Ha(n){const e=[];for(const t of n.views.values())t.query._queryParams.loadsAllData()||e.push(t);return e}function Rt(n,e){let t=null;for(const s of n.views.values())t=t||df(s,e);return t}function Ba(n,e){if(e._queryParams.loadsAllData())return xs(n);{const s=e._queryIdentifier;return n.views.get(s)}}function $a(n,e){return Ba(n,e)!=null}function Pt(n){return xs(n)!=null}function xs(n){for(const e of n.views.values())if(e.query._queryParams.loadsAllData())return e;return null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ms;function Ef(n){w(!Ms,"__referenceConstructor has already been defined"),Ms=n}function wf(){return w(Ms,"Reference.ts has not been loaded"),Ms}let Sf=1;class Va{constructor(e){this.listenProvider_=e,this.syncPointTree_=new ae(null),this.pendingWriteTree_=Qd(),this.tagToQueryMap=new Map,this.queryToTagMap=new Map}}function nr(n,e,t,s,i){return Ud(n.pendingWriteTree_,e,t,s,i),i?hn(n,new $t($i(),e,t)):[]}function Cf(n,e,t,s){Wd(n.pendingWriteTree_,e,t,s);const i=ae.fromObject(t);return hn(n,new cn($i(),e,i))}function Nt(n,e,t=!1){const s=Gd(n.pendingWriteTree_,e);if(Hd(n.pendingWriteTree_,e)){let r=new ae(null);return s.snap!=null?r=r.set(Q(),!0):Pe(s.children,o=>{r=r.set(new se(o),!0)}),hn(n,new As(s.path,r,t))}else return[]}function qn(n,e,t){return hn(n,new $t(Vi(),e,t))}function If(n,e,t){const s=ae.fromObject(t);return hn(n,new cn(Vi(),e,s))}function bf(n,e){return hn(n,new Vn(Vi(),e))}function Tf(n,e,t){const s=ir(n,t);if(s){const i=rr(s),r=i.path,o=i.queryId,a=ke(r,e),l=new Vn(ji(o),a);return or(n,r,l)}else return[]}function Fs(n,e,t,s,i=!1){const r=e._path,o=n.syncPointTree_.get(r);let a=[];if(o&&(e._queryIdentifier==="default"||$a(o,e))){const l=vf(o,e,t,s);_f(o)&&(n.syncPointTree_=n.syncPointTree_.remove(r));const c=l.removed;if(a=l.events,!i){const f=c.findIndex(h=>h._queryParams.loadsAllData())!==-1,d=n.syncPointTree_.findOnPath(r,(h,y)=>Pt(y));if(f&&!d){const h=n.syncPointTree_.subtree(r);if(!h.isEmpty()){const y=Pf(h);for(let E=0;E<y.length;++E){const x=y[E],j=x.query,Y=qa(n,x);n.listenProvider_.startListening(Qn(j),Yn(n,j),Y.hashFn,Y.onComplete)}}}!d&&c.length>0&&!s&&(f?n.listenProvider_.stopListening(Qn(e),null):c.forEach(h=>{const y=n.queryToTagMap.get(Ws(h));n.listenProvider_.stopListening(Qn(h),y)}))}Nf(n,c)}return a}function ja(n,e,t,s){const i=ir(n,s);if(i!=null){const r=rr(i),o=r.path,a=r.queryId,l=ke(o,e),c=new $t(ji(a),l,t);return or(n,o,c)}else return[]}function Af(n,e,t,s){const i=ir(n,s);if(i){const r=rr(i),o=r.path,a=r.queryId,l=ke(o,e),c=ae.fromObject(t),f=new cn(ji(a),l,c);return or(n,o,f)}else return[]}function sr(n,e,t,s=!1){const i=e._path;let r=null,o=!1;n.syncPointTree_.foreachOnPath(i,(h,y)=>{const E=ke(h,i);r=r||Rt(y,E),o=o||Pt(y)});let a=n.syncPointTree_.get(i);a?(o=o||Pt(a),r=r||Rt(a,Q())):(a=new Wa,n.syncPointTree_=n.syncPointTree_.set(i,a));let l;r!=null?l=!0:(l=!1,r=L.EMPTY_NODE,n.syncPointTree_.subtree(i).foreachChild((y,E)=>{const x=Rt(E,Q());x&&(r=r.updateImmediateChild(y,x))}));const c=$a(a,e);if(!c&&!e._queryParams.loadsAllData()){const h=Ws(e);w(!n.queryToTagMap.has(h),"View does not exist, but we have a tag");const y=kf();n.queryToTagMap.set(h,y),n.tagToQueryMap.set(y,h)}const f=Ns(n.pendingWriteTree_,i);let d=yf(a,e,t,f,r,l);if(!c&&!o&&!s){const h=Ba(a,e);d=d.concat(Of(n,e,h))}return d}function Us(n,e,t){const i=n.pendingWriteTree_,r=n.syncPointTree_.findOnPath(e,(o,a)=>{const l=ke(o,e),c=Rt(a,l);if(c)return c});return Aa(i,e,r,t,!0)}function Rf(n,e){const t=e._path;let s=null;n.syncPointTree_.foreachOnPath(t,(c,f)=>{const d=ke(c,t);s=s||Rt(f,d)});let i=n.syncPointTree_.get(t);i?s=s||Rt(i,Q()):(i=new Wa,n.syncPointTree_=n.syncPointTree_.set(t,i));const r=s!=null,o=r?new Tt(s,!0,!1):null,a=Ns(n.pendingWriteTree_,e._path),l=Ga(i,e,a,r?o.getNode():L.EMPTY_NODE,r);return hf(l)}function hn(n,e){return za(e,n.syncPointTree_,null,Ns(n.pendingWriteTree_,Q()))}function za(n,e,t,s){if(B(n.path))return Ka(n,e,t,s);{const i=e.get(Q());t==null&&i!=null&&(t=Rt(i,Q()));let r=[];const o=W(n.path),a=n.operationForChild(o),l=e.children.get(o);if(l&&a){const c=t?t.getImmediateChild(o):null,f=Pa(s,o);r=r.concat(za(a,l,c,f))}return i&&(r=r.concat(tr(i,n,s,t))),r}}function Ka(n,e,t,s){const i=e.get(Q());t==null&&i!=null&&(t=Rt(i,Q()));let r=[];return e.children.inorderTraversal((o,a)=>{const l=t?t.getImmediateChild(o):null,c=Pa(s,o),f=n.operationForChild(o);f&&(r=r.concat(Ka(f,a,l,c)))}),i&&(r=r.concat(tr(i,n,s,t))),r}function qa(n,e){const t=e.query,s=Yn(n,t);return{hashFn:()=>(uf(e)||L.EMPTY_NODE).hash(),onComplete:i=>{if(i==="ok")return s?Tf(n,t._path,s):bf(n,t._path);{const r=Ih(i,t);return Fs(n,t,null,r)}}}}function Yn(n,e){const t=Ws(e);return n.queryToTagMap.get(t)}function Ws(n){return n._path.toString()+"$"+n._queryIdentifier}function ir(n,e){return n.tagToQueryMap.get(e)}function rr(n){const e=n.indexOf("$");return w(e!==-1&&e<n.length-1,"Bad queryKey."),{queryId:n.substr(e+1),path:new se(n.substr(0,e))}}function or(n,e,t){const s=n.syncPointTree_.get(e);w(s,"Missing sync point for query tag that we're tracking");const i=Ns(n.pendingWriteTree_,e);return tr(s,t,i,null)}function Pf(n){return n.fold((e,t,s)=>{if(t&&Pt(t))return[xs(t)];{let i=[];return t&&(i=Ha(t)),Pe(s,(r,o)=>{i=i.concat(o)}),i}})}function Qn(n){return n._queryParams.loadsAllData()&&!n._queryParams.isDefault()?new(wf())(n._repo,n._path):n}function Nf(n,e){for(let t=0;t<e.length;++t){const s=e[t];if(!s._queryParams.loadsAllData()){const i=Ws(s),r=n.queryToTagMap.get(i);n.queryToTagMap.delete(i),n.tagToQueryMap.delete(r)}}}function kf(){return Sf++}function Of(n,e,t){const s=e._path,i=Yn(n,e),r=qa(n,t),o=n.listenProvider_.startListening(Qn(e),i,r.hashFn,r.onComplete),a=n.syncPointTree_.subtree(s);if(i)w(!Pt(a.value),"If we're adding a query, it shouldn't be shadowed");else{const l=a.fold((c,f,d)=>{if(!B(c)&&f&&Pt(f))return[xs(f).query];{let h=[];return f&&(h=h.concat(Ha(f).map(y=>y.query))),Pe(d,(y,E)=>{h=h.concat(E)}),h}});for(let c=0;c<l.length;++c){const f=l[c];n.listenProvider_.stopListening(Qn(f),Yn(n,f))}}return o}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ar{constructor(e){this.node_=e}getImmediateChild(e){const t=this.node_.getImmediateChild(e);return new ar(t)}node(){return this.node_}}class lr{constructor(e,t){this.syncTree_=e,this.path_=t}getImmediateChild(e){const t=pe(this.path_,e);return new lr(this.syncTree_,t)}node(){return Us(this.syncTree_,this.path_)}}const Lf=function(n){return n=n||{},n.timestamp=n.timestamp||new Date().getTime(),n},Ya=function(n,e,t){if(!n||typeof n!="object")return n;if(w(".sv"in n,"Unexpected leaf node or priority contents"),typeof n[".sv"]=="string")return Df(n[".sv"],e,t);if(typeof n[".sv"]=="object")return xf(n[".sv"],e);w(!1,"Unexpected server value: "+JSON.stringify(n,null,2))},Df=function(n,e,t){switch(n){case"timestamp":return t.timestamp;default:w(!1,"Unexpected server value: "+n)}},xf=function(n,e,t){n.hasOwnProperty("increment")||w(!1,"Unexpected server value: "+JSON.stringify(n,null,2));const s=n.increment;typeof s!="number"&&w(!1,"Unexpected increment value: "+s);const i=e.node();if(w(i!==null&&typeof i<"u","Expected ChildrenNode.EMPTY_NODE for nulls"),!i.isLeafNode())return s;const o=i.getValue();return typeof o!="number"?s:o+s},Qa=function(n,e,t,s){return ur(e,new lr(t,n),s)},cr=function(n,e,t){return ur(n,new ar(e),t)};function ur(n,e,t){const s=n.getPriority().val(),i=Ya(s,e.getImmediateChild(".priority"),t);let r;if(n.isLeafNode()){const o=n,a=Ya(o.getValue(),e,t);return a!==o.getValue()||i!==o.getPriority().val()?new Ce(a,ye(i)):n}else{const o=n;return r=o,i!==o.getPriority().val()&&(r=r.updatePriority(new Ce(i))),o.forEachChild(he,(a,l)=>{const c=ur(l,e.getImmediateChild(a),t);c!==l&&(r=r.updateImmediateChild(a,c))}),r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hr{constructor(e="",t=null,s={children:{},childCount:0}){this.name=e,this.parent=t,this.node=s}}function Gs(n,e){let t=e instanceof se?e:new se(e),s=n,i=W(t);for(;i!==null;){const r=Mt(s.node.children,i)||{children:{},childCount:0};s=new hr(i,s,r),t=oe(t),i=W(t)}return s}function zt(n){return n.node.value}function dr(n,e){n.node.value=e,fr(n)}function Ja(n){return n.node.childCount>0}function Mf(n){return zt(n)===void 0&&!Ja(n)}function Hs(n,e){Pe(n.node.children,(t,s)=>{e(new hr(t,n,s))})}function Xa(n,e,t,s){t&&e(n),Hs(n,i=>{Xa(i,e,!0)})}function Ff(n,e,t){let s=n.parent;for(;s!==null;){if(e(s))return!0;s=s.parent}return!1}function Jn(n){return new se(n.parent===null?n.name:Jn(n.parent)+"/"+n.name)}function fr(n){n.parent!==null&&Uf(n.parent,n.name,n)}function Uf(n,e,t){const s=Mf(t),i=Xe(n.node.children,e);s&&i?(delete n.node.children[e],n.node.childCount--,fr(n)):!s&&!i&&(n.node.children[e]=t.node,n.node.childCount++,fr(n))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Wf=/[\[\].#$\/\u0000-\u001F\u007F]/,Gf=/[\[\].#$\u0000-\u001F\u007F]/,pr=10*1024*1024,mr=function(n){return typeof n=="string"&&n.length!==0&&!Wf.test(n)},Za=function(n){return typeof n=="string"&&n.length!==0&&!Gf.test(n)},Hf=function(n){return n&&(n=n.replace(/^\/*\.info(\/|$)/,"/")),Za(n)},el=function(n){return n===null||typeof n=="string"||typeof n=="number"&&!bi(n)||n&&typeof n=="object"&&Xe(n,".sv")},Bf=function(n,e,t,s){Xn(ms(n,"value"),e,t)},Xn=function(n,e,t){const s=t instanceof se?new id(t,n):t;if(e===void 0)throw new Error(n+"contains undefined "+Bt(s));if(typeof e=="function")throw new Error(n+"contains a function "+Bt(s)+" with contents = "+e.toString());if(bi(e))throw new Error(n+"contains "+e.toString()+" "+Bt(s));if(typeof e=="string"&&e.length>pr/3&&gs(e)>pr)throw new Error(n+"contains a string greater than "+pr+" utf8 bytes "+Bt(s)+" ('"+e.substring(0,50)+"...')");if(e&&typeof e=="object"){let i=!1,r=!1;if(Pe(e,(o,a)=>{if(o===".value")i=!0;else if(o!==".priority"&&o!==".sv"&&(r=!0,!mr(o)))throw new Error(n+" contains an invalid key ("+o+") "+Bt(s)+`.  Keys must be non-empty strings and can't contain ".", "#", "$", "/", "[", or "]"`);rd(s,o),Xn(n,a,s),od(s)}),i&&r)throw new Error(n+' contains ".value" child '+Bt(s)+" in addition to actual children.")}},$f=function(n,e){let t,s;for(t=0;t<e.length;t++){s=e[t];const r=Fn(s);for(let o=0;o<r.length;o++)if(!(r[o]===".priority"&&o===r.length-1)){if(!mr(r[o]))throw new Error(n+"contains an invalid key ("+r[o]+") in path "+s.toString()+`. Keys must be non-empty strings and can't contain ".", "#", "$", "/", "[", or "]"`)}}e.sort(sd);let i=null;for(t=0;t<e.length;t++){if(s=e[t],i!==null&&Be(i,s))throw new Error(n+"contains a path "+i.toString()+" that is ancestor of another path "+s.toString());i=s}},Vf=function(n,e,t,s){const i=ms(n,"values");if(!(e&&typeof e=="object")||Array.isArray(e))throw new Error(i+" must be an object containing the children to replace.");const r=[];Pe(e,(o,a)=>{const l=new se(o);if(Xn(i,a,pe(t,l)),Di(l)===".priority"&&!el(a))throw new Error(i+"contains an invalid value for '"+l.toString()+"', which must be a valid Firebase priority (a string, finite number, server value, or null).");r.push(l)}),$f(i,r)},tl=function(n,e,t,s){if(!Za(t))throw new Error(ms(n,e)+'was an invalid path = "'+t+`". Paths must be non-empty strings and can't contain ".", "#", "$", "[", or "]"`)},jf=function(n,e,t,s){t&&(t=t.replace(/^\/*\.info(\/|$)/,"/")),tl(n,e,t)},nl=function(n,e){if(W(e)===".info")throw new Error(n+" failed = Can't modify data under /.info/")},zf=function(n,e){const t=e.path.toString();if(typeof e.repoInfo.host!="string"||e.repoInfo.host.length===0||!mr(e.repoInfo.namespace)&&e.repoInfo.host.split(":")[0]!=="localhost"||t.length!==0&&!Hf(t))throw new Error(ms(n,"url")+`must be a valid firebase URL and the path can't contain ".", "#", "$", "[", or "]".`)};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kf{constructor(){this.eventLists_=[],this.recursionDepth_=0}}function Bs(n,e){let t=null;for(let s=0;s<e.length;s++){const i=e[s],r=i.getPath();t!==null&&!xi(r,t.path)&&(n.eventLists_.push(t),t=null),t===null&&(t={events:[],path:r}),t.events.push(i)}t&&n.eventLists_.push(t)}function sl(n,e,t){Bs(n,t),il(n,s=>xi(s,e))}function Ue(n,e,t){Bs(n,t),il(n,s=>Be(s,e)||Be(e,s))}function il(n,e){n.recursionDepth_++;let t=!0;for(let s=0;s<n.eventLists_.length;s++){const i=n.eventLists_[s];if(i){const r=i.path;e(r)?(qf(n.eventLists_[s]),n.eventLists_[s]=null):t=!1}}t&&(n.eventLists_=[]),n.recursionDepth_--}function qf(n){for(let e=0;e<n.events.length;e++){const t=n.events[e];if(t!==null){n.events[e]=null;const s=t.getEventRunner();On&&Re("event: "+t.toString()),sn(s)}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rl="repo_interrupt",Yf=25;class Qf{constructor(e,t,s,i){this.repoInfo_=e,this.forceRestClient_=t,this.authTokenProvider_=s,this.appCheckProvider_=i,this.dataUpdateCount=0,this.statsListener_=null,this.eventQueue_=new Kf,this.nextWriteId_=1,this.interceptServerDataCallback_=null,this.onDisconnect_=Ts(),this.transactionQueueTree_=new hr,this.persistentConnection_=null,this.key=this.repoInfo_.toURLString()}toString(){return(this.repoInfo_.secure?"https://":"http://")+this.repoInfo_.host}}function Jf(n,e,t){if(n.stats_=ki(n.repoInfo_),n.forceRestClient_||Rh())n.server_=new bs(n.repoInfo_,(s,i,r,o)=>{ol(n,s,i,r,o)},n.authTokenProvider_,n.appCheckProvider_),setTimeout(()=>al(n,!0),0);else{if(typeof t<"u"&&t!==null){if(typeof t!="object")throw new Error("Only objects are supported for option databaseAuthVariableOverride");try{we(t)}catch(s){throw new Error("Invalid authOverride provided: "+s)}}n.persistentConnection_=new mt(n.repoInfo_,e,(s,i,r,o)=>{ol(n,s,i,r,o)},s=>{al(n,s)},s=>{Zf(n,s)},n.authTokenProvider_,n.appCheckProvider_,t),n.server_=n.persistentConnection_}n.authTokenProvider_.addTokenChangeListener(s=>{n.server_.refreshAuthToken(s)}),n.appCheckProvider_.addTokenChangeListener(s=>{n.server_.refreshAppCheckToken(s.token)}),n.statsReporter_=Lh(n.repoInfo_,()=>new Od(n.stats_,n.server_)),n.infoData_=new Ad,n.infoSyncTree_=new Va({startListening:(s,i,r,o)=>{let a=[];const l=n.infoData_.getNode(s._path);return l.isEmpty()||(a=qn(n.infoSyncTree_,s._path,l),setTimeout(()=>{o("ok")},0)),a},stopListening:()=>{}}),gr(n,"connected",!1),n.serverSyncTree_=new Va({startListening:(s,i,r,o)=>(n.server_.listen(s,r,i,(a,l)=>{const c=o(a,l);Ue(n.eventQueue_,s._path,c)}),[]),stopListening:(s,i)=>{n.server_.unlisten(s,i)}})}function Xf(n){const t=n.infoData_.getNode(new se(".info/serverTimeOffset")).val()||0;return new Date().getTime()+t}function Zn(n){return Lf({timestamp:Xf(n)})}function ol(n,e,t,s,i){n.dataUpdateCount++;const r=new se(e);t=n.interceptServerDataCallback_?n.interceptServerDataCallback_(e,t):t;let o=[];if(i)if(s){const l=ps(t,c=>ye(c));o=Af(n.serverSyncTree_,r,l,i)}else{const l=ye(t);o=ja(n.serverSyncTree_,r,l,i)}else if(s){const l=ps(t,c=>ye(c));o=If(n.serverSyncTree_,r,l)}else{const l=ye(t);o=qn(n.serverSyncTree_,r,l)}let a=r;o.length>0&&(a=fn(n,r)),Ue(n.eventQueue_,a,o)}function al(n,e){gr(n,"connected",e),e===!1&&sp(n)}function Zf(n,e){Pe(e,(t,s)=>{gr(n,t,s)})}function gr(n,e,t){const s=new se("/.info/"+e),i=ye(t);n.infoData_.updateSnapshot(s,i);const r=qn(n.infoSyncTree_,s,i);Ue(n.eventQueue_,s,r)}function $s(n){return n.nextWriteId_++}function ep(n,e,t){const s=Rf(n.serverSyncTree_,e);return s!=null?Promise.resolve(s):n.server_.get(e).then(i=>{const r=ye(i).withIndex(e._queryParams.getIndex());sr(n.serverSyncTree_,e,t,!0);let o;if(e._queryParams.loadsAllData())o=qn(n.serverSyncTree_,e._path,r);else{const a=Yn(n.serverSyncTree_,e);o=ja(n.serverSyncTree_,e._path,r,a)}return Ue(n.eventQueue_,e._path,o),Fs(n.serverSyncTree_,e,t,null,!0),r},i=>(dn(n,"get for query "+we(e)+" failed: "+i),Promise.reject(new Error(i))))}function tp(n,e,t,s,i){dn(n,"set",{path:e.toString(),value:t,priority:s});const r=Zn(n),o=ye(t,s),a=Us(n.serverSyncTree_,e),l=cr(o,a,r),c=$s(n),f=nr(n.serverSyncTree_,e,l,c,!0);Bs(n.eventQueue_,f),n.server_.put(e.toString(),o.val(!0),(h,y)=>{const E=h==="ok";E||Ne("set at "+e+" failed: "+h);const x=Nt(n.serverSyncTree_,c,!E);Ue(n.eventQueue_,e,x),_r(n,i,h,y)});const d=vr(n,e);fn(n,d),Ue(n.eventQueue_,d,[])}function np(n,e,t,s){dn(n,"update",{path:e.toString(),value:t});let i=!0;const r=Zn(n),o={};if(Pe(t,(a,l)=>{i=!1,o[a]=Qa(pe(e,a),ye(l),n.serverSyncTree_,r)}),i)Re("update() called with empty data.  Don't do anything."),_r(n,s,"ok",void 0);else{const a=$s(n),l=Cf(n.serverSyncTree_,e,o,a);Bs(n.eventQueue_,l),n.server_.merge(e.toString(),t,(c,f)=>{const d=c==="ok";d||Ne("update at "+e+" failed: "+c);const h=Nt(n.serverSyncTree_,a,!d),y=h.length>0?fn(n,e):e;Ue(n.eventQueue_,y,h),_r(n,s,c,f)}),Pe(t,c=>{const f=vr(n,pe(e,c));fn(n,f)}),Ue(n.eventQueue_,e,[])}}function sp(n){dn(n,"onDisconnectEvents");const e=Zn(n),t=Ts();Bi(n.onDisconnect_,Q(),(i,r)=>{const o=Qa(i,r,n.serverSyncTree_,e);Ea(t,i,o)});let s=[];Bi(t,Q(),(i,r)=>{s=s.concat(qn(n.serverSyncTree_,i,r));const o=vr(n,i);fn(n,o)}),n.onDisconnect_=Ts(),Ue(n.eventQueue_,Q(),s)}function ip(n,e,t){let s;W(e._path)===".info"?s=sr(n.infoSyncTree_,e,t):s=sr(n.serverSyncTree_,e,t),sl(n.eventQueue_,e._path,s)}function ll(n,e,t){let s;W(e._path)===".info"?s=Fs(n.infoSyncTree_,e,t):s=Fs(n.serverSyncTree_,e,t),sl(n.eventQueue_,e._path,s)}function cl(n){n.persistentConnection_&&n.persistentConnection_.interrupt(rl)}function rp(n){n.persistentConnection_&&n.persistentConnection_.resume(rl)}function dn(n,...e){let t="";n.persistentConnection_&&(t=n.persistentConnection_.id+":"),Re(t,...e)}function _r(n,e,t,s){e&&sn(()=>{if(t==="ok")e(null);else{const i=(t||"error").toUpperCase();let r=i;s&&(r+=": "+s);const o=new Error(r);o.code=i,e(o)}})}function op(n,e,t,s,i,r){dn(n,"transaction on "+e);const o={path:e,update:t,onComplete:s,status:null,order:Ro(),applyLocally:r,retryCount:0,unwatcher:i,abortReason:null,currentWriteId:null,currentInputSnapshot:null,currentOutputSnapshotRaw:null,currentOutputSnapshotResolved:null},a=yr(n,e,void 0);o.currentInputSnapshot=a;const l=o.update(a.val());if(l===void 0)o.unwatcher(),o.currentOutputSnapshotRaw=null,o.currentOutputSnapshotResolved=null,o.onComplete&&o.onComplete(null,!1,o.currentInputSnapshot);else{Xn("transaction failed: Data returned ",l,o.path),o.status=0;const c=Gs(n.transactionQueueTree_,e),f=zt(c)||[];f.push(o),dr(c,f);let d;typeof l=="object"&&l!==null&&Xe(l,".priority")?(d=Mt(l,".priority"),w(el(d),"Invalid priority returned by transaction. Priority must be a valid string, finite number, server value, or null.")):d=(Us(n.serverSyncTree_,e)||L.EMPTY_NODE).getPriority().val();const h=Zn(n),y=ye(l,d),E=cr(y,a,h);o.currentOutputSnapshotRaw=y,o.currentOutputSnapshotResolved=E,o.currentWriteId=$s(n);const x=nr(n.serverSyncTree_,e,E,o.currentWriteId,o.applyLocally);Ue(n.eventQueue_,e,x),Vs(n,n.transactionQueueTree_)}}function yr(n,e,t){return Us(n.serverSyncTree_,e,t)||L.EMPTY_NODE}function Vs(n,e=n.transactionQueueTree_){if(e||js(n,e),zt(e)){const t=hl(n,e);w(t.length>0,"Sending zero length transaction queue"),t.every(i=>i.status===0)&&ap(n,Jn(e),t)}else Ja(e)&&Hs(e,t=>{Vs(n,t)})}function ap(n,e,t){const s=t.map(c=>c.currentWriteId),i=yr(n,e,s);let r=i;const o=i.hash();for(let c=0;c<t.length;c++){const f=t[c];w(f.status===0,"tryToSendTransactionQueue_: items in queue should all be run."),f.status=1,f.retryCount++;const d=ke(e,f.path);r=r.updateChild(d,f.currentOutputSnapshotRaw)}const a=r.val(!0),l=e;n.server_.put(l.toString(),a,c=>{dn(n,"transaction put response",{path:l.toString(),status:c});let f=[];if(c==="ok"){const d=[];for(let h=0;h<t.length;h++)t[h].status=2,f=f.concat(Nt(n.serverSyncTree_,t[h].currentWriteId)),t[h].onComplete&&d.push(()=>t[h].onComplete(null,!0,t[h].currentOutputSnapshotResolved)),t[h].unwatcher();js(n,Gs(n.transactionQueueTree_,e)),Vs(n,n.transactionQueueTree_),Ue(n.eventQueue_,e,f);for(let h=0;h<d.length;h++)sn(d[h])}else{if(c==="datastale")for(let d=0;d<t.length;d++)t[d].status===3?t[d].status=4:t[d].status=0;else{Ne("transaction at "+l.toString()+" failed: "+c);for(let d=0;d<t.length;d++)t[d].status=4,t[d].abortReason=c}fn(n,e)}},o)}function fn(n,e){const t=ul(n,e),s=Jn(t),i=hl(n,t);return lp(n,i,s),s}function lp(n,e,t){if(e.length===0)return;const s=[];let i=[];const o=e.filter(a=>a.status===0).map(a=>a.currentWriteId);for(let a=0;a<e.length;a++){const l=e[a],c=ke(t,l.path);let f=!1,d;if(w(c!==null,"rerunTransactionsUnderNode_: relativePath should not be null."),l.status===4)f=!0,d=l.abortReason,i=i.concat(Nt(n.serverSyncTree_,l.currentWriteId,!0));else if(l.status===0)if(l.retryCount>=Yf)f=!0,d="maxretry",i=i.concat(Nt(n.serverSyncTree_,l.currentWriteId,!0));else{const h=yr(n,l.path,o);l.currentInputSnapshot=h;const y=e[a].update(h.val());if(y!==void 0){Xn("transaction failed: Data returned ",y,l.path);let E=ye(y);typeof y=="object"&&y!=null&&Xe(y,".priority")||(E=E.updatePriority(h.getPriority()));const j=l.currentWriteId,Y=Zn(n),de=cr(E,h,Y);l.currentOutputSnapshotRaw=E,l.currentOutputSnapshotResolved=de,l.currentWriteId=$s(n),o.splice(o.indexOf(j),1),i=i.concat(nr(n.serverSyncTree_,l.path,de,l.currentWriteId,l.applyLocally)),i=i.concat(Nt(n.serverSyncTree_,j,!0))}else f=!0,d="nodata",i=i.concat(Nt(n.serverSyncTree_,l.currentWriteId,!0))}Ue(n.eventQueue_,t,i),i=[],f&&(e[a].status=2,(function(h){setTimeout(h,Math.floor(0))})(e[a].unwatcher),e[a].onComplete&&(d==="nodata"?s.push(()=>e[a].onComplete(null,!1,e[a].currentInputSnapshot)):s.push(()=>e[a].onComplete(new Error(d),!1,null))))}js(n,n.transactionQueueTree_);for(let a=0;a<s.length;a++)sn(s[a]);Vs(n,n.transactionQueueTree_)}function ul(n,e){let t,s=n.transactionQueueTree_;for(t=W(e);t!==null&&zt(s)===void 0;)s=Gs(s,t),e=oe(e),t=W(e);return s}function hl(n,e){const t=[];return dl(n,e,t),t.sort((s,i)=>s.order-i.order),t}function dl(n,e,t){const s=zt(e);if(s)for(let i=0;i<s.length;i++)t.push(s[i]);Hs(e,i=>{dl(n,i,t)})}function js(n,e){const t=zt(e);if(t){let s=0;for(let i=0;i<t.length;i++)t[i].status!==2&&(t[s]=t[i],s++);t.length=s,dr(e,t.length>0?t:void 0)}Hs(e,s=>{js(n,s)})}function vr(n,e){const t=Jn(ul(n,e)),s=Gs(n.transactionQueueTree_,e);return Ff(s,i=>{Er(n,i)}),Er(n,s),Xa(s,i=>{Er(n,i)}),t}function Er(n,e){const t=zt(e);if(t){const s=[];let i=[],r=-1;for(let o=0;o<t.length;o++)t[o].status===3||(t[o].status===1?(w(r===o-1,"All SENT items should be at beginning of queue."),r=o,t[o].status=3,t[o].abortReason="set"):(w(t[o].status===0,"Unexpected transaction status in abort"),t[o].unwatcher(),i=i.concat(Nt(n.serverSyncTree_,t[o].currentWriteId,!0)),t[o].onComplete&&s.push(t[o].onComplete.bind(null,new Error("set"),!1,null))));r===-1?dr(e,void 0):t.length=r+1,Ue(n.eventQueue_,Jn(e),i);for(let o=0;o<s.length;o++)sn(s[o])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function cp(n){let e="";const t=n.split("/");for(let s=0;s<t.length;s++)if(t[s].length>0){let i=t[s];try{i=decodeURIComponent(i.replace(/\+/g," "))}catch{}e+="/"+i}return e}function up(n){const e={};n.charAt(0)==="?"&&(n=n.substring(1));for(const t of n.split("&")){if(t.length===0)continue;const s=t.split("=");s.length===2?e[decodeURIComponent(s[0])]=decodeURIComponent(s[1]):Ne(`Invalid query segment '${t}' in query '${n}'`)}return e}const fl=function(n,e){const t=hp(n),s=t.namespace;t.domain==="firebase.com"&&pt(t.host+" is no longer supported. Please use <YOUR FIREBASE>.firebaseio.com instead"),(!s||s==="undefined")&&t.domain!=="localhost"&&pt("Cannot parse Firebase url. Please use https://<YOUR FIREBASE>.firebaseio.com"),t.secure||vh();const i=t.scheme==="ws"||t.scheme==="wss";return{repoInfo:new $o(t.host,t.secure,s,i,e,"",s!==t.subdomain),path:new se(t.pathString)}},hp=function(n){let e="",t="",s="",i="",r="",o=!0,a="https",l=443;if(typeof n=="string"){let c=n.indexOf("//");c>=0&&(a=n.substring(0,c-1),n=n.substring(c+2));let f=n.indexOf("/");f===-1&&(f=n.length);let d=n.indexOf("?");d===-1&&(d=n.length),e=n.substring(0,Math.min(f,d)),f<d&&(i=cp(n.substring(f,d)));const h=up(n.substring(Math.min(n.length,d)));c=e.indexOf(":"),c>=0?(o=a==="https"||a==="wss",l=parseInt(e.substring(c+1),10)):c=e.length;const y=e.slice(0,c);if(y.toLowerCase()==="localhost")t="localhost";else if(y.split(".").length<=2)t=y;else{const E=e.indexOf(".");s=e.substring(0,E).toLowerCase(),t=e.substring(E+1),r=s}"ns"in h&&(r=h.ns)}return{host:e,port:l,domain:t,subdomain:s,secure:o,scheme:a,pathString:i,namespace:r}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dp{constructor(e,t,s,i){this.eventType=e,this.eventRegistration=t,this.snapshot=s,this.prevName=i}getPath(){const e=this.snapshot.ref;return this.eventType==="value"?e._path:e.parent._path}getEventType(){return this.eventType}getEventRunner(){return this.eventRegistration.getEventRunner(this)}toString(){return this.getPath().toString()+":"+this.eventType+":"+we(this.snapshot.exportVal())}}class fp{constructor(e,t,s){this.eventRegistration=e,this.error=t,this.path=s}getPath(){return this.path}getEventType(){return"cancel"}getEventRunner(){return this.eventRegistration.getEventRunner(this)}toString(){return this.path.toString()+":cancel"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pl{constructor(e,t){this.snapshotCallback=e,this.cancelCallback=t}onValue(e,t){this.snapshotCallback.call(null,e,t)}onCancel(e){return w(this.hasCancelCallback,"Raising a cancel event on a listener with no cancel callback"),this.cancelCallback.call(null,e)}get hasCancelCallback(){return!!this.cancelCallback}matches(e){return this.snapshotCallback===e.snapshotCallback||this.snapshotCallback.userCallback!==void 0&&this.snapshotCallback.userCallback===e.snapshotCallback.userCallback&&this.snapshotCallback.context===e.snapshotCallback.context}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wr{constructor(e,t,s,i){this._repo=e,this._path=t,this._queryParams=s,this._orderByCalled=i}get key(){return B(this._path)?null:Di(this._path)}get ref(){return new ut(this._repo,this._path)}get _queryIdentifier(){const e=va(this._queryParams),t=Ti(e);return t==="{}"?"default":t}get _queryObject(){return va(this._queryParams)}isEqual(e){if(e=Fe(e),!(e instanceof wr))return!1;const t=this._repo===e._repo,s=xi(this._path,e._path),i=this._queryIdentifier===e._queryIdentifier;return t&&s&&i}toJSON(){return this.toString()}toString(){return this._repo.toString()+nd(this._path)}}class ut extends wr{constructor(e,t){super(e,t,new Hi,!1)}get parent(){const e=aa(this._path);return e===null?null:new ut(this._repo,e)}get root(){let e=this;for(;e.parent!==null;)e=e.parent;return e}}class pn{constructor(e,t,s){this._node=e,this.ref=t,this._index=s}get priority(){return this._node.getPriority().val()}get key(){return this.ref.key}get size(){return this._node.numChildren()}child(e){const t=new se(e),s=ht(this.ref,e);return new pn(this._node.getChild(t),s,he)}exists(){return!this._node.isEmpty()}exportVal(){return this._node.val(!0)}forEach(e){return this._node.isLeafNode()?!1:!!this._node.forEachChild(this._index,(s,i)=>e(new pn(i,ht(this.ref,s),he)))}hasChild(e){const t=new se(e);return!this._node.getChild(t).isEmpty()}hasChildren(){return this._node.isLeafNode()?!1:!this._node.isEmpty()}toJSON(){return this.exportVal()}val(){return this._node.val()}}function Oe(n,e){return n=Fe(n),n._checkNotDeleted("ref"),e!==void 0?ht(n._root,e):n._root}function ht(n,e){return n=Fe(n),W(n._path)===null?jf("child","path",e):tl("child","path",e),new ut(n._repo,pe(n._path,e))}function pp(n,e){n=Fe(n),nl("set",n._path),Bf("set",e,n._path);const t=new Zt;return tp(n._repo,n._path,e,null,t.wrapCallback(()=>{})),t.promise}function mp(n,e){Vf("update",e,n._path);const t=new Zt;return np(n._repo,n._path,e,t.wrapCallback(()=>{})),t.promise}function We(n){n=Fe(n);const e=new pl(()=>{}),t=new zs(e);return ep(n._repo,n,t).then(s=>new pn(s,new ut(n._repo,n._path),n._queryParams.getIndex()))}class zs{constructor(e){this.callbackContext=e}respondsTo(e){return e==="value"}createEvent(e,t){const s=t._queryParams.getIndex();return new dp("value",this,new pn(e.snapshotNode,new ut(t._repo,t._path),s))}getEventRunner(e){return e.getEventType()==="cancel"?()=>this.callbackContext.onCancel(e.error):()=>this.callbackContext.onValue(e.snapshot,null)}createCancelEvent(e,t){return this.callbackContext.hasCancelCallback?new fp(this,e,t):null}matches(e){return e instanceof zs?!e.callbackContext||!this.callbackContext?!0:e.callbackContext.matches(this.callbackContext):!1}hasAnyCallback(){return this.callbackContext!==null}}function gp(n,e,t,s,i){let r;if(typeof s=="object"&&(r=void 0,i=s),typeof s=="function"&&(r=s),i&&i.onlyOnce){const l=t,c=(f,d)=>{ll(n._repo,n,a),l(f,d)};c.userCallback=t.userCallback,c.context=t.context,t=c}const o=new pl(t,r||void 0),a=new zs(o);return ip(n._repo,n,a),()=>ll(n._repo,n,a)}function Sr(n,e,t,s){return gp(n,"value",e,t,s)}mf(ut),Ef(ut);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _p="FIREBASE_DATABASE_EMULATOR_HOST",Cr={};let yp=!1;function vp(n,e,t,s){const i=e.lastIndexOf(":"),r=e.substring(0,i),o=In(r);n.repoInfo_=new $o(e,o,n.repoInfo_.namespace,n.repoInfo_.webSocketOnly,n.repoInfo_.nodeAdmin,n.repoInfo_.persistenceKey,n.repoInfo_.includeNamespaceInQueryParams,!0,t),s&&(n.authTokenProvider_=s)}function Ep(n,e,t,s,i){let r=s||n.options.databaseURL;r===void 0&&(n.options.projectId||pt("Can't determine Firebase Database URL. Be sure to include  a Project ID when calling firebase.initializeApp()."),Re("Using default host for project ",n.options.projectId),r=`${n.options.projectId}-default-rtdb.firebaseio.com`);let o=fl(r,i),a=o.repoInfo,l;typeof process<"u"&&Co&&(l=Co[_p]),l?(r=`http://${l}?ns=${a.namespace}`,o=fl(r,i),a=o.repoInfo):o.repoInfo.secure;const c=new Nh(n.name,n.options,e);zf("Invalid Firebase Database URL",o),B(o.path)||pt("Database URL must point to the root of a Firebase Database (not including a child path).");const f=Sp(a,n,c,new Ph(n,t));return new Cp(f,n)}function wp(n,e){const t=Cr[e];(!t||t[n.key]!==n)&&pt(`Database ${e}(${n.repoInfo_}) has already been deleted.`),cl(n),delete t[n.key]}function Sp(n,e,t,s){let i=Cr[e.name];i||(i={},Cr[e.name]=i);let r=i[n.toURLString()];return r&&pt("Database initialized multiple times. Please make sure the format of the database URL matches with each database() call."),r=new Qf(n,yp,t,s),i[n.toURLString()]=r,r}class Cp{constructor(e,t){this._repoInternal=e,this.app=t,this.type="database",this._instanceStarted=!1}get _repo(){return this._instanceStarted||(Jf(this._repoInternal,this.app.options.appId,this.app.options.databaseAuthVariableOverride),this._instanceStarted=!0),this._repoInternal}get _root(){return this._rootInternal||(this._rootInternal=new ut(this._repo,Q())),this._rootInternal}_delete(){return this._rootInternal!==null&&(wp(this._repo,this.app.name),this._repoInternal=null,this._rootInternal=null),Promise.resolve()}_checkNotDeleted(e){this._rootInternal===null&&pt("Cannot call "+e+" on a deleted database.")}}function Ip(n=_o(),e){const t=mo(n,"database").getImmediate({identifier:e});if(!t._instanceStarted){const s=Mc("database");s&&bp(t,...s)}return t}function bp(n,e,t,s={}){n=Fe(n),n._checkNotDeleted("useEmulator");const i=`${e}:${t}`,r=n._repoInternal;if(n._instanceStarted){if(i===n._repoInternal.repoInfo_.host&&Rn(s,r.repoInfo_.emulatorOptions))return;pt("connectDatabaseEmulator() cannot initialize or alter the emulator configuration after the database instance has started.")}let o;if(r.repoInfo_.nodeAdmin)s.mockUserToken&&pt('mockUserToken is not supported by the Admin SDK. For client access with mock users, please use the "firebase" package instead of "firebase-admin".'),o=new ys(ys.OWNER);else if(s.mockUserToken){const a=typeof s.mockUserToken=="string"?s.mockUserToken:Uc(s.mockUserToken,n.app.options.projectId);o=new ys(a)}In(e)&&(Fc(e),Hc("Database",!0)),vp(r,i,s,o)}function Tp(n){n=Fe(n),n._checkNotDeleted("goOffline"),cl(n._repo)}function Ap(n){n=Fe(n),n._checkNotDeleted("goOnline"),rp(n._repo)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Rp(n){ph(_s),en(new Ft("database",(e,{instanceIdentifier:t})=>{const s=e.getProvider("app").getImmediate(),i=e.getProvider("auth-internal"),r=e.getProvider("app-check-internal");return Ep(s,i,r,t)},"PUBLIC").setMultipleInstances(!0)),It(Io,bo,n),It(Io,bo,"esm2017")}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pp{constructor(e,t){this.committed=e,this.snapshot=t}toJSON(){return{committed:this.committed,snapshot:this.snapshot.toJSON()}}}function Np(n,e,t){var s;if(n=Fe(n),nl("Reference.transaction",n._path),n.key===".length"||n.key===".keys")throw"Reference.transaction failed: "+n.key+" is a read-only object.";const i=(s=void 0)!==null&&s!==void 0?s:!0,r=new Zt,o=(l,c,f)=>{let d=null;l?r.reject(l):(d=new pn(f,new ut(n._repo,n._path),he),r.resolve(new Pp(c,d)))},a=Sr(n,()=>{});return op(n._repo,n._path,e,o,a,i),r.promise}mt.prototype.simpleListen=function(n,e){this.sendRequest("q",{p:n},e)},mt.prototype.echo=function(n,e){this.sendRequest("echo",{d:n},e)},Rp();var kp="firebase",Op="11.10.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */It(kp,Op,"app");const ml={apiKey:"AIzaSyAXSdRQn-_CmaFoI2_dGVBBous5VWtVTNE",authDomain:"wooglespulse.firebaseapp.com",databaseURL:"https://wooglespulse-default-rtdb.europe-west1.firebasedatabase.app",projectId:"wooglespulse",storageBucket:"wooglespulse.firebasestorage.app",messagingSenderId:"673555749713",appId:"1:673555749713:web:cb57ee2ec9b52656f31170",measurementId:"G-WQQFBXVGYK"};let Ks=null;function gl(){return Ks||(Ks=nh().length>0?_o():go(ml),Ks)}const Lp=1440*60*1e3,Dp=5;function xp(n){if(!n||typeof n!="object"||Array.isArray(n))return null;let e=null;for(const t of Object.values(n)){if(!t||typeof t!="object"||Array.isArray(t))continue;const s=t.rack;if(!s||typeof s!="object"||Array.isArray(s))continue;const i=s;for(const r of[i.updatedAt,i.confirmedAt])typeof r=="number"&&Number.isFinite(r)&&(e===null||r>e)&&(e=r)}return e}function Mp(n,e,t=Date.now()){if(!n||typeof n!="object"||Array.isArray(n))return[];const s=t-Lp,i=[],r=[];for(const[o,a]of Object.entries(n)){if(o===e)continue;const l=xp(a);l!==null&&l>=s&&l<=t?i.push({gameId:o,lastActivity:l}):r.push(o)}return i.sort((o,a)=>a.lastActivity-o.lastActivity||o.gameId.localeCompare(a.gameId)),r.push(...i.slice(Dp).map(({gameId:o})=>o)),r}function Ir(n){return(n==null?void 0:n.trim().toLowerCase())??""}function Fp(n,e){const t=Ir(e==null?void 0:e.leftUsername),s=Ir(e==null?void 0:e.rightUsername);if(t&&s&&t===s)return{left:null,right:null};const i=[n.player1,n.player2],r=o=>i.find(a=>Ir(a.username)===o)??null;return{left:t?r(t):null,right:s?r(s):null}}const Up=["player1","player2"],Wp=["left","right"];function _l(n){return typeof n=="string"?n.trim().toLowerCase():""}function br(n){return n!==null&&typeof n=="object"?n:null}function Gp(n,e,t){if(e.gameId!==n)return null;const s={},i=[[br(e.players),Up,"players"],[br(e.broadcastPlayers),Wp,"broadcastPlayers"]];for(const r of t){const o=_l(r.username);if(!(!o||!Number.isFinite(r.matchScore))){for(const[a,l,c]of i)if(a)for(const f of l){const d=br(a[f]);if(!d||_l(d.username)!==o)continue;const h=d.matchScore;if(typeof h=="number"&&r.matchScore<h)return null;h!==r.matchScore&&(s[`${c}/${f}/matchScore`]=r.matchScore)}}}return Object.keys(s).length>0?s:null}const Hp="state",Bp="latestMove",$p="session",Tr="players",Ar="finishedGames";class Vp extends Error{constructor(){super("Publish gate closed"),this.name="GateClosedError"}}const jp={gameId:"demo"},zp=2e3;function mn(n){if(typeof n=="number")return Number.isFinite(n)?n:0;if(Array.isArray(n))return n.map(e=>mn(e));if(n!==null&&typeof n=="object"){const e={};for(const[t,s]of Object.entries(n))e[t]=mn(s);return e}return n}function Kp(n,e){const t=n.filter(i=>i.blank===!0&&i.dataLetter==="128"&&i.letter===""&&i.value===0).length,s=n.filter(i=>!(i.letter===""&&i.value===0&&(i.blank===!1&&i.dataLetter==="0"||i.blank===!0&&i.dataLetter==="128")));return console.log("[WPULSE RACK SERIALIZE DEBUG]",{username:e,inputRackLength:n.length,genuineTileCount:s.length,emptyPlaceholderCount:t,outputRackLength:s.length}),s}function qp(n=jp){let e=null,t=null,s=!1,i=!1;function r(){i||(i=!0,console.debug("[Pulse Firebase] Publisher not connected"))}let o=null,a=null;const l=`${Date.now()}-${Math.random().toString(36).slice(2)}`,c=new Set,f=new Set;let d=0,h=!1;const y=new Set;function E(){return n.gate?n.gate.isOpen():!0}function x(){if(!E())throw new Vp}function j(p){y.add(p);const v=()=>{y.delete(p)};return p.then(v,v),p}function Y(p,v){return x(),j(pp(p,v))}function de(p,v){return x(),j(mp(p,v))}function ue(p,v){return x(),j(Np(p,v))}function ge(){if(!s||!E()||(t||(e=gl(),t=Ip(e),i=!1),h&&(Ap(t),h=!1),a))return;const p=Oe(t,`${n.gameId}/broadcastConfig`);a=Sr(p,()=>{o&&E()&&me.publishState(o).catch(v=>{console.error("[Pulse Firebase] Failed to republish state after assignment change:",v)})},v=>{console.warn("[Pulse Firebase] Broadcast Configuration listener failed:",v)})}function _t(){a==null||a(),a=null,o=null;const p=t;!p||h||Promise.allSettled([...y]).then(()=>{!E()&&t===p&&!h&&(Tp(p),h=!0)})}function _e(){if(!t)throw new Error("Firebase not connected");return Oe(t,`${n.gameId}/${n.statePath??Hp}`)}function Le(){if(!t)throw new Error("Firebase not connected");return Oe(t,`${n.gameId}/${n.latestMovePath??Bp}`)}function $e(){if(!t)throw new Error("Firebase not connected");return Oe(t,`${n.gameId}/${n.sessionPath??$p}`)}function st(p,v){if(!t)throw new Error("Firebase not connected");return Oe(t,`${n.gameId}/${n.playersPath??Tr}/${p}/${v}/rack`)}function dt(p){return Array.isArray(p)?p.map(v=>(v==null?void 0:v.letter)||(v==null?void 0:v.dataLetter)||"?").join(""):p==null?"null":String(p)}function Ge(p){return p.trim().toLowerCase()}function qt(p){var P,M,te,le,N;const v=Ge(p);if(!v)return!1;for(const X of document.querySelectorAll(".player-card")){const z=X.querySelector(".player-details a"),je=((P=((z==null?void 0:z.getAttribute("href"))??"").split("/").filter(Boolean).pop())==null?void 0:P.trim().toLowerCase())??"",Z=((te=(M=X.querySelector(".player-name"))==null?void 0:M.textContent)==null?void 0:te.trim().toLowerCase())??"",it=((N=(le=X.querySelector(".player-details"))==null?void 0:le.textContent)==null?void 0:N.trim().toLowerCase())??"";if([je,Z,it].some(rt=>rt===v||rt.includes(v)||v.includes(rt)))return X.classList.contains("on-turn")}return!1}async function $(p,v){try{const M=(await We(st(p,v))).val();return M&&typeof M=="object"&&Array.isArray(M.rack)?M.rack:null}catch(P){return console.warn("[WPULSE FIREBASE RACK MUTATION] previous read failed",{gameId:p,username:v,error:P}),null}}async function J(p){const v=t;if(!v)return;const P=`${n.gameId}/${n.playersPath??Tr}`;try{const M=await We(Oe(v,P)),te=Mp(M.val(),p);await Promise.all(te.map(le=>Y(Oe(v,`${P}/${le}`),null))),console.log("[Pulse Firebase] Pruned stale player games",te)}catch(M){console.warn("[Pulse Firebase] Failed to prune stale player games:",M)}}const me={async connect(){s||(s=!0,i=!1,ge())},setGateOpen(p){s&&(p?ge():_t())},disconnect(){a==null||a(),a=null,o=null,s=!1,t=null,e=null},async publishFinalState(p){var v,P;if(!(!s||!t)){try{const[M,te]=await Promise.all([We($e()),We(_e())]),le=((v=M.val())==null?void 0:v.gameId)===((P=p.session)==null?void 0:P.gameId),N=te.val(),X=Array.isArray(N==null?void 0:N.turnHistory)?N.turnHistory.length:N!=null&&N.turnHistory&&typeof N.turnHistory=="object"?Object.keys(N.turnHistory).length:0;if(le&&X>p.turnHistory.length){console.log("[WPULSE GAME OVER] final state skipped: Firebase already has more turns",{existingTurns:X,turns:p.turnHistory.length}),await de(_e(),{gameStatus:"finished"});return}}catch(M){console.warn("[WPULSE GAME OVER] could not compare with the published state",M)}await me.publishState({...p,gameStatus:"finished"})}},async markStateFinished(p){var P;!s||!t||((P=(await We($e())).val())==null?void 0:P.gameId)!==p||await de(_e(),{gameStatus:"finished"})},async markGameFinished(p,v){!s||!t||await ue(Oe(t,`${n.gameId}/${Ar}/${p}`),P=>{if(!P)return{at:Date.now(),source:v}})},async publishMatchScores(p,v){if(!s||!t)return!1;const P=_e(),[M,te,le]=await Promise.all([We(ht(P,"gameId")),We(ht(P,"players")),We(ht(P,"broadcastPlayers"))]),N=Gp(p,{gameId:M.val(),players:te.val(),broadcastPlayers:le.val()},v);return N?(await de(P,N),console.log("[WPULSE GAME OVER] match score updated after game end",{gameId:p,updates:N}),!0):!1},gameResultStore(p){const v=`${n.gameId}/${Ar}/${p}`;return{async latchExists(){return!s||!t||!E()?!1:(await We(Oe(t,`${v}/at`))).exists()},async writeOnce(P){return!s||!t||!E()?!1:(await ue(Oe(t,`${v}/result`),te=>{if(!te)return P})).committed}}},subscribeFinishedGame(p,v){return!s||!t?()=>{}:Sr(Oe(t,`${n.gameId}/${Ar}/${p}`),P=>v(P.val()),P=>console.warn("[WPULSE GAME OVER] finishedGame listener failed:",P))},async acquireStateAuthority(p,v,P,M){var z;if(!s||!t||!p||!v)return!1;const te=n.gameId==="current"?"/current/authority":`${n.gameId}/authority`,le=Oe(t,te),N=p.toLowerCase(),X=await ue(le,Ve=>{var Ie;const je=Date.now(),Z=Ve&&typeof Ve=="object"?Ve:null,it=(Z==null?void 0:Z.gameId)===v,ze=typeof(Z==null?void 0:Z.gameDetectedAt)!="number"||M>Z.gameDetectedAt,rt=it&&typeof(Z==null?void 0:Z.turnCount)=="number"&&Z.turnCount>P;if(!it&&!ze||rt)return;const Ke=(Z==null?void 0:Z.gameId)===v&&Z.turnCount===P,K=Ke&&((Ie=Z==null?void 0:Z.username)==null?void 0:Ie.toLowerCase())===N,He=!Z||typeof Z.leaseUntil!="number"||Z.leaseUntil<=je;if(!(!K&&!He&&Ke))return{username:p,gameId:v,turnCount:P,gameDetectedAt:M,leaseUntil:je+zp,token:l}});return X.committed&&((z=X.snapshot.val())==null?void 0:z.token)===l},async publishState(p){var le;if(!s||!t){r();return}o=p;let v={left:null,right:null};try{const X=(await We(Oe(t,`${n.gameId}/broadcastConfig`))).val();v=Fp(p.players,X&&{leftUsername:typeof X.leftUsername=="string"?X.leftUsername:null,rightUsername:typeof X.rightUsername=="string"?X.rightUsername:null})}catch(N){console.warn("[Pulse Firebase] Could not read Broadcast Configuration for player mapping:",N)}let P=p.turnHistory,M=p.latestMove;if(P.some(N=>N.type==="exchange"&&!N.exchangedTiles))try{const N=(await We(ht(_e(),"turnHistory"))).val();if(Array.isArray(N)){const X=new Map;for(const z of N)if(z&&typeof z.turnNumber=="number"&&typeof z.exchangedTiles=="string"){const Ve=typeof z.tilesExchanged=="number"?z.tilesExchanged:null;us(z.exchangedTiles,Ve)&&X.set(z.turnNumber,z.exchangedTiles)}if(P=P.map(z=>z.type==="exchange"&&!z.exchangedTiles&&X.has(z.turnNumber)?{...z,exchangedTiles:X.get(z.turnNumber)}:z),M&&M.type==="exchange"&&!M.exchangedTiles){const z=X.get(M.turnNumber);z&&(M={...M,exchangedTiles:z})}}}catch(N){console.warn("[Pulse Firebase] Could not read existing exchanged tiles:",N)}const te={gameId:((le=p.session)==null?void 0:le.gameId)??null,connectionStatus:p.connectionStatus,gameStatus:p.gameStatus,players:p.players,broadcastPlayers:v,board:p.board,turnHistory:P,latestMove:M,unseenTiles:p.unseenTiles,tilesInBag:p.tilesInBag,vowels:p.vowels,consonants:p.consonants,lastStateRead:p.lastStateRead,lastFirebasePublish:p.lastFirebasePublish,error:p.error};try{console.log("[Pulse Firebase] Writing state to",_e().toString()),await Y(_e(),mn(te)),console.log("[Pulse Firebase] State write successful")}catch(N){throw console.error("[Pulse Firebase] Failed to publish state:",N),N}},async publishExchangedTiles(p){if(!(!s||!t)){p.length<d&&f.clear(),d=p.length;for(const v of p){if(v.type!=="exchange"||!v.exchangedTiles||!us(v.exchangedTiles,v.tilesExchanged))continue;const P=`${n.gameId}|${v.turnNumber}|${v.exchangedTiles}`;if(!f.has(P))try{const M=ht(_e(),`turnHistory/${v.turnNumber-1}`),te=(await We(M)).val();if(!te||te.turnNumber!==v.turnNumber||te.type!=="exchange")continue;te.exchangedTiles!==v.exchangedTiles&&await Y(ht(M,"exchangedTiles"),v.exchangedTiles);const le=Le(),N=(await We(le)).val();N&&N.turnNumber===v.turnNumber&&N.type==="exchange"&&N.exchangedTiles!==v.exchangedTiles&&await Y(ht(le,"exchangedTiles"),v.exchangedTiles),f.add(P)}catch(M){console.warn("[Pulse Firebase] Failed to publish exchanged tiles:",M)}}}},async publishLatestMove(p){if(!s||!t){r();return}try{console.log("[Pulse Firebase] Writing latestMove to",Le().toString()),await Y(Le(),mn(p)),console.log("[Pulse Firebase] Latest move write successful")}catch(v){throw console.error("[Pulse Firebase] Failed to publish latest move:",v),v}},async publishSession(p){if(!s||!t){r();return}try{console.log("[Pulse Firebase] Writing session to",$e().toString()),await Y($e(),mn(p)),console.log("[Pulse Firebase] Session write successful")}catch(v){throw console.error("[Pulse Firebase] Failed to publish session:",v),v}},async publishPlayerRack(p,v,P){if(!s||!t){r();return}if(!p||!v){console.warn("[Pulse Firebase] Cannot publish player rack: missing gameId or username");return}if(P.length===0){console.warn("[Pulse Firebase] Cannot publish player rack: rack is empty");return}try{const M=st(p,v),te=await $(p,v),le=te!==null&&te.length>P.length,N=qt(v);if(le&&!N){console.log("[WPULSE FIREBASE RACK MUTATION]",{operation:"SKIP",path:`/current/players/${p}/${v}/rack`,username:v,gameId:p,reason:"shorter-rack-while-inactive",candidateRack:dt(P),previousRack:dt(te),activePlayerOnTurn:!1});return}const X={username:v,rack:mn(Kp(P,v)),confirmedAt:Date.now(),updatedAt:Date.now(),source:"player-extension"};console.log("[WPULSE FIREBASE RACK MUTATION]",{operation:"SET",path:`/current/players/${p}/${v}/rack`,username:v,gameId:p,rack:dt(P),previousRack:dt(te),source:"publishPlayerRack",browserIdentity:v}),console.log("[Pulse Firebase] Writing player rack to",M.toString()),console.log("[WPULSE RACK FIREBASE PAYLOAD DEBUG]",{username:v,inputRackLength:P.length,inputRackSignature:JSON.stringify(P),payloadRackLength:X.rack.length,payloadRackSignature:JSON.stringify(X.rack)}),await Y(M,X),console.log("[Pulse Firebase] Player rack write successful"),c.has(p)||(c.add(p),J(p))}catch(M){throw console.error("[Pulse Firebase] Failed to publish player rack:",M),M}},async publishExtensionHeartbeat(p,v){if(!s||!t){r();return}if(!p){console.warn("[Pulse Firebase] Cannot publish heartbeat: missing username");return}try{const P=Oe(t,`${n.gameId}/heartbeat/${p}`);await Y(P,{username:p,running:!0,gameId:v,timestamp:Date.now()})}catch(P){console.error("[Pulse Firebase] Failed to publish heartbeat:",P)}},async removePlayerGame(p){if(!s||!t){r();return}if(!p){console.warn("[Pulse Firebase] Cannot remove player game: missing gameId");return}try{const v=`${n.gameId}/${n.playersPath??Tr}/${p}`;console.log("[WPULSE FIREBASE RACK MUTATION]",{operation:"REMOVE",path:`/current/players/${p}`,username:null,gameId:p,rack:null,previousRack:"entire-game-node",source:"removePlayerGame",browserIdentity:null}),console.log("[Pulse Firebase] Removing stale game players",v),await Y(Oe(t,v),null),console.log("[Pulse Firebase] Stale game players removed")}catch(v){console.error("[Pulse Firebase] Failed to remove stale game players:",v)}},isConnected(){return s&&t!==null}};return{...me,acquireStateAuthority:async(...p)=>E()?me.acquireStateAuthority(...p):!1,publishState:async p=>{E()&&await me.publishState(p)},publishLatestMove:async p=>{E()&&await me.publishLatestMove(p)},publishExchangedTiles:async p=>{E()&&await me.publishExchangedTiles(p)},publishSession:async p=>{E()&&await me.publishSession(p)},publishPlayerRack:async(...p)=>{E()&&await me.publishPlayerRack(...p)},publishExtensionHeartbeat:async(...p)=>{E()&&await me.publishExtensionHeartbeat(...p)},removePlayerGame:async p=>{E()&&await me.removePlayerGame(p)},publishFinalState:async p=>{E()&&await me.publishFinalState(p)},markStateFinished:async p=>{E()&&await me.markStateFinished(p)},markGameFinished:async(...p)=>{E()&&await me.markGameFinished(...p)},publishMatchScores:async(...p)=>E()?me.publishMatchScores(...p):!1,subscribeFinishedGame:(p,v)=>E()?me.subscribeFinishedGame(p,v):()=>{}}}function yl(n,e){var t={};for(var s in n)Object.prototype.hasOwnProperty.call(n,s)&&e.indexOf(s)<0&&(t[s]=n[s]);if(n!=null&&typeof Object.getOwnPropertySymbols=="function")for(var i=0,s=Object.getOwnPropertySymbols(n);i<s.length;i++)e.indexOf(s[i])<0&&Object.prototype.propertyIsEnumerable.call(n,s[i])&&(t[s[i]]=n[s[i]]);return t}typeof SuppressedError=="function"&&SuppressedError;function vl(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const Yp=vl,El=new Tn("auth","Firebase",vl());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qs=new fi("@firebase/auth");function Qp(n,...e){qs.logLevel<=ne.WARN&&qs.warn(`Auth (${_s}): ${n}`,...e)}function Ys(n,...e){qs.logLevel<=ne.ERROR&&qs.error(`Auth (${_s}): ${n}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qs(n,...e){throw Rr(n,...e)}function wl(n,...e){return Rr(n,...e)}function Sl(n,e,t){const s=Object.assign(Object.assign({},Yp()),{[e]:t});return new Tn("auth","Firebase",s).create(e,{appName:n.name})}function es(n){return Sl(n,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function Rr(n,...e){if(typeof n!="string"){const t=e[0],s=[...e.slice(1)];return s[0]&&(s[0].appName=n.name),n._errorFactory.create(t,...s)}return El.create(n,...e)}function ee(n,e,...t){if(!n)throw Rr(e,...t)}function ts(n){const e="INTERNAL ASSERTION FAILED: "+n;throw Ys(e),new Error(e)}function Js(n,e){n||ts(e)}function Jp(){return Cl()==="http:"||Cl()==="https:"}function Cl(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xp(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(Jp()||$c()||"connection"in navigator)?navigator.onLine:!0}function Zp(){if(typeof navigator>"u")return null;const n=navigator;return n.languages&&n.languages[0]||n.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class em{constructor(e,t){this.shortDelay=e,this.longDelay=t,Js(t>e,"Short delay should be less than long delay!"),this.isMobile=ui()||no()}get(){return Xp()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tm(n,e){Js(n.emulator,"Emulator should always be set here");const{url:t}=n.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Il{static initialize(e,t,s){this.fetchImpl=e,t&&(this.headersImpl=t),s&&(this.responseImpl=s)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;ts("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;ts("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;ts("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const nm={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sm=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],im=new em(3e4,6e4);function Pr(n,e){return n.tenantId&&!e.tenantId?Object.assign(Object.assign({},e),{tenantId:n.tenantId}):e}async function ns(n,e,t,s,i={}){return bl(n,i,async()=>{let r={},o={};s&&(e==="GET"?o=s:r={body:JSON.stringify(s)});const a=hi(Object.assign({key:n.config.apiKey},o)).slice(1),l=await n._getAdditionalHeaders();l["Content-Type"]="application/json",n.languageCode&&(l["X-Firebase-Locale"]=n.languageCode);const c=Object.assign({method:e,headers:l},r);return Bc()||(c.referrerPolicy="no-referrer"),n.emulatorConfig&&In(n.emulatorConfig.host)&&(c.credentials="include"),Il.fetch()(await Tl(n,n.config.apiHost,t,a),c)})}async function bl(n,e,t){n._canInitEmulator=!1;const s=Object.assign(Object.assign({},nm),e);try{const i=new om(n),r=await Promise.race([t(),i.promise]);i.clearNetworkTimeout();const o=await r.json();if("needConfirmation"in o)throw Xs(n,"account-exists-with-different-credential",o);if(r.ok&&!("errorMessage"in o))return o;{const a=r.ok?o.errorMessage:o.error.message,[l,c]=a.split(" : ");if(l==="FEDERATED_USER_ID_ALREADY_LINKED")throw Xs(n,"credential-already-in-use",o);if(l==="EMAIL_EXISTS")throw Xs(n,"email-already-in-use",o);if(l==="USER_DISABLED")throw Xs(n,"user-disabled",o);const f=s[l]||l.toLowerCase().replace(/[_\s]+/g,"-");if(c)throw Sl(n,f,c);Qs(n,f)}}catch(i){if(i instanceof xt)throw i;Qs(n,"network-request-failed",{message:String(i)})}}async function rm(n,e,t,s,i={}){const r=await ns(n,e,t,s,i);return"mfaPendingCredential"in r&&Qs(n,"multi-factor-auth-required",{_serverResponse:r}),r}async function Tl(n,e,t,s){const i=`${e}${t}?${s}`,r=n,o=r.config.emulator?tm(n.config,i):`${n.config.apiScheme}://${i}`;return sm.includes(t)&&(await r._persistenceManagerAvailable,r._getPersistenceType()==="COOKIE")?r._getPersistence()._getFinalTarget(o).toString():o}class om{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,s)=>{this.timer=setTimeout(()=>s(wl(this.auth,"network-request-failed")),im.get())})}}function Xs(n,e,t){const s={appName:n.name};t.email&&(s.email=t.email),t.phoneNumber&&(s.phoneNumber=t.phoneNumber);const i=wl(n,e,s);return i.customData._tokenResponse=t,i}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function am(n,e){return ns(n,"POST","/v1/accounts:delete",e)}async function Zs(n,e){return ns(n,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ss(n){if(n)try{const e=new Date(Number(n));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function lm(n,e=!1){const t=Fe(n),s=await t.getIdToken(e),i=Al(s);ee(i&&i.exp&&i.auth_time&&i.iat,t.auth,"internal-error");const r=typeof i.firebase=="object"?i.firebase:void 0,o=r==null?void 0:r.sign_in_provider;return{claims:i,token:s,authTime:ss(Nr(i.auth_time)),issuedAtTime:ss(Nr(i.iat)),expirationTime:ss(Nr(i.exp)),signInProvider:o||null,signInSecondFactor:(r==null?void 0:r.sign_in_second_factor)||null}}function Nr(n){return Number(n)*1e3}function Al(n){const[e,t,s]=n.split(".");if(e===void 0||t===void 0||s===void 0)return Ys("JWT malformed, contained fewer than 3 sections"),null;try{const i=fs(t);return i?JSON.parse(i):(Ys("Failed to decode base64 JWT payload"),null)}catch(i){return Ys("Caught error parsing JWT payload as JSON",i==null?void 0:i.toString()),null}}function Rl(n){const e=Al(n);return ee(e,"internal-error"),ee(typeof e.exp<"u","internal-error"),ee(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function kr(n,e,t=!1){if(t)return e;try{return await e}catch(s){throw s instanceof xt&&cm(s)&&n.auth.currentUser===n&&await n.auth.signOut(),s}}function cm({code:n}){return n==="auth/user-disabled"||n==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class um{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){var t;if(e){const s=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),s}else{this.errorBackoff=3e4;const i=((t=this.user.stsTokenManager.expirationTime)!==null&&t!==void 0?t:0)-Date.now()-3e5;return Math.max(0,i)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Or{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=ss(this.lastLoginAt),this.creationTime=ss(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ei(n){var e;const t=n.auth,s=await n.getIdToken(),i=await kr(n,Zs(t,{idToken:s}));ee(i==null?void 0:i.users.length,t,"internal-error");const r=i.users[0];n._notifyReloadListener(r);const o=!((e=r.providerUserInfo)===null||e===void 0)&&e.length?Pl(r.providerUserInfo):[],a=dm(n.providerData,o),l=n.isAnonymous,c=!(n.email&&r.passwordHash)&&!(a!=null&&a.length),f=l?c:!1,d={uid:r.localId,displayName:r.displayName||null,photoURL:r.photoUrl||null,email:r.email||null,emailVerified:r.emailVerified||!1,phoneNumber:r.phoneNumber||null,tenantId:r.tenantId||null,providerData:a,metadata:new Or(r.createdAt,r.lastLoginAt),isAnonymous:f};Object.assign(n,d)}async function hm(n){const e=Fe(n);await ei(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function dm(n,e){return[...n.filter(s=>!e.some(i=>i.providerId===s.providerId)),...e]}function Pl(n){return n.map(e=>{var{providerId:t}=e,s=yl(e,["providerId"]);return{providerId:t,uid:s.rawId||"",displayName:s.displayName||null,email:s.email||null,phoneNumber:s.phoneNumber||null,photoURL:s.photoUrl||null}})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function fm(n,e){const t=await bl(n,{},async()=>{const s=hi({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:i,apiKey:r}=n.config,o=await Tl(n,i,"/v1/token",`key=${r}`),a=await n._getAdditionalHeaders();a["Content-Type"]="application/x-www-form-urlencoded";const l={method:"POST",headers:a,body:s};return n.emulatorConfig&&In(n.emulatorConfig.host)&&(l.credentials="include"),Il.fetch()(o,l)});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function pm(n,e){return ns(n,"POST","/v2/accounts:revokeToken",Pr(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gn{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){ee(e.idToken,"internal-error"),ee(typeof e.idToken<"u","internal-error"),ee(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):Rl(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){ee(e.length!==0,"internal-error");const t=Rl(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(ee(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:s,refreshToken:i,expiresIn:r}=await fm(e,t);this.updateTokensAndExpiration(s,i,Number(r))}updateTokensAndExpiration(e,t,s){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+s*1e3}static fromJSON(e,t){const{refreshToken:s,accessToken:i,expirationTime:r}=t,o=new gn;return s&&(ee(typeof s=="string","internal-error",{appName:e}),o.refreshToken=s),i&&(ee(typeof i=="string","internal-error",{appName:e}),o.accessToken=i),r&&(ee(typeof r=="number","internal-error",{appName:e}),o.expirationTime=r),o}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new gn,this.toJSON())}_performRefresh(){return ts("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function kt(n,e){ee(typeof n=="string"||typeof n>"u","internal-error",{appName:e})}class nt{constructor(e){var{uid:t,auth:s,stsTokenManager:i}=e,r=yl(e,["uid","auth","stsTokenManager"]);this.providerId="firebase",this.proactiveRefresh=new um(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=t,this.auth=s,this.stsTokenManager=i,this.accessToken=i.accessToken,this.displayName=r.displayName||null,this.email=r.email||null,this.emailVerified=r.emailVerified||!1,this.phoneNumber=r.phoneNumber||null,this.photoURL=r.photoURL||null,this.isAnonymous=r.isAnonymous||!1,this.tenantId=r.tenantId||null,this.providerData=r.providerData?[...r.providerData]:[],this.metadata=new Or(r.createdAt||void 0,r.lastLoginAt||void 0)}async getIdToken(e){const t=await kr(this,this.stsTokenManager.getToken(this.auth,e));return ee(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return lm(this,e)}reload(){return hm(this)}_assign(e){this!==e&&(ee(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>Object.assign({},t)),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new nt(Object.assign(Object.assign({},this),{auth:e,stsTokenManager:this.stsTokenManager._clone()}));return t.metadata._copy(this.metadata),t}_onReload(e){ee(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let s=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),s=!0),t&&await ei(this),await this.auth._persistUserIfCurrent(this),s&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(St(this.auth.app))return Promise.reject(es(this.auth));const e=await this.getIdToken();return await kr(this,am(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return Object.assign(Object.assign({uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>Object.assign({},e)),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId},this.metadata.toJSON()),{apiKey:this.auth.config.apiKey,appName:this.auth.name})}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){var s,i,r,o,a,l,c,f;const d=(s=t.displayName)!==null&&s!==void 0?s:void 0,h=(i=t.email)!==null&&i!==void 0?i:void 0,y=(r=t.phoneNumber)!==null&&r!==void 0?r:void 0,E=(o=t.photoURL)!==null&&o!==void 0?o:void 0,x=(a=t.tenantId)!==null&&a!==void 0?a:void 0,j=(l=t._redirectEventId)!==null&&l!==void 0?l:void 0,Y=(c=t.createdAt)!==null&&c!==void 0?c:void 0,de=(f=t.lastLoginAt)!==null&&f!==void 0?f:void 0,{uid:ue,emailVerified:ge,isAnonymous:_t,providerData:_e,stsTokenManager:Le}=t;ee(ue&&Le,e,"internal-error");const $e=gn.fromJSON(this.name,Le);ee(typeof ue=="string",e,"internal-error"),kt(d,e.name),kt(h,e.name),ee(typeof ge=="boolean",e,"internal-error"),ee(typeof _t=="boolean",e,"internal-error"),kt(y,e.name),kt(E,e.name),kt(x,e.name),kt(j,e.name),kt(Y,e.name),kt(de,e.name);const st=new nt({uid:ue,auth:e,email:h,emailVerified:ge,displayName:d,isAnonymous:_t,photoURL:E,phoneNumber:y,tenantId:x,stsTokenManager:$e,createdAt:Y,lastLoginAt:de});return _e&&Array.isArray(_e)&&(st.providerData=_e.map(dt=>Object.assign({},dt))),j&&(st._redirectEventId=j),st}static async _fromIdTokenResponse(e,t,s=!1){const i=new gn;i.updateFromServerResponse(t);const r=new nt({uid:t.localId,auth:e,stsTokenManager:i,isAnonymous:s});return await ei(r),r}static async _fromGetAccountInfoResponse(e,t,s){const i=t.users[0];ee(i.localId!==void 0,"internal-error");const r=i.providerUserInfo!==void 0?Pl(i.providerUserInfo):[],o=!(i.email&&i.passwordHash)&&!(r!=null&&r.length),a=new gn;a.updateFromIdToken(s);const l=new nt({uid:i.localId,auth:e,stsTokenManager:a,isAnonymous:o}),c={uid:i.localId,displayName:i.displayName||null,photoURL:i.photoUrl||null,email:i.email||null,emailVerified:i.emailVerified||!1,phoneNumber:i.phoneNumber||null,tenantId:i.tenantId||null,providerData:r,metadata:new Or(i.createdAt,i.lastLoginAt),isAnonymous:!(i.email&&i.passwordHash)&&!(r!=null&&r.length)};return Object.assign(l,c),l}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Nl=new Map;function Kt(n){Js(n instanceof Function,"Expected a class definition");let e=Nl.get(n);return e?(Js(e instanceof n,"Instance stored in cache mismatched with class"),e):(e=new n,Nl.set(n,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kl{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}kl.type="NONE";const Ol=kl;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Lr(n,e,t){return`firebase:${n}:${e}:${t}`}class _n{constructor(e,t,s){this.persistence=e,this.auth=t,this.userKey=s;const{config:i,name:r}=this.auth;this.fullUserKey=Lr(this.userKey,i.apiKey,r),this.fullPersistenceKey=Lr("persistence",i.apiKey,r),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const t=await Zs(this.auth,{idToken:e}).catch(()=>{});return t?nt._fromGetAccountInfoResponse(this.auth,t,e):null}return nt._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,s="authUser"){if(!t.length)return new _n(Kt(Ol),e,s);const i=(await Promise.all(t.map(async c=>{if(await c._isAvailable())return c}))).filter(c=>c);let r=i[0]||Kt(Ol);const o=Lr(s,e.config.apiKey,e.name);let a=null;for(const c of t)try{const f=await c._get(o);if(f){let d;if(typeof f=="string"){const h=await Zs(e,{idToken:f}).catch(()=>{});if(!h)break;d=await nt._fromGetAccountInfoResponse(e,h,f)}else d=nt._fromJSON(e,f);c!==r&&(a=d),r=c;break}}catch{}const l=i.filter(c=>c._shouldAllowMigration);return!r._shouldAllowMigration||!l.length?new _n(r,e,s):(r=l[0],a&&await r._set(o,a.toJSON()),await Promise.all(t.map(async c=>{if(c!==r)try{await c._remove(o)}catch{}})),new _n(r,e,s))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ll(n){const e=n.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(ym(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(mm(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(Em(e))return"Blackberry";if(wm(e))return"Webos";if(gm(e))return"Safari";if((e.includes("chrome/")||_m(e))&&!e.includes("edge/"))return"Chrome";if(vm(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,s=n.match(t);if((s==null?void 0:s.length)===2)return s[1]}return"Other"}function mm(n=ct()){return/firefox\//i.test(n)}function gm(n=ct()){const e=n.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function _m(n=ct()){return/crios\//i.test(n)}function ym(n=ct()){return/iemobile/i.test(n)}function vm(n=ct()){return/android/i.test(n)}function Em(n=ct()){return/blackberry/i.test(n)}function wm(n=ct()){return/webos/i.test(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Dl(n,e=[]){let t;switch(n){case"Browser":t=Ll(ct());break;case"Worker":t=`${Ll(ct())}-${n}`;break;default:t=n}const s=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${_s}/${s}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sm{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const s=r=>new Promise((o,a)=>{try{const l=e(r);o(l)}catch(l){a(l)}});s.onAbort=t,this.queue.push(s);const i=this.queue.length-1;return()=>{this.queue[i]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const s of this.queue)await s(e),s.onAbort&&t.push(s.onAbort)}catch(s){t.reverse();for(const i of t)try{i()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:s==null?void 0:s.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Cm(n,e={}){return ns(n,"GET","/v2/passwordPolicy",Pr(n,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Im=6;class bm{constructor(e){var t,s,i,r;const o=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=(t=o.minPasswordLength)!==null&&t!==void 0?t:Im,o.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=o.maxPasswordLength),o.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=o.containsLowercaseCharacter),o.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=o.containsUppercaseCharacter),o.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=o.containsNumericCharacter),o.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=o.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=(i=(s=e.allowedNonAlphanumericCharacters)===null||s===void 0?void 0:s.join(""))!==null&&i!==void 0?i:"",this.forceUpgradeOnSignin=(r=e.forceUpgradeOnSignin)!==null&&r!==void 0?r:!1,this.schemaVersion=e.schemaVersion}validatePassword(e){var t,s,i,r,o,a;const l={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,l),this.validatePasswordCharacterOptions(e,l),l.isValid&&(l.isValid=(t=l.meetsMinPasswordLength)!==null&&t!==void 0?t:!0),l.isValid&&(l.isValid=(s=l.meetsMaxPasswordLength)!==null&&s!==void 0?s:!0),l.isValid&&(l.isValid=(i=l.containsLowercaseLetter)!==null&&i!==void 0?i:!0),l.isValid&&(l.isValid=(r=l.containsUppercaseLetter)!==null&&r!==void 0?r:!0),l.isValid&&(l.isValid=(o=l.containsNumericCharacter)!==null&&o!==void 0?o:!0),l.isValid&&(l.isValid=(a=l.containsNonAlphanumericCharacter)!==null&&a!==void 0?a:!0),l}validatePasswordLengthOptions(e,t){const s=this.customStrengthOptions.minPasswordLength,i=this.customStrengthOptions.maxPasswordLength;s&&(t.meetsMinPasswordLength=e.length>=s),i&&(t.meetsMaxPasswordLength=e.length<=i)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let s;for(let i=0;i<e.length;i++)s=e.charAt(i),this.updatePasswordCharacterOptionsStatuses(t,s>="a"&&s<="z",s>="A"&&s<="Z",s>="0"&&s<="9",this.allowedNonAlphanumericCharacters.includes(s))}updatePasswordCharacterOptionsStatuses(e,t,s,i,r){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=s)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=i)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=r))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tm{constructor(e,t,s,i){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=s,this.config=i,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new Ml(this),this.idTokenSubscription=new Ml(this),this.beforeStateQueue=new Sm(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=El,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=i.sdkClientVersion,this._persistenceManagerAvailable=new Promise(r=>this._resolvePersistenceManagerAvailable=r)}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=Kt(t)),this._initializationPromise=this.queue(async()=>{var s,i,r;if(!this._deleted&&(this.persistenceManager=await _n.create(this,e),(s=this._resolvePersistenceManagerAvailable)===null||s===void 0||s.call(this),!this._deleted)){if(!((i=this._popupRedirectResolver)===null||i===void 0)&&i._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((r=this.currentUser)===null||r===void 0?void 0:r.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await Zs(this,{idToken:e}),s=await nt._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(s)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var t;if(St(this.app)){const o=this.app.settings.authIdToken;return o?new Promise(a=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(o).then(a,a))}):this.directlySetCurrentUser(null)}const s=await this.assertedPersistence.getCurrentUser();let i=s,r=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const o=(t=this.redirectUser)===null||t===void 0?void 0:t._redirectEventId,a=i==null?void 0:i._redirectEventId,l=await this.tryRedirectSignIn(e);(!o||o===a)&&(l!=null&&l.user)&&(i=l.user,r=!0)}if(!i)return this.directlySetCurrentUser(null);if(!i._redirectEventId){if(r)try{await this.beforeStateQueue.runMiddleware(i)}catch(o){i=s,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(o))}return i?this.reloadAndSetCurrentUserOrClear(i):this.directlySetCurrentUser(null)}return ee(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===i._redirectEventId?this.directlySetCurrentUser(i):this.reloadAndSetCurrentUserOrClear(i)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await ei(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=Zp()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(St(this.app))return Promise.reject(es(this));const t=e?Fe(e):null;return t&&ee(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&ee(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return St(this.app)?Promise.reject(es(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return St(this.app)?Promise.reject(es(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(Kt(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await Cm(this),t=new bm(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new Tn("auth","Firebase",e())}onAuthStateChanged(e,t,s){return this.registerStateListener(this.authStateSubscription,e,t,s)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,s){return this.registerStateListener(this.idTokenSubscription,e,t,s)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const s=this.onAuthStateChanged(()=>{s(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),s={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(s.tenantId=this.tenantId),await pm(this,s)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)===null||e===void 0?void 0:e.toJSON()}}async _setRedirectUser(e,t){const s=await this.getOrInitRedirectPersistenceManager(t);return e===null?s.removeCurrentUser():s.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&Kt(e)||this._popupRedirectResolver;ee(t,this,"argument-error"),this.redirectPersistenceManager=await _n.create(this,[Kt(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,s;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)===null||t===void 0?void 0:t._redirectEventId)===e?this._currentUser:((s=this.redirectUser)===null||s===void 0?void 0:s._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var e,t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const s=(t=(e=this.currentUser)===null||e===void 0?void 0:e.uid)!==null&&t!==void 0?t:null;this.lastNotifiedUid!==s&&(this.lastNotifiedUid=s,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,s,i){if(this._deleted)return()=>{};const r=typeof t=="function"?t:t.next.bind(t);let o=!1;const a=this._isInitialized?Promise.resolve():this._initializationPromise;if(ee(a,this,"internal-error"),a.then(()=>{o||r(this.currentUser)}),typeof t=="function"){const l=e.addObserver(t,s,i);return()=>{o=!0,l()}}else{const l=e.addObserver(t);return()=>{o=!0,l()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return ee(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=Dl(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var e;const t={"X-Client-Version":this.clientVersion};this.app.options.appId&&(t["X-Firebase-gmpid"]=this.app.options.appId);const s=await((e=this.heartbeatServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getHeartbeatsHeader());s&&(t["X-Firebase-Client"]=s);const i=await this._getAppCheckToken();return i&&(t["X-Firebase-AppCheck"]=i),t}async _getAppCheckToken(){var e;if(St(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const t=await((e=this.appCheckServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getToken());return t!=null&&t.error&&Qp(`Error while retrieving App Check token: ${t.error}`),t==null?void 0:t.token}}function xl(n){return Fe(n)}class Ml{constructor(e){this.auth=e,this.observer=null,this.addObserver=Zc(t=>this.observer=t)}get next(){return ee(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Am(n,e){const t=mo(n,"auth");if(t.isInitialized()){const i=t.getImmediate(),r=t.getOptions();if(Rn(r,e??{}))return i;Qs(i,"already-initialized")}return t.initialize({options:e})}function Rm(n,e){const t=(e==null?void 0:e.persistence)||[],s=(Array.isArray(t)?t:[t]).map(Kt);e!=null&&e.errorMap&&n._updateErrorMap(e.errorMap),n._initializeWithPersistence(s,e==null?void 0:e.popupRedirectResolver)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Pm(n,e){return rm(n,"POST","/v1/accounts:signUp",Pr(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class is{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,s,i=!1){const r=await nt._fromIdTokenResponse(e,s,i),o=Fl(s);return new is({user:r,providerId:o,_tokenResponse:s,operationType:t})}static async _forOperation(e,t,s){await e._updateTokensIfNecessary(s,!0);const i=Fl(s);return new is({user:e,providerId:i,_tokenResponse:s,operationType:t})}}function Fl(n){return n.providerId?n.providerId:"phoneNumber"in n?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Nm(n){var e;if(St(n.app))return Promise.reject(es(n));const t=xl(n);if(await t._initializationPromise,!((e=t.currentUser)===null||e===void 0)&&e.isAnonymous)return new is({user:t.currentUser,providerId:null,operationType:"signIn"});const s=await Pm(t,{returnSecureToken:!0}),i=await is._fromIdTokenResponse(t,"signIn",s,!0);return await t._updateCurrentUser(i.user),i}var Ul="@firebase/auth",Wl="1.10.8";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class km{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)===null||e===void 0?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(s=>{e((s==null?void 0:s.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){ee(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Om(n){switch(n){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function Lm(n){en(new Ft("auth",(e,{options:t})=>{const s=e.getProvider("app").getImmediate(),i=e.getProvider("heartbeat"),r=e.getProvider("app-check-internal"),{apiKey:o,authDomain:a}=s.options;ee(o&&!o.includes(":"),"invalid-api-key",{appName:s.name});const l={apiKey:o,authDomain:a,clientPlatform:n,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:Dl(n)},c=new Tm(s,i,r,l);return Rm(c,t),c},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,s)=>{e.getProvider("auth-internal").initialize()})),en(new Ft("auth-internal",e=>{const t=xl(e.getProvider("auth").getImmediate());return(s=>new km(s))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),It(Ul,Wl,Om(n)),It(Ul,Wl,"esm2017")}Lm("WebExtension");async function Dm(n){const e=await n(!1);return e.status===401?n(!0):e}const rs="wpulseAuth:",Gl="wpulseAuthSpike";class Hl{constructor(){ls(this,"type","LOCAL");ls(this,"listeners",new Map);ls(this,"lastWritten",new Map)}async _isAvailable(){var e;try{return typeof chrome<"u"&&!!((e=chrome.storage)!=null&&e.local)}catch{return!1}}async _set(e,t){const s=JSON.stringify(t);this.lastWritten.set(e,s),await chrome.storage.local.set({[rs+e]:s})}async _get(e){const s=(await chrome.storage.local.get(rs+e))[rs+e];if(typeof s!="string")return null;try{return JSON.parse(s)}catch{return null}}async _remove(e){this.lastWritten.set(e,null),await chrome.storage.local.remove(rs+e)}_addListener(e,t){const s=(r,o)=>{if(o!=="local")return;const a=r[rs+e];if(!a)return;const l=typeof a.newValue=="string"?a.newValue:null;if(this.lastWritten.get(e)===l)return;let c=null;try{c=l===null?null:JSON.parse(l)}catch{c=null}t(c)};let i=this.listeners.get(e);i||(i=new Map,this.listeners.set(e,i)),i.set(t,s),chrome.storage.onChanged.addListener(s)}_removeListener(e,t){var i,r;const s=(i=this.listeners.get(e))==null?void 0:i.get(t);s&&(chrome.storage.onChanged.removeListener(s),(r=this.listeners.get(e))==null||r.delete(t))}}ls(Hl,"type","LOCAL");let yn=null;async function xm(n){const e=typeof navigator<"u"?navigator.locks:void 0;return e?e.request("wpulse-install-auth",n):n()}let Dr=!1;function Bl(){return yn||(yn=xm(async()=>{const n=Am(gl(),{persistence:Hl});return await n.authStateReady(),n.currentUser?Dr=!0:(Dr=!1,await Nm(n)),n}),yn.catch(()=>{yn=null}),yn)}async function $l(){const n=await Bl();if(!n.currentUser)throw new Error("No install identity");return n.currentUser.uid}async function Mm(n=!1){const e=await Bl();if(!e.currentUser)throw new Error("No install identity");return e.currentUser.getIdToken(n)}function Vl(n){return Dm(async e=>{const t=await Mm(e),s=`${ml.databaseURL}/${n}.json?auth=${encodeURIComponent(t)}`,i=await fetch(s,{cache:"no-store"});return{status:i.status,body:await i.text()}})}function Fm(){return new Promise(n=>{try{chrome.storage.local.get(Gl,e=>{n((e==null?void 0:e[Gl])===!0)})}catch{n(!1)}})}async function Um(){if(!await Fm())return;const n={uid:null,reused:null,restStatus:null,restBody:null,error:null};try{n.uid=await $l(),n.reused=Dr;const{status:e,body:t}=await Vl("control/enabled");n.restStatus=e,n.restBody=t}catch(e){n.error=e instanceof Error?`${e.name}: ${e.message}`:String(e)}console.log("[WPULSE AUTH SPIKE]",JSON.stringify(n))}const Wm=120*1e3;function xr(n){return n==="broadcasting"}function jl(n){return typeof n=="object"&&n!==null&&!Array.isArray(n)}function zl(n,e){return n.length>0&&n.toLowerCase()===e.toLowerCase()}function Gm(n){const{enabled:e,approved:t,pair:s,username:i}=n;return e===void 0?"checking":e!==!0?"disabled":t===void 0?"checking":jl(t)?s===void 0?"checking":!jl(s)||typeof s.player1!="string"||typeof s.player2!="string"?"not-selected":i===void 0?"checking":typeof i!="string"||i.length===0?"not-selected":zl(i,s.player1)||zl(i,s.player2)?"broadcasting":"not-selected":"not-approved"}const Kl={values:null,lastGoodAt:null,denied:!1};function Hm(n,e,t){switch(e.kind){case"ok":return{values:e.values,lastGoodAt:t,denied:!1};case"denied":return{values:null,lastGoodAt:null,denied:!0};case"error":return n}}function Bm(n,e,t,s=Wm){return n.denied?"not-approved":!n.values||n.lastGoodAt===null||t-n.lastGoodAt>s?"checking":Gm({...n.values,username:e})}const $m=1e4,Vm=2e3;function jm(n){try{return{ok:!0,value:JSON.parse(n)}}catch{return{ok:!1}}}function zm(n){if(n.some(r=>r.status===401||r.status===403))return{kind:"denied"};if(n.some(r=>r.status!==200))return{kind:"error"};const e=n.map(r=>jm(r.body));if(e.some(r=>!r.ok))return{kind:"denied"};const[t,s,i]=e.map(r=>r.ok?r.value:void 0);return{kind:"ok",values:{enabled:t,pair:s,approved:i}}}function Km(n){const e=n.now??(()=>Date.now()),t=n.random??Math.random;let s=Kl,i=null,r=null,o=!1,a=0;function l(){const h=Bm(s,n.getUsername(),e());if(h===i)return;const y=i;i=h,n.onStatus(h,y)}async function c(){var h;try{const y=await n.getInstallId();(h=n.onInstallId)==null||h.call(n,y);const E=await Promise.all([n.restGet("control/enabled"),n.restGet("control/pair"),n.restGet(`control/approvedInstalls/${encodeURIComponent(y)}`)]);return zm(E)}catch{return{kind:"error"}}}function f(){if(!o)return;r!==null&&clearTimeout(r);const h=$m+Math.floor(t()*Vm);r=setTimeout(()=>void d(),h)}async function d(){var E;if(r=null,!o)return;const h=a,y=await c();!o||h!==a||(s=Hm(s,y,e()),y.kind==="ok"&&((E=n.onValues)==null||E.call(n,y.values)),l(),f())}return{start(){o||(o=!0,a+=1,l(),d())},stop(){o=!1,a+=1,r!==null&&(clearTimeout(r),r=null),s=Kl,l()},reevaluate(){o&&l()},refresh(){o&&(r!==null&&(clearTimeout(r),r=null),d())},getStatus(){return i??"checking"},isOpen(){return o&&i!==null&&xr(i)}}}const ql="data-wpulse-content-script";function qm(n){return n===null}const Ym=["gameEndReason","game_end_reason"];function Yl(n,e=0){if(e>3||n===null||typeof n!="object")return;const t=n;for(const s of Ym)if(s in t)return t[s];for(const s of Object.values(t)){const i=Yl(s,e+1);if(i!==void 0)return i}}function Qm(n){const e=Yl(n);if(e==null)return!1;if(typeof e=="number")return e!==0;if(typeof e=="string"){const t=e.trim().toUpperCase();return t!==""&&t!=="0"&&t!=="NONE"}return!1}async function Jm(n,e=fetch){try{const t=await e("/api/game_service.GameMetadataService/GetMetadata",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({gameId:n})});return t.ok?Qm(await t.json()):null}catch{return null}}const Xm=/^(rematch|export gcg)$/i,Zm=/^(examine|exam|analy[sz]e)$/i;function eg(n){let e=!1,t=!1;for(const s of n.querySelectorAll("button, a")){const i=(s.textContent??"").replace(/\s+/g," ").trim();!i||i.length>20||(Xm.test(i)?e=!0:Zm.test(i)&&(t=!0))}return{strong:e,hint:t}}const tg=20;function Ql(n,e){if(e==null||typeof e!="object")return null;const t=e,s=t.source==="api"||t.source==="director"?t.source:"dom";return{gameId:n,at:typeof t.at=="number"?t.at:0,source:s}}function ng(n){const e=new Map,t=()=>{const s=[...e.values()].sort((i,r)=>r.at-i.at).slice(0,tg).map(({gameId:i,at:r,source:o})=>({gameId:i,at:r,source:o}));n.save(s)};return{async load(){for(const s of await n.load())e.has(s.gameId)||e.set(s.gameId,{...s,confirmedRemotely:!0})},isLatched(s){return s!==null&&e.has(s)},set(s){return e.has(s.gameId)?!1:(e.set(s.gameId,{...s,confirmedRemotely:!1}),t(),!0)},applyRemote(s,i){const r=Ql(s,i),o=e.get(s);r?(e.set(s,{...r,confirmedRemotely:!0}),t()):o!=null&&o.confirmedRemotely&&(e.delete(s),t())}}}const Jl=["NONE","TIME","STANDARD","CONSECUTIVE_ZEROES","RESIGNED","ABORTED","TRIPLE_CHALLENGE","CANCELLED","FORCE_FORFEIT"],sg=new Set(["ABORTED","CANCELLED"]);function Xl(n){if(typeof n=="number")return Number.isInteger(n)&&n>0&&n<Jl.length?Jl[n]:null;if(typeof n!="string")return null;const e=n.trim().toUpperCase();return/^\d+$/.test(e)?Xl(Number(e)):e===""||e==="NONE"?null:e}function ig(n){if(n===null||typeof n!="object")return null;const e=n.nickname;return typeof e=="string"&&e.trim()?e.trim():null}function rg(n,e){if(n===null||typeof n!="object")return null;const t=n,s=Xl(t.game_end_reason??t.gameEndReason);if(!s)return null;const r=(Array.isArray(t.players)?t.players:[]).map(ig),o={reason:s,tie:!1,at:e},a=t.winner;!sg.has(s)&&typeof a=="number"&&(a===-1?o.tie=!0:Number.isInteger(a)&&a>=0&&a<r.length&&r[a]&&(o.winnerUsername=r[a]));const l=t.scores;return Array.isArray(l)&&r.length>0&&l.length===r.length&&l.every(c=>typeof c=="number"&&Number.isFinite(c))&&r.every(Boolean)&&(o.scores=r.map((c,f)=>({username:c,score:l[f]}))),o}async function og(n,e={}){const{fetchFn:t=fetch,retries:s=3,delayMs:i=500,wait:r=a=>new Promise(l=>setTimeout(l,a)),now:o=Date.now}=e;for(let a=0;a<=s;a++){a>0&&await r(i);try{const l=await t("/api/game_service.GameMetadataService/GetMetadata",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({gameId:n})});if(!l.ok)continue;const c=rg(await l.json(),o());if(c)return c}catch{}}return null}async function ag(n,e,t){try{const[,s]=await Promise.all([n.catch(()=>{}),e.catch(()=>null)]);return!s||!await t.latchExists()?!1:await t.writeOnce(s)}catch{return!1}}sh("error");const Mr="wpulse_enabled",lg="[PULSE DIAG]";console.log("[WPULSE BUILD]","authority-fix-v2");const ie=(...n)=>console.log(lg,...n),Fr=document.documentElement;if(!Fr||!qm(Fr.getAttribute(ql)))console.log("[PULSE] Duplicate content script injection skipped");else{let n=function(u){try{chrome.runtime.sendMessage({type:"WPULSE_STATUS",...u})}catch(g){Jt(g)}},e=function(u){if(u!==Te){Te=u;try{chrome.runtime.sendMessage({type:"WPULSE_PAGE",inGame:u})}catch(g){Jt(g),Te=null}}},t=function(u){try{chrome.storage.local.set(u)}catch(g){Jt(g)}},s=function(){return(J==null?void 0:J.isOpen())??!1},i=function(){if(!me)return;const u=$.getAutomaticIdentity();return!u||Date.now()>=u.expiresAt?null:u.username},r=function(){var u,g;A==null||A(),A=null,T=null,Le(Cn(window.location.href));try{const S=$.getState(),C=((u=S.session)==null?void 0:u.gameId)??null,V=d(S)??((g=$.getAutomaticIdentity())==null?void 0:g.username)??null;C&&V&&F.delete(`${C}:${V.trim().toLowerCase()}`),$.refreshState()}catch{}Lt()},o=function(){A==null||A(),A=null,T=null,be=null,n({enabled:K,live:!1})},a=function(){const u=i();return u===void 0?{}:{[v]:u}},l=function(u,g){t({[p]:u,...a()});const S=xr(u),C=g!==null&&xr(g);g!==null&&console.log("[WPULSE GATE]",{from:g,to:u}),S!==C&&(re.setGateOpen(S),S?r():o())},c=function(){ie("shutdownPipeline() start"),console.log("[WPULSE READER] DISCONNECT",{reason:"pipeline-shutdown"}),J==null||J.stop(),j(),de(),_e(),N!==null&&(window.clearTimeout(N),N=null),X=null,z=null,Ve=null,je=null,me=!1;try{$.disconnect()}catch(u){ie("reader.disconnect threw",u)}try{re.disconnect()}catch(u){ie("publisher.disconnect threw",u)}le=0,Z=null,F.clear(),fe.clear(),H.clear(),ce+=1,ve="",be=null,Ee=null,e(!1),He=!1,Ie=null,ie("shutdownPipeline() done",{initialized:He,initInFlight:Ie}),n({enabled:K,live:!1})},f=function(u){if(ie("applyEnabledChange()",{from:K,to:u}),u===K){ie("applyEnabledChange() no-op");return}K=u,K?(ie("applyEnabledChange() -> ON -> startPipeline"),at()):(ie("applyEnabledChange() -> OFF -> shutdownPipeline"),c())},d=function(u){const g=$.getAutomaticIdentity();if(g&&[u.players.player1.username,u.players.player2.username].filter(D=>typeof D=="string"&&D.length>0).some(D=>D.toLowerCase()===g.username.toLowerCase()))return g.username;const S=$.getConfirmedUsername();return S&&[u.players.player1.username,u.players.player2.username].filter(D=>typeof D=="string"&&D.length>0).some(D=>D.toLowerCase()===S.toLowerCase())?S:null},h=function(u,g){if(!g||!u.activePlayer)return!1;const S=u.players[u.activePlayer].username;return!!S&&S.toLowerCase()===g.toLowerCase()},y=function(u){return Array.isArray(u)?u.map(g=>`${g.letter}:${g.blank?"1":"0"}`).join(""):""},E=function(u,g){const S=u.board.map(U=>`${U.coordinate}:${U.letter}:${U.tentative?"T":"C"}`).sort(),C=u.players.player1.username.toLowerCase(),V=u.players.player2.username.toLowerCase(),D=u.playerRacks??{};console.log("[PULSE] STATE FINGERPRINT",{source:g,timestamp:Date.now(),board:S.join("|"),tentative:S.filter(U=>U.endsWith(":T")).map(U=>U.split(":")[0]),latestMove:u.latestMove?`${u.latestMove.turnNumber}:${u.latestMove.player}:${u.latestMove.type}:${u.latestMove.coordinate??""}`:null,unseenTiles:(u.unseenTiles??[]).join(""),player1Rack:y(D[C]??((g==null?void 0:g.toLowerCase())===C?u.rack:[])),player2Rack:y(D[V]??((g==null?void 0:g.toLowerCase())===V?u.rack:[]))})},x=function(){ze&&window.clearTimeout(ze),ze=window.setTimeout(()=>{ze=null;try{const g=$.getState().gameStatus==="active",S=Date.now()-it>2e4;s()&&g&&S&&Me()}catch{}x()},1e4)},j=function(){ze&&(window.clearTimeout(ze),ze=null)},Y=function(){Ke&&window.clearTimeout(Ke),Ke=window.setTimeout(async()=>{var u;if(Ke=null,!!K){try{const g=$.getState(),S=d(g),C=((u=g.session)==null?void 0:u.gameId)??null;S&&s()&&await re.publishExtensionHeartbeat(S,C)}catch{}Y()}},1e4)},de=function(){Ke&&(window.clearTimeout(Ke),Ke=null)},ue=function(u){let g=u;if(!g)try{g=$.getState()}catch{}const S=$.getAutomaticIdentity(),C=g?[g.players.player1.username,g.players.player2.username]:[],V=!!(g!=null&&g.session&&C.some(Boolean)),D=!S||V&&li(S,C),U=D?"retry":"expiry";if(N!==null&&X===U)return;N!==null&&(window.clearTimeout(N),N=null);const q=S?S.expiresAt-Date.now():0,Ye=D?5e3:Math.max(q-6e4,3e4);X=U,N=window.setTimeout(()=>{N=null,X=null,qe()},Ye)},ge=function(u,g,S,C){const V=`${u??""}:${g.trim().toLowerCase()}`,U=(H.get(V)??Promise.resolve()).catch(()=>{}).then(()=>vn(u,g,S,C));H.set(V,U);const q=()=>{H.get(V)===U&&H.delete(V)};return U.then(q,q),U},_t=function(u,g,S,C){var U,q;const V=g&&u.activePlayer&&u.players[u.activePlayer].username.toLowerCase()===g.toLowerCase()?u.activePlayer:null,D=`${((U=u.session)==null?void 0:U.gameId)??""}|${g??""}|${V??""}|${S}|${C}`;D!==ve&&(ve=D,console.log("[WPULSE AUTHORITY]",{username:g,gameId:((q=u.session)==null?void 0:q.gameId)??null,turnCount:u.turnHistory.length,myPlayer:V,activePlayer:u.activePlayer,canPublish:S,reason:C}))},_e=function(){b!==null&&(window.clearTimeout(b),b=null),A==null||A(),A=null,T=null},Le=function(u){!u||u===T||!re.isConnected()||(A==null||A(),T=u,A=re.subscribeFinishedGame(u,g=>{const S=I.isLatched(u);I.applyRemote(u,g),S!==I.isLatched(u)&&He&&$.refreshState()}))},$e=function(u,g){const S=u+JSON.stringify(g);S!==O&&(O=S,console.log("[WPULSE GAME OVER]",u,g))},st=function(){b!==null&&window.clearTimeout(b),b=window.setTimeout(()=>{b=null,K&&ni().finally(st)},_)},dt=function(u){ce+=1,si(u,ce)},Ge=function(){const u=()=>{K&&(J==null||J.start())};if(document.visibilityState==="visible"){u();return}try{chrome.storage.local.get(["onboarding","wpulseWooglesSeen"],g=>{const S=g??{},C=S.onboarding;if(!(!!C&&typeof C=="object"&&C.done!==!0&&S.wpulseWooglesSeen!==!0)){u();return}const D=()=>{document.visibilityState==="visible"&&(document.removeEventListener("visibilitychange",D),u())};document.addEventListener("visibilitychange",D)})}catch{u()}},qt=function(){!K||!He||$.getAutomaticIdentity()||qe(!0)};Fr.setAttribute(ql,"initialized"),console.log("[PULSE] CONTENT SCRIPT LOADED"),Um();const $=bc();let J=null,me=!1;const re=qp({gameId:"current",gate:{isOpen:()=>(J==null?void 0:J.isOpen())??!1}}),p="wpulseGateStatus",v="wpulseGateAccount",P="wpulseGatePair",M="wpulseInstallId";let te=null,le=0,N=null,X=null,z=null,Ve=null,je=null,Z=null,it=Date.now(),ze=null,rt=!1,Ke=null,K=!0,He=!1,Ie=null,Ot=null;const m="wpulse_finished_games",_=3e3,I=ng({load:()=>new Promise(u=>{try{chrome.storage.local.get(m,g=>{const S=g==null?void 0:g[m];u(Array.isArray(S)?S.flatMap(C=>{const V=typeof(C==null?void 0:C.gameId)=="string"?Ql(C.gameId,C):null;return V?[V]:[]}):[])})}catch{u([])}}),save:u=>{try{chrome.storage.local.set({[m]:u})}catch{}}}),R=new Set;let A=null,T=null,b=null,k=!1,O="";const F=new Map,fe=new Map,H=new Map;let ce=0,ve="",be=null,Ee=null,De=!1,Te=null;async function ot(){return new Promise(u=>{try{chrome.storage.local.get(Mr,g=>{const S=g==null?void 0:g[Mr];u(S===void 0?!0:S!==!1)})}catch{u(!0)}})}J=Km({getInstallId:$l,restGet:Vl,getUsername:i,onStatus:l,onValues:u=>{const g=u.pair,S=g&&typeof g=="object"?[g.player1,g.player2].filter(C=>typeof C=="string"&&C.trim()!==""):[];t({[P]:S})},onInstallId:u=>{u!==te&&(te=u,t({[M]:u}))}});async function at(){if(ie("startPipeline() enter",{extensionEnabled:K,initialized:He,initInFlight:!!Ie}),!K){ie("startPipeline() bailed: disabled");return}if(He){ie("startPipeline() bailed: already initialized");return}if(Ie){ie("startPipeline() awaiting existing init"),await Ie;return}Ie=ii();try{await Ie,He=!0,ie("startPipeline() init resolved",{initialized:He})}finally{Ie=null}}async function Me(){if(K&&!rt){rt=!0,console.log("[PULSE] RECOVERY: attempting reader+publisher recovery");try{De=!0,console.log("[WPULSE READER] DISCONNECT",{reason:"recovery"}),$.disconnect(),re.disconnect(),await re.connect(),console.log("[WPULSE READER] CONNECT",{reason:"recovery"}),await $.connect(),De=!1,it=Date.now(),console.log("[PULSE] RECOVERY: recovery complete")}catch(u){De=!1,console.error("[PULSE] RECOVERY: recovery failed",u)}finally{rt=!1}}}async function qe(u=!1){return z||(z=(async()=>{var q;let g;try{g=$.getState()}catch{ue();return}const S=$.getAutomaticIdentity(),C=[g.players.player1.username,g.players.player2.username],D=!!(g.session&&C.some(Boolean))&&li(S,C);if(!u&&S&&!D&&Date.now()<S.expiresAt){ue(g);return}const U=await $.refreshAutomaticIdentity(u||D);if(me=!0,J==null||J.reevaluate(),t(a()),U){const Ye=((q=g.session)==null?void 0:q.gameId)??null;Ye&&F.delete(`${Ye}:${U.username.trim().toLowerCase()}`),console.log("[WPULSE IDENTITY] Fresh identity resolved",{previous:(S==null?void 0:S.username)??null,current:U.username,gameId:Ye}),je=null,$.refreshState(),Lt()}ue()})().finally(()=>{z=null}),z)}async function yt(u){if(u){console.log("[PULSE] FIREBASE WRITE START",{path:"/current/session",data:u});try{await re.publishSession(u),console.log("[PULSE] FIREBASE WRITE SUCCESS","/current/session")}catch(g){console.error("[PULSE] FIREBASE WRITE ERROR","/current/session",g)}}}async function vn(u,g,S,C){const V=g.trim().toLowerCase(),D=Array.isArray(S)?S:[],U=D.map(Qe=>Qe.letter||Qe.dataLetter||"?").join(""),q=["player1","player2"].find(Qe=>C.players[Qe].username.trim().toLowerCase()===V)??null;if(q&&C.activePlayer,console.log("[WPULSE RACK READ]",{username:g,gameId:u,rack:U,tileCount:D.length,source:"state-change",reason:"candidate-rack"}),!u){console.log("[WPULSE RACK SKIPPED]",{username:g,gameId:u,reason:"missing-game-id",previousRack:null,candidateRack:U});return}if(!V){console.log("[WPULSE RACK SKIPPED]",{username:g,gameId:u,reason:"missing-username",previousRack:null,candidateRack:U});return}if(D.length===0){console.log("[WPULSE RACK SKIPPED]",{username:g,gameId:u,reason:"empty-rack-retained",previousRack:null,candidateRack:U});return}const Ye=JSON.stringify(D),Yt=`${u}:${V}`;if(F.get(Yt)===Ye){console.log("[WPULSE RACK SKIPPED]",{username:g,gameId:u,reason:"duplicate-signature",previousRack:U,candidateRack:U});return}console.log("[WPULSE RACK WRITE]",{username:g,gameId:u,rack:U,signature:Ye}),console.log("[PULSE] FIREBASE WRITE START",{path:`/current/players/${u}/${g}/rack`,gameId:u,username:g,tileCount:D.length});try{await re.publishPlayerRack(u,g.trim(),D),F.set(Yt,Ye),fe.set(Yt,D.map(Qe=>({...Qe}))),console.log("[PULSE] FIREBASE WRITE SUCCESS",`/current/players/${u}/${g}/rack`)}catch(Qe){console.error("[PULSE] FIREBASE WRITE ERROR",`/current/players/${u}/${g}/rack`,Qe)}}async function Lt(){var u;if(!(!K||!s()))try{const g=$.getState(),S=d(g),C=((u=g.session)==null?void 0:u.gameId)??null;S&&await re.publishExtensionHeartbeat(S,C)}catch{}}async function Dt(u,g,S){if(I.isLatched(u))return;I.set({gameId:u,at:Date.now(),source:g});const C=R.has(u);if($e("game finished, publishing stopped",{gameId:u,source:g,watchedLive:C}),!C)return;const V=og(u),D=(async()=>{try{S?await re.publishFinalState(S):await re.markStateFinished(u)}catch(U){console.error("[WPULSE GAME OVER] final state write failed",U)}try{await re.markGameFinished(u,g)}catch(U){console.error("[WPULSE GAME OVER] latch write failed",U)}})();ag(D,V,re.gameResultStore(u)).then(U=>{U&&$e("game result recorded",{gameId:u})}),await D}const os=new Map;async function ti(u,g,S){if(!S||!s()||!R.has(u))return;const C=[g.players.player1,g.players.player2].flatMap(D=>D.username&&typeof D.matchScore=="number"?[{username:D.username,matchScore:D.matchScore}]:[]);if(C.length===0)return;const V=JSON.stringify(C);if(os.get(u)!==V){os.set(u,V);try{await re.publishMatchScores(u,C)}catch(D){os.delete(u),console.error("[WPULSE GAME OVER] match score update failed",D)}}}async function ni(){if(!K||k)return;const u=Cn(window.location.href);if(Le(u),!(!u||I.isLatched(u))){k=!0;try{await Jm(u)===!0&&!I.isLatched(u)&&Cn(window.location.href)===u&&await Dt(u,"api",null)}finally{k=!1}}}async function si(u,g){var Zl,ec,tc,nc,sc,ic;if(!K||(e(u.gameStatus==="active"),g!==ce))return;const S=De;console.log("[PULSE] STATE RECEIVED",{connection:u.connectionStatus,game:u.gameStatus,activePlayer:u.activePlayer,turnCount:u.turnHistory.length,latestMove:u.latestMove,session:u.session}),console.log("[WPULSE READER] STATE_CHANGE",{gameId:((Zl=u.session)==null?void 0:Zl.gameId)??null,turnCount:u.turnHistory.length,rackLength:u.rack.length});const C=((ec=u.session)==null?void 0:ec.gameId)??null;C&&C!==Ve&&(Ve=C,qe(!0));const V=$.getAutomaticIdentity(),D=[u.players.player1.username,u.players.player2.username],U=!!(u.session&&D.some(Boolean)&&li(V,D));if(U&&V){const Ae=`${C??""}:${V.username.toLowerCase()}`;Ae!==je&&(je=Ae,console.debug(`[WPULSE IDENTITY] Cached identity is stale for detected game ${C??"(none)"} (cached account: ${V.username})`),qe(!0))}else U||(je=null);const q=d(u);if((q==null?void 0:q.toLowerCase())!==Ee&&(console.log("[WPULSE IDENTITY]",{previous:Ee,current:q,reason:"publish-identity-changed"}),Ee=(q==null?void 0:q.toLowerCase())??null),Le(C),C&&I.isLatched(C)){$e("replay or post-game state ignored",{gameId:C,turnCount:u.turnHistory.length}),ti(C,u,q),n({enabled:K,live:!1});return}const Ye=eg(document);if(C&&Ye.strong){await Dt(C,"dom",q?u:null),n({enabled:K,live:!1});return}if(Ye.hint&&ni(),C&&R.add(C),!s()){it=Date.now(),n({enabled:K,live:!1}),ue();return}const Yt=!!(u.session&&h(u,q));let vt=!1;if(Yt&&q&&C)try{vt=await re.acquireStateAuthority(q,C,u.turnHistory.length,((tc=u.session)==null?void 0:tc.detectedAt)??Date.now())}catch(Ae){Ae instanceof Error&&Ae.message==="disconnect"?console.info("[PULSE] STATE AUTHORITY ERROR",Ae):console.error("[PULSE] STATE AUTHORITY ERROR",Ae)}if(g!==ce)return;it=Date.now();const Qe=vt?u.activePlayer:null;Qe!==be&&(console.log("[WPULSE AUTHORITY CHANGE]",{previous:be,next:Qe,gameId:C}),be=Qe),_t(u,q,vt,vt?"active-player-lease":Yt?"authority-held-by-other-extension":"not-active-player"),Z&&C&&Z!==C&&(console.log("[PULSE] GAME CHANGED",{from:Z,to:C}),le=0,vt&&re.removePlayerGame(Z)),Z=C;const ai=u.turnHistory.length;E(u,q),vt&&u.session&&yt(u.session),ai!==le&&(le=ai,vt&&u.latestMove&&(console.log("[PULSE] FIREBASE WRITE START",{path:"/current/latestMove",data:u.latestMove}),re.publishLatestMove(u.latestMove).catch(Ae=>{console.error("[PULSE] FIREBASE WRITE ERROR","/current/latestMove",Ae)}))),vt?(console.log("[WPULSE SHARED WRITE]",{username:q,gameId:C,turnCount:ai}),re.publishState(u).catch(Ae=>{console.error("[PULSE] FIREBASE WRITE ERROR","/current/state",Ae)})):console.log("[WPULSE SHARED WRITE SKIPPED]",{reason:Yt?"authority-held-by-other-extension":"not-active-player",username:q,gameId:C,turnCount:ai,activePlayer:u.activePlayer}),C&&u.turnHistory.some(Ae=>Ae.type==="exchange"&&Ae.exchangedTiles)&&re.publishExchangedTiles(u.turnHistory),q&&!S?ge(((nc=u.session)==null?void 0:nc.gameId)??null,q,u.rack,u):q?console.log("[WPULSE RACK SKIPPED]",{username:q,gameId:((sc=u.session)==null?void 0:sc.gameId)??null,reason:"stale-recovery-state-retained",previousRack:"firebase-last-known",candidateRack:u.rack.map(Ae=>Ae.letter).join("")}):console.log("[WPULSE RACK SKIPPED]",{username:null,gameId:((ic=u.session)==null?void 0:ic.gameId)??null,reason:"identity-unavailable",previousRack:null,candidateRack:u.rack.map(Ae=>Ae.letter).join("")});const cg=K&&u.connectionStatus==="connected"&&u.gameStatus==="active";n({enabled:K,live:cg}),ue()}async function ii(){ie("init() enter",{extensionEnabled:K});try{if(!K){ie("init() skipped â€” extension disabled");return}Ge(),ie("init() publisher.connect()"),await re.connect(),ie("init() publisher connected",{connected:re.isConnected()}),await I.load(),A==null||A(),A=null,T=null,Le(Cn(window.location.href)),st(),Ot?ie("init() onStateChange already registered"):(ie("init() registering onStateChange listener"),Ot=$.onStateChange(dt)),ie("init() reader.connect()"),console.log("[WPULSE READER] CONNECT",{reason:"pipeline-init"}),await $.connect(),ie("init() reader connected"),ie("init() ensureIdentity()"),await qe(),x(),Y(),ie("init() publishImmediateHeartbeat()"),Lt(),ie("init() READER CONNECTED complete")}catch(u){ie("init() ERROR",u),console.error("[PULSE] ERROR",u)}}(async()=>(K=await ot(),n({enabled:K,live:!1}),K?await at():console.log("[PULSE] extension disabled at boot â€” pipeline not started")))(),chrome.storage.onChanged.addListener((u,g)=>{if(g!=="local")return;const S=u[Mr];if(!S)return;const C=S.newValue!==!1;ie("storage.onChanged ENABLED_STORAGE_KEY",{next:C,current:K}),f(C)}),chrome.storage.onChanged.addListener((u,g)=>{if(g!=="local")return;const S=u[cs];S&&(console.log("[PULSE] IDENTITY STORAGE CHANGE DETECTED",{key:cs,newValue:S.newValue}),$.refreshConfirmedAssignment())}),chrome.runtime.onMessage.addListener((u,g,S)=>{if(!u||typeof u!="object")return;if(u.type==="WPULSE_ENABLED_CHANGED")return ie("onMessage WPULSE_ENABLED_CHANGED",{enabled:u.enabled}),f(u.enabled!==!1),S({ok:!0}),!0;if(u.type==="WPULSE_PING")return J==null||J.refresh(),qt(),S({ok:!0}),!0;if(u.type!=="GET_DETECTED_PLAYERS")return;if(console.log("[PULSE CONTENT] RECEIVED GET_DETECTED_PLAYERS",{message:u}),!K)return S({type:"DETECTED_PLAYERS_RESPONSE",connected:!1,gameStatus:"idle",detectedPlayers:[],automaticIdentity:null}),!0;let C="idle";try{C=$.getState().gameStatus}catch{C="idle"}return console.log("[PULSE CONTENT] RESPONDING DETECTED_PLAYERS",{gameStatus:C,detectedPlayers:$.getDetectedPlayers()}),S({type:"DETECTED_PLAYERS_RESPONSE",connected:!0,gameStatus:$.getState().gameStatus,detectedPlayers:$.getDetectedPlayers(),automaticIdentity:$.getAutomaticIdentity()}),!0});const ri="wpulseGateRefresh";chrome.storage.onChanged.addListener((u,g)=>{g!=="local"||!u[ri]||(J==null||J.refresh(),qt())}),document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"&&(J==null||J.refresh(),qt())});const oi=3e3;let En=!1;async function as(){if(En||!K||!He)return;const u=$.getAutomaticIdentity();if(u){En=!0;try{const g=await lc();if(g.kind==="unknown")return;(g.kind==="signed-out"||g.username.toLowerCase()!==u.username.toLowerCase())&&await qe(!0)}finally{En=!1}}}const wn=window.setInterval(()=>{document.visibilityState==="visible"&&as()},oi);document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"&&as()}),window.addEventListener("beforeunload",()=>{j(),de(),$.disconnect(),re.disconnect()}),rc(()=>{K=!1,window.clearInterval(wn),N!==null&&window.clearTimeout(N),N=null,b!==null&&window.clearTimeout(b),b=null,j(),de(),J==null||J.stop(),A==null||A(),A=null,Ot==null||Ot(),Ot=null,$.disconnect(),re.disconnect()}),window.addEventListener("unhandledrejection",u=>{Jt(u.reason)&&u.preventDefault()}),window.addEventListener("error",u=>{Jt(u.error??u.message)&&u.preventDefault()})}})();
